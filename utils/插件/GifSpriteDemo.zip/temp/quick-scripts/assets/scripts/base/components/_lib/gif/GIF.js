(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/base/components/_lib/gif/GIF.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '52eedBsjrpBrKOtcNxjdJXh', 'GIF', __filename);
// scripts/base/components/_lib/gif/GIF.ts

"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var LZW_1 = require("./LZW");
/**
 * GIF解析
 */
var GIF = /** @class */ (function () {
    function GIF(message) {
        this._offset = 0;
        this._info = {
            header: '',
            frames: [],
            comment: ''
        };
        this._message = null;
        this._delays = [];
        this._spriteFrames = [];
        this._canvas = null;
        this._context = null;
        if (!message || !message.buffer)
            return;
        this._message = message;
        this.buffer = message.buffer;
    }
    Object.defineProperty(GIF.prototype, "buffer", {
        get: function () {
            return this._buffer;
        },
        set: function (buffer) {
            this.clear();
            this._buffer = buffer;
            this._view = new Uint8Array(buffer);
            this.init();
        },
        enumerable: true,
        configurable: true
    });
    /**
     * 初始化
     */
    GIF.prototype.init = function () {
        return __awaiter(this, void 0, void 0, function () {
            var sT, eT;
            return __generator(this, function (_a) {
                sT = new Date().getTime();
                this.getHeader();
                this.getScrDesc();
                this.getTexture();
                eT = new Date().getTime();
                console.log("total time : " + (eT - sT) + "ms");
                return [2 /*return*/];
            });
        });
    };
    /**
     * 解析GIF得到所有的纹理
     */
    GIF.prototype.getTexture = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                // console.log(this._info)
                // await 0;
                // let index = 0;
                // let framePromises = this._info.frames.map(async frame => {
                //     const framePromise = await this.decodeFrame2Texture(frame, index++);
                //     return framePromise;
                // });
                // for (const framePromise of framePromises) {
                //     await framePromise;
                // }
                // let index = 0;
                // for (const frame of this._info.frames) {
                //     this.decodeFrame2Texture(frame, index++);
                // }
                this.getSpriteFrame(0);
                return [2 /*return*/];
            });
        });
    };
    /**
     * 得到对应索引的精灵帧
     * @param index
     */
    GIF.prototype.getSpriteFrame = function (index) {
        if (this._spriteFrames[index])
            return this._spriteFrames[index];
        return this.decodeFrame2Texture(this._info.frames[index], index);
    };
    /**
     * 解析frame数据为ImageData
     * 最耗时的操作(80%耗时归究这里)
     * @param frame frame数据
     */
    GIF.prototype.decodeFrame = function (frame) {
        // let imageData = this._context.getImageData(frame.img.x, frame.img.y, frame.img.w, frame.img.h)
        var imageData = new ImageData(frame.img.w, frame.img.h);
        frame.img.m ? this._tab = frame.img.colorTab : this._tab = this._info.colorTab;
        LZW_1.default.decode(frame.img.srcBuf, frame.img.codeSize).forEach(function (j, k) {
            imageData.data[k * 4] = this._tab[j * 3];
            imageData.data[k * 4 + 1] = this._tab[j * 3 + 1];
            imageData.data[k * 4 + 2] = this._tab[j * 3 + 2];
            imageData.data[k * 4 + 3] = 255;
            frame.ctrl.t ? (j == frame.ctrl.tranIndex ? imageData.data[k * 4 + 3] = 0 : 0) : 0;
        }.bind(this));
        return imageData;
    };
    /**
     * 合并ImageData数据
     * @param lastImageData 上一帧frame解析出来的ImageData
     * @param curImageData 当前的ImageData
     */
    GIF.prototype.mergeFrames = function (lastImageData, curImageData) {
        var imageData = curImageData;
        if (lastImageData) {
            for (var i = 0; i < imageData.data.length; i += 4) {
                if (imageData.data[i + 3] == 0) {
                    imageData.data[i] = this._lastData.data[i];
                    imageData.data[i + 1] = this._lastData.data[i + 1];
                    imageData.data[i + 2] = this._lastData.data[i + 2];
                    imageData.data[i + 3] = this._lastData.data[i + 3];
                }
            }
        }
        return imageData;
    };
    /**
     * 将DataUrl的数据转换为cc.SpriteFrame
     * @param dataUrl
     */
    GIF.prototype.dataUrl2SpriteFrame = function (dataUrl) {
        var texture = new cc.Texture2D();
        var spriteFrame = new cc.SpriteFrame();
        var image = new Image();
        image.src = dataUrl;
        texture.initWithElement(image);
        spriteFrame.setTexture(texture);
        return spriteFrame;
    };
    /**
     * 将frame数据转化为cc.Texture
     * @param frame 当前frame的数据
     * @param index 当前frame的顺序
     */
    GIF.prototype.decodeFrame2Texture = function (frame, index) {
        return __awaiter(this, void 0, void 0, function () {
            var imageData, curImageData, lastImageData, finalImageData, dataUrl;
            return __generator(this, function (_a) {
                // 1、初始化canvas的相关信息
                if (!this._context) {
                    this._canvas = document.createElement('canvas');
                    this._context = this._canvas.getContext('2d');
                    this._canvas.width = frame.img.w;
                    this._canvas.height = frame.img.h;
                }
                imageData = this.decodeFrame(frame);
                // 3、将当前frame的ImageData设置到canvas上（必须,否则会因为ImageData的尺寸大小可能不一样造成拉伸等错乱现象）
                this._context.putImageData(imageData, frame.img.x, frame.img.y, 0, 0, frame.img.w, frame.img.h);
                curImageData = this._context.getImageData(0, 0, this._canvas.width, this._canvas.height);
                lastImageData = this._lastData;
                finalImageData = this.mergeFrames(lastImageData, curImageData);
                // 5、把最终的ImageData设置到canvas上（形成合成之后的最终图像）
                this._context.putImageData(finalImageData, 0, 0);
                this._lastData = finalImageData;
                dataUrl = this._canvas.toDataURL("image/png");
                this._delays[index] = frame.ctrl.delay;
                this._spriteFrames[index] = this.dataUrl2SpriteFrame(dataUrl);
                if (this._spriteFrames.length == this._info.frames.length) {
                    // 8、解析完所有帧时回调
                    this._message.initFinishedFunc({ delays: this._delays, spriteFrames: this._spriteFrames, length: this._info.frames.length });
                }
                else {
                    // 7、解析完每一帧回调
                    this._message.initOneSpriteFrameFunc({ delays: this._delays, spriteFrames: this._spriteFrames, length: this._info.frames.length });
                }
                return [2 /*return*/, this._spriteFrames[index]];
            });
        });
    };
    /**
     * 读文件流
     * @param len 读取的长度
     */
    GIF.prototype.read = function (len) {
        return this._view.slice(this._offset, this._offset += len);
    };
    /**
     * 获取文件头部分(Header)
     * GIF署名(Signature)和版本号(Version)
     */
    GIF.prototype.getHeader = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                // await 0;
                this._info.header = '';
                this.read(6).forEach(function (e, i, arr) {
                    this._info.header += String.fromCharCode(e);
                }.bind(this));
                return [2 /*return*/];
            });
        });
    };
    /**
     * 获取逻辑屏幕标识符(Logical Screen Descriptor)
     * GIF数据流部分(GIF Data Stream)
     */
    GIF.prototype.getScrDesc = function () {
        return __awaiter(this, void 0, void 0, function () {
            var arr, i;
            return __generator(this, function (_a) {
                arr = this.read(7);
                this._info.w = arr[0] + (arr[1] << 8);
                this._info.h = arr[2] + (arr[3] << 8);
                this._info.m = 1 & arr[4] >> 7;
                this._info.cr = 7 & arr[4] >> 4;
                this._info.s = 1 & arr[4] >> 3;
                this._info.pixel = arr[4] & 0x07;
                this._info.bgColor = arr[5];
                this._info.radio = arr[6];
                if (this._info.m) {
                    this._info.colorTab = this.read((2 << this._info.pixel) * 3);
                }
                this.decode();
                return [2 /*return*/];
            });
        });
    };
    /**
     * 解析GIF数据流
     */
    GIF.prototype.decode = function () {
        var srcBuf = [];
        var arr = this.read(1);
        switch (arr[0]) {
            case 33: //扩展块
                this.extension();
                break;
            case 44: //图象标识符
                arr = this.read(9);
                this._frame.img = {
                    x: arr[0] + (arr[1] << 8),
                    y: arr[2] + (arr[3] << 8),
                    w: arr[4] + (arr[5] << 8),
                    h: arr[6] + (arr[7] << 8),
                    colorTab: 0
                };
                this._frame.img.m = 1 & arr[8] >> 7;
                this._frame.img.i = 1 & arr[8] >> 6;
                this._frame.img.s = 1 & arr[8] >> 5;
                this._frame.img.r = 3 & arr[8] >> 3;
                this._frame.img.pixel = arr[8] & 0x07;
                if (this._frame.img.m) {
                    this._frame.img.colorTab = this.read((2 << this._frame.img.pixel) * 3);
                }
                this._frame.img.codeSize = this.read(1)[0];
                srcBuf = [];
                while (1) {
                    arr = this.read(1);
                    if (arr[0]) {
                        this.read(arr[0]).forEach(function (e, i, arr) {
                            srcBuf.push(e);
                        });
                    }
                    else {
                        this._frame.img.srcBuf = srcBuf;
                        this.decode();
                        break;
                    }
                }
                ;
                break;
            case 59:
                console.log('The end.', this._offset, this.buffer.byteLength);
                break;
            default:
                // console.log(arr);
                break;
        }
    };
    /**
     * 扩展块部分
     */
    GIF.prototype.extension = function () {
        var arr = this.read(1), o, s;
        switch (arr[0]) {
            case 255: //应用程序扩展
                if (this.read(1)[0] == 11) {
                    this._info.appVersion = '';
                    this.read(11).forEach(function (e, i, arr) {
                        this._info.appVersion += String.fromCharCode(e);
                    }.bind(this));
                    while (1) {
                        arr = this.read(1);
                        if (arr[0]) {
                            this.read(arr[0]);
                        }
                        else {
                            this.decode();
                            break;
                        }
                    }
                    ;
                }
                else {
                    throw new Error('解析出错');
                }
                break;
            case 249: //图形控制扩展
                if (this.read(1)[0] == 4) {
                    arr = this.read(4);
                    this._frame = {};
                    this._frame.ctrl = {
                        disp: 7 & arr[0] >> 2,
                        i: 1 & arr[0] >> 1,
                        t: arr[0] & 0x01,
                        delay: arr[1] + (arr[2] << 8),
                        tranIndex: arr[3]
                    };
                    this._info.frames.push(this._frame);
                    if (this.read(1)[0] == 0) {
                        this.decode();
                    }
                    else {
                        throw new Error('解析出错');
                    }
                }
                else {
                    throw new Error('解析出错');
                }
                break;
            case 254: //注释块
                arr = this.read(1);
                if (arr[0]) {
                    this.read(arr[0]).forEach(function (e, i, arr) {
                        this._info.comment += String.fromCharCode(e);
                    });
                    if (this.read(1)[0] == 0) {
                        this.decode();
                    }
                    ;
                }
                break;
            default:
                // console.log(arr);
                break;
        }
    };
    /**
     * 初始化参数
     */
    GIF.prototype.clear = function () {
        this._tab = null;
        this._view = null;
        this._frame = null;
        this._offset = 0;
        this._info = {
            header: '',
            frames: [],
            comment: ''
        };
        this._lastData = null;
        this._delays = [];
        this._spriteFrames = [];
        this._canvas = null;
        this._context = null;
    };
    return GIF;
}());
exports.default = GIF;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=GIF.js.map
        