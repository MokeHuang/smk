(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/base/components/GIFSprite.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '0302bh9xdZGsJ0TUmwsx8tl', 'GIFSprite', __filename);
// scripts/base/components/GIFSprite.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var GIF_1 = require("./_lib/gif/GIF");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property, requireComponent = _a.requireComponent, disallowMultiple = _a.disallowMultiple, executeInEditMode = _a.executeInEditMode;
var BaseGIFSprite = /** @class */ (function (_super) {
    __extends(BaseGIFSprite, _super);
    function BaseGIFSprite() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._defaultSpriteFrame = null;
        _this._path = null;
        _this.sprite = null;
        _this._length = 0;
        _this._index = 0;
        return _this;
    }
    Object.defineProperty(BaseGIFSprite.prototype, "path", {
        get: function () { return this._path; },
        set: function (path) {
            if (path == null)
                return;
            this._path = path;
            this.clear();
            this.applayChange();
        },
        enumerable: true,
        configurable: true
    });
    BaseGIFSprite.prototype.onLoad = function () {
        this.sprite = this.node.getComponent(cc.Sprite);
        this._defaultSpriteFrame = this.sprite.spriteFrame;
    };
    BaseGIFSprite.prototype.start = function () {
        // let sT = new Date().getTime();
        this.applayChange();
        // let eT = new Date().getTime();
        // console.log("end", eT);
    };
    BaseGIFSprite.prototype.onDestroy = function () {
        this.sprite.spriteFrame = this._defaultSpriteFrame;
    };
    BaseGIFSprite.prototype.update = function (dt) {
        // console.log("update(dt):" + (new Date().getTime() - this._oldTime) + "ms");
        // this._oldTime = new Date().getTime();
        if (this._inited && CC_EDITOR) {
            var index = this._index++ % this._spriteFrames.length;
            var spriteFrame = this._spriteFrames[index];
            this.sprite.spriteFrame = spriteFrame, true;
            // console.log(this.sprite.spriteFrame, spriteFrame, this.sprite.spriteFrame == spriteFrame);
        }
        if (this._inited == null || this._inited)
            return;
        if (this._gif && this._spriteFrames && this._spriteFrames.length < this._length) {
            this._gif.getSpriteFrame(this._spriteFrames.length);
        }
        // else {
        //     this.inited();
        // }
    };
    BaseGIFSprite.prototype.setDefaultSpriteFrame = function (spriteFrame) {
        // console.log("setDefaultSpriteFrame", spriteFrame);
        this.sprite.spriteFrame = spriteFrame, true;
        // this.sprite.spriteFrame.setTexture(spriteFrame.getTexture())
    };
    /**
     * 初始化完成
     */
    BaseGIFSprite.prototype.inited = function () {
        this._gif = null;
        this._action = cc.repeatForever(cc.sequence([
            cc.delayTime(this._delays[this._index % this._length >= this._spriteFrames.length ? this._spriteFrames.length - 1 : this._index % this._length] * 10 / 1000 > 0.02 ?
                this._delays[this._index % this._length >= this._spriteFrames.length ? this._spriteFrames.length - 1 : this._index % this._length] * 10 / 1000 : 0.02),
            cc.callFunc(function () {
                var sp = this._spriteFrames[this._index++ % this._spriteFrames.length];
                this.sprite.spriteFrame = sp;
                // this.sprite.spriteFrame.setTexture(sp.getTexture());
            }.bind(this))
        ]));
        this.node.runAction(this._action.clone());
    };
    /**
     * 应用更改
     */
    BaseGIFSprite.prototype.applayChange = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                // await new Promise((resolve) => {
                cc.loader.load(this.path.toString(), function (err, result) {
                    return __awaiter(this, void 0, void 0, function () {
                        var gifMessage;
                        return __generator(this, function (_a) {
                            gifMessage = {
                                target: this,
                                buffer: result.buffer,
                                initOneSpriteFrameFunc: function (data) {
                                    this._delays = data.delays;
                                    this._spriteFrames = data.spriteFrames;
                                    this._length = data.length;
                                    if (data.spriteFrames.length == 1) {
                                        this.setDefaultSpriteFrame(data.spriteFrames[0]);
                                        this._inited = false;
                                        this.inited();
                                    }
                                }.bind(this),
                                initFinishedFunc: function (data) {
                                    this._delays = data.delays;
                                    this._spriteFrames = data.spriteFrames;
                                    // this.inited();
                                    this._inited = true;
                                }.bind(this)
                            };
                            this._gif = new GIF_1.default(gifMessage);
                            return [2 /*return*/];
                        });
                    });
                }.bind(this));
                return [2 /*return*/];
            });
        });
    };
    /**
     * 清空数据
     */
    BaseGIFSprite.prototype.clear = function () {
        this.node.stopAllActions();
        this._gif = null;
        this._index = 0;
        this._inited = null;
        this._delays = null;
        this._spriteFrames = null;
    };
    __decorate([
        property({ visible: false })
    ], BaseGIFSprite.prototype, "_defaultSpriteFrame", void 0);
    __decorate([
        property({ visible: false })
    ], BaseGIFSprite.prototype, "_path", void 0);
    __decorate([
        property({ type: cc.Asset })
    ], BaseGIFSprite.prototype, "path", null);
    BaseGIFSprite = __decorate([
        ccclass,
        executeInEditMode,
        disallowMultiple,
        requireComponent(cc.Sprite)
    ], BaseGIFSprite);
    return BaseGIFSprite;
}(cc.Component));
exports.default = BaseGIFSprite;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=GIFSprite.js.map
        