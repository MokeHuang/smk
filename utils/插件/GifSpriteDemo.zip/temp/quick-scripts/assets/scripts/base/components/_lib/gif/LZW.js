(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/base/components/_lib/gif/LZW.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'e054f13wvpNrZOOYDkya+6Y', 'LZW', __filename);
// script/base/components/_lib/gif/LZW.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * LZW编码解析
 */
var LZW = /** @class */ (function () {
    function LZW() {
    }
    LZW.decode = function (arr, min) {
        var clearCode = 1 << min, eofCode = clearCode + 1, size = min + 1, dict = [], pos = 0;
        function clear() {
            var i;
            dict = [];
            size = min + 1;
            for (i = 0; i < clearCode; i++) {
                dict[i] = [i];
            }
            dict[clearCode] = [];
            dict[eofCode] = null;
        }
        function decode() {
            var out = [], code, last;
            while (1) {
                last = code;
                code = read(size);
                if (code == clearCode) {
                    clear();
                    continue;
                }
                if (code == eofCode) {
                    break;
                }
                if (code < dict.length) {
                    if (last !== clearCode) {
                        dict.push(dict[last].concat(dict[code][0]));
                    }
                }
                else {
                    if (code !== dict.length) {
                        throw new Error('LZW解析出错');
                    }
                    dict.push(dict[last].concat(dict[last][0]));
                }
                out.push.apply(out, dict[code]);
                if (dict.length === (1 << size) && size < 12) {
                    size++;
                }
            }
            return out;
        }
        function read(size) {
            var i, code = 0;
            for (i = 0; i < size; i++) {
                if (arr[pos >> 3] & 1 << (pos & 7)) {
                    code |= 1 << i;
                }
                pos++;
            }
            return code;
        }
        // return { decode: decode }
        return decode();
    };
    return LZW;
}());
exports.default = LZW;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=LZW.js.map
        