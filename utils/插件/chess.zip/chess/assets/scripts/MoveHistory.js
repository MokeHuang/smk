// 移动历史记录
var history = [];

// 指针
var pointer = -1;

module.exports = {
    history: history,
	pointer: pointer
}
