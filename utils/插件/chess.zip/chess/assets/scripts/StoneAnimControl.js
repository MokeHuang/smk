cc.Class({
    extends: cc.Component,

    properties: {
        anim: cc.Animation
    },

    // onLoad () {},

    start() {
        this.playRun();
    },

    playRun: function () {
        this.anim = cc.find("stone").getComponent(cc.Animation);
        this.anim.play('move');
    },

    // update (dt) {},
});
