"use strict";
cc._RF.push(module, '1c684KaTNJHgJr7+0e0Eb0M', 'GameBoard');
// scripts/GameBoard.js

"use strict";

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

/**
 * 功能：游戏棋盘相关逻辑
 */
var Constant = require('./Constant.js');

var Stone = require('./Stone.js');

var MoveRule = require("./MoveRule.js");

var Request = require("./Request.js");

var MoveHistory = require("./MoveHistory.js");

var getName = function getName() {
  console.log(123);
}; //


cc.Class({
  "extends": cc.Component,
  properties: {
    //图集资源，用于初始化棋子prefab
    piecesAtlas: {
      "default": null,
      type: cc.SpriteAtlas
    },
    //棋子prefab
    piecePrefab: {
      "default": null,
      type: cc.Prefab
    },
    //可走点prefab
    dotPrefab: {
      "default": null,
      type: cc.Prefab
    },
    //移动前后标识prefab
    boxPrefab: {
      "default": null,
      type: cc.Prefab
    },
    //移动前后标识prefab
    eatPrefab: {
      "default": null,
      type: cc.Prefab
    },
    //游戏结束prefab
    gameOverPrefab: {
      "default": null,
      type: cc.Prefab
    },
    //将军prefab
    killPrefab: {
      "default": null,
      type: cc.Prefab
    },
    //二维数组存储棋子数据
    piecesArrArr: [],
    //是否获胜
    isWin: null,
    //是否轮到我下棋了
    isMyTurn: true,
    //旋转角度	180或0
    rotate: 180,
    //自己点击的棋子
    m_cur_click_stone: null,
    //红黑走棋对换
    red_or_black: Constant.turn_type.red,
    //可移动点预制体集合
    can_move_dot_list: [],
    // 将帅位置	初始为将位置
    jiang_shuai_row: 9,
    jiang_shuai_col: 4,
    websocket: '',
    // 避免重复连接
    lockReconnect: false,
    //红黑方
    redLabel: '123456',
    blackLabel: '45613',
    time: cc.Label,
    countdown: 300,
    //    倒计时的时间 为10秒
    move: cc.Animation
  },
  update: function update() {
    var _this = this;

    this.websocket.onmessage = function (evt) {
      // console.log(evt.data);
      if (!evt.data) {// 初始棋子历史记录
        // this.send_game_board_info(this.piecesArrArr, 20, 20, 20, 20, Constant.turn_type.black, this.websocket);
      } else {
        _this.lookerStones(evt.data);
      }
    };
  },
  // 测试全局接口
  getName: function getName(name) {
    console.log(name);
  },
  //组件加载时，进行变量初始化操作
  onLoad: function onLoad() {
    this.fn_countdown();
    getName = this.getName;
    getName('这是一个全局函数，我的名字叫做沙摩柯！'); // 创建连接并初始化棋子
    // this.getwebsocket()
    //初始化32颗棋子

    this.init32Stones(); // 初始化点击事件 求和 认输 悔棋 重开

    var self = this;
    cc.find("Canvas/spr_board_bg/retract").on(cc.Node.EventType.TOUCH_START, function (e) {
      // this.lookerStones();
      this.rotateGameBoard();
    }.bind(this));
    cc.find("button").on(cc.Node.EventType.TOUCH_START, function (e) {
      cc.find("stone").addComponent('StoneAnimControl');
      cc.log(cc.find("stone").getComponent(cc.Animation));
    }.bind(this));
    cc.find("Canvas/spr_board_bg/give_up").on(cc.Node.EventType.TOUCH_START, function (e) {
      console.log(self.isMyTurn);
      self.show_win(self.isMyTurn);
    }.bind(this));
    cc.find("Canvas/spr_board_bg/draw").on(cc.Node.EventType.TOUCH_START, function (e) {
      console.log('和棋');
      self.isWin = 2;
      this.countdown = 0;
      var gameOverPrefab = cc.instantiate(this.gameOverPrefab);
      console.log(this.gameOverPrefab);
      gameOverPrefab.setPosition(4 * Constant.cell_size - Constant.left_bottom_pos.len_x, 4.5 * Constant.cell_size - Constant.left_bottom_pos.len_y);
      this.node.addChild(gameOverPrefab);
      gameOverPrefab.runAction(cc.fadeTo(2));
    }.bind(this));
    cc.find("Canvas/spr_board_bg/reopen").on(cc.Node.EventType.TOUCH_START, function (e) {
      console.log('重开');
      this.countdown = 300;
      this.isWin = null; //初始化棋子数组信息

      for (var row = 0; row <= 9; row++) {
        for (var col = 0; col <= 8; col++) {
          if (self.piecesArrArr[row][col]) {
            self.piecesArrArr[row][col].m_piecePrefab.removeFromParent();
            self.piecesArrArr[row][col] = null;
          }
        }
      }

      MoveHistory.history = [];
      self.clear_can_move_dot();
      self.red_or_black = Constant.turn_type.red;
      self.isMyTurn = true;
      self.init32Stones();
    }.bind(this)); //初始化点击事件

    this.node.on(cc.Node.EventType.TOUCH_START, function (e) {
      if (this.isWin !== null) {
        console.log('对弈结束，请重新开始');
        return;
      }

      this.red_or_black = this.isMyTurn ? Constant.turn_type.red : Constant.turn_type.black; //
      //判断是否有走棋的权限

      if (this.red_or_black === Constant.turn_type.red) {
        // this.checkUrl('uin')
        if (this.redLabel != '123456') {
          return;
        } else {// console.log(123456);
        }
      } else if (this.red_or_black === Constant.turn_type.black) {
        if (this.blackLabel != '45613') {
          return;
        } else {// console.log(45613);
        }
      } //


      var click_info = this.get_select_row_col_by_click(e);
      var row = click_info.row;
      var col = click_info.col; //

      if (row < 0 || row > 9 || col < 0 || col > 8) {
        return;
      } else {
        var click_stone = this.piecesArrArr[row][col]; //点中了一个棋子

        if (click_stone) {
          //点了红旗，切换当前选中的棋子
          // if(click_stone.m_turn_type === Constant.turn_type.red){
          if (click_stone.m_turn_type === this.red_or_black) {
            //
            this.select_one_stone(click_stone);
          } //点了黑棋，1.如果当前没有选中棋子，则报错 2.选中了棋子，则试图吃掉当前的黑棋
          else {
              if (!this.m_cur_click_stone) {
                console.log('轮到' + (this.red_or_black ? 'black' : 'red') + '走棋！');
              } else {
                //试图去吃黑色棋子 this.m_cur_click_stone
                if (MoveRule.canMove(this, row, col)) {
                  this.kill_stone(row, col);
                }
              }
            }
        } //选中棋子后，又选择了一个空位置
        else {
            if (!this.m_cur_click_stone) {} else {
              if (MoveRule.canMove(this, row, col)) {
                this.move_stone(row, col);
              }
            }
          }
      }
    }.bind(this), this);
  },
  //旋转棋盘
  rotateGameBoard: function rotateGameBoard() {
    var _this2 = this;

    this.node.runAction(cc.rotateTo(0, this.rotate, this.rotate));
    this.node.children.forEach(function (item) {
      item.runAction(cc.rotateTo(0, _this2.rotate, _this2.rotate));
    });
    this.rotate = this.rotate == 180 ? 0 : 180;
  },
  fn_countdown: function fn_countdown() {
    this.time.string = 300; //  场景文本框为 显示10

    this.countdown = 300;

    if (this.countdown >= 0) {
      this.schedule(function () {
        // 计时器将每隔 1s 执行一次。
        this.DoSomething();
      }, 1);
    }
  },
  DoSomething: function DoSomething() {
    // 倒计时算法
    if (this.countdown >= 1) {
      this.countdown = this.countdown - 1;
      this.time.string = this.countdown; //场景中文本框显示
    } else {
      this.show_win(!this.red_or_black);
    }
  },
  //根据点击点获取点击的行列
  get_select_row_col_by_click: function get_select_row_col_by_click(e) {
    var pos = this.node.convertToNodeSpaceAR(e.getLocation());
    var row = Math.floor((pos.y + Constant.left_bottom_pos.len_y + Constant.cell_size * 0.5) / Constant.cell_size);
    var col = Math.floor((pos.x + Constant.left_bottom_pos.len_x + Constant.cell_size * 0.5) / Constant.cell_size);
    return {
      row: row,
      col: col
    };
  },
  //选中一颗棋子后 显示可移动的点
  can_move_dot: function can_move_dot() {
    for (var r = 0; r < 10; r++) {
      for (var c = 0; c < 9; c++) {
        if (MoveRule.canMove(this, r, c)) {
          var x = c * Constant.cell_size - Constant.left_bottom_pos.len_x;
          var y = r * Constant.cell_size - Constant.left_bottom_pos.len_y; //创建可移动dot预制体 并存储

          var dotPrefab = cc.instantiate(this.dotPrefab);
          dotPrefab.setPosition(x, y);
          this.node.addChild(dotPrefab);
          this.can_move_dot_list.push(dotPrefab);
        }
      }
    }
  },
  //清除可移动点dot 移动前后标记box 传参
  clear_can_move_dot: function clear_can_move_dot(no_box) {
    if (this.can_move_dot_list.length === 0) return; // 第一个为box则不清除，则0，1都为box不清除，否在全部清除

    if (this.can_move_dot_list[0].name === no_box) {
      this.can_move_dot_list.slice(2).forEach(function (item) {
        item.removeFromParent();
      });
      this.can_move_dot_list = this.can_move_dot_list.slice(0, 2);
    } else {
      this.can_move_dot_list.forEach(function (item) {
        item.removeFromParent();
      });
      this.can_move_dot_list = [];
    }
  },
  // 记录移动前后棋子的位置
  move_front_back: function move_front_back(row, col, old_row, old_col) {
    var x = col * Constant.cell_size - Constant.left_bottom_pos.len_x;
    var y = row * Constant.cell_size - Constant.left_bottom_pos.len_y;

    for (var i = 0; i < 2; i++) {
      var boxPrefab = cc.instantiate(this.boxPrefab);
      boxPrefab.setPosition(x, y);
      this.node.addChild(boxPrefab);
      this.can_move_dot_list.push(boxPrefab);
      x = old_col * Constant.cell_size - Constant.left_bottom_pos.len_x;
      y = old_row * Constant.cell_size - Constant.left_bottom_pos.len_y;
    }
  },
  show_win: function show_win(turn_type) {
    // 胜利条件判断
    if (turn_type) {
      console.log('黑方胜利！！！');
      this.isWin = Constant.turn_type.black;
    } else {
      console.log('红方胜利！！！');
      this.isWin = Constant.turn_type.red;
    }

    this.countdown = 0;
    var gameOverPrefab = cc.instantiate(this.gameOverPrefab);
    gameOverPrefab.setPosition(4 * Constant.cell_size - Constant.left_bottom_pos.len_x, 4.5 * Constant.cell_size - Constant.left_bottom_pos.len_y);
    this.node.addChild(gameOverPrefab);
    gameOverPrefab.runAction(cc.fadeTo(2));
  },
  // 将帅能移动位置
  fn_jiang_shuai_can_move: function fn_jiang_shuai_can_move() {
    // 存储将或帅能走的位置
    var jiang_shuai_can_move = new Set(); // 赋予当前点击对象为将或帅

    this.m_cur_click_stone = this.piecesArrArr[this.jiang_shuai_row][this.jiang_shuai_col]; // 添加将帅自己的位置

    jiang_shuai_can_move.add('{"row":' + this.jiang_shuai_row + ',' + '"col":' + this.jiang_shuai_col + '}');

    for (var r = 0; r < 10; r++) {
      for (var c = 3; c <= 5; c++) {
        // 跳过九宫格外的其他位置 记录将或帅位置
        r = r === 3 ? 7 : r; // 总为移动方将帅位置

        if (this.piecesArrArr[r][c] && this.piecesArrArr[r][c].m_stone_type === 6 && this.piecesArrArr[r][c].m_turn_type === this.red_or_black) {
          this.jiang_shuai_row = r;
          this.jiang_shuai_col = c;
        } // 判断将帅可移动的位置
        //      if(MoveRule.canMove(this, r, c)){
        // jiang_shuai_can_move.add('{"row":' + r + ',' + '"col":' + c + '}');
        //      }

      }
    }

    return jiang_shuai_can_move;
  },
  // 本方棋子的攻击范围
  fn_m_attack_scope: function fn_m_attack_scope(old_jiang_shuai_row, old_jiang_shuai_col) {
    var _this3 = this;

    var m_all_can_move = new Set(); // 本方所有棋子能走的位置

    var arr = [];
    this.piecesArrArr.forEach(function (item) {
      arr.push.apply(arr, _toConsumableArray(item));
    });
    arr.forEach(function (item) {
      // 本方
      if (item && item.m_turn_type === _this3.red_or_black) {
        _this3.m_cur_click_stone = item;

        for (var r = 0; r < 10; r++) {
          for (var c = 0; c < 9; c++) {
            // 本方所有棋子能走的位置
            if (MoveRule.canMove(_this3, r, c)) {
              if (_this3.m_cur_click_stone.m_stone_type === 4) {
                // 炮 特殊，需要隔子
                if (old_jiang_shuai_row === r && old_jiang_shuai_col === c) {
                  if (MoveRule.get_stone_num_between_row_col(_this3, _this3.m_cur_click_stone.m_row, _this3.m_cur_click_stone.m_col, old_jiang_shuai_row, old_jiang_shuai_col) === 1) {
                    if (_this3.m_cur_click_stone.m_row === old_jiang_shuai_row) {
                      if (!_this3.piecesArrArr[r][c + 1]) {
                        m_all_can_move.add('{"row":' + r + ',' + '"col":' + (c + 1) + '}');
                      }

                      if (!_this3.piecesArrArr[r][c - 1]) {
                        m_all_can_move.add('{"row":' + r + ',' + '"col":' + (c - 1) + '}');
                      }
                    }

                    if (_this3.m_cur_click_stone.m_col === old_jiang_shuai_col) {
                      if (r + 1 <= 9 && !_this3.piecesArrArr[r + 1][c]) {
                        m_all_can_move.add('{"row":' + (r + 1) + ',' + '"col":' + c + '}');
                      }

                      if (r - 1 >= 0 && !_this3.piecesArrArr[r - 1][c]) {
                        m_all_can_move.add('{"row":' + (r - 1) + ',' + '"col":' + c + '}');
                      }
                    }

                    m_all_can_move.add('{"row":' + r + ',' + '"col":' + c + '}');
                  }
                }
              } else {
                m_all_can_move.add('{"row":' + r + ',' + '"col":' + c + '}');
              }
            }
          }
        }
      }
    });
    return m_all_can_move;
  },
  // 将军	// 绝杀
  final_hit: function final_hit() {
    var temp = this.m_cur_click_stone; // 存储本方全部子能移动的位置 先

    var m_all_can_move = this.fn_m_attack_scope(this.jiang_shuai_row, this.jiang_shuai_col); // 存储将或帅能移动的位置 后

    var jiang_shuai_can_move = this.fn_jiang_shuai_can_move();
    this.m_cur_click_stone = temp;
    var size = jiang_shuai_can_move.size; // 清除当前将帅的当前点击

    jiang_shuai_can_move.forEach(function (item) {
      // 判断将帅可移动的位置 是否在 本方所有棋子可移动位置范围内
      if (m_all_can_move.has(item)) {
        jiang_shuai_can_move["delete"](item);
      }
    });

    if (size !== jiang_shuai_can_move.size) {
      console.log('将军'); // 动画

      var killPrefab = cc.instantiate(this.killPrefab);
      killPrefab.setPosition(4 * Constant.cell_size - Constant.left_bottom_pos.len_x, 4.5 * Constant.cell_size - Constant.left_bottom_pos.len_y);
      this.node.addChild(killPrefab);
      killPrefab.runAction(cc.fadeTo(2));
      setTimeout(function () {
        killPrefab.removeFromParent();
      }, 2000);
    }

    for (var i = 0; i < 10; i++) {
      if (this.piecesArrArr[i][this.jiang_shuai_col] && this.piecesArrArr[i][this.jiang_shuai_col].m_stone_type === 6 && this.piecesArrArr[i][this.jiang_shuai_col].m_row !== this.jiang_shuai_row) {
        if (MoveRule.get_stone_num_between_row_col(this, i, this.jiang_shuai_col, this.jiang_shuai_row, this.jiang_shuai_col) === 0) {
          this.show_win(!this.red_or_black);
          return;
        }
      }
    }
  },
  //选中一颗棋子
  select_one_stone: function select_one_stone(click_stone) {
    if (this.can_move_dot_list) {
      this.clear_can_move_dot('box');
    }

    if (this.m_cur_click_stone) {
      var pre_prefab = this.m_cur_click_stone.m_piecePrefab;
      pre_prefab.stopAllActions();
      pre_prefab.scale = 1;
    } //刷新新的棋子


    this.m_cur_click_stone = click_stone;
    var prefab = this.m_cur_click_stone.m_piecePrefab;
    prefab.stopAllActions();
    prefab.scale = 1;
    prefab.runAction(cc.repeatForever(cc.sequence(cc.scaleTo(0.5, 0.8), cc.scaleTo(0.5, 1.0)))); //判断可移动点

    this.can_move_dot();
  },
  //杀死棋子
  kill_stone: function kill_stone(row, col) {
    var _this4 = this;

    // 棋子移动动画
    var mySprite = this.m_cur_click_stone.m_piecePrefab;
    var moveTo = cc.moveTo(0.2, col * Constant.cell_size - Constant.left_bottom_pos.len_x, row * Constant.cell_size - Constant.left_bottom_pos.len_y);
    mySprite.runAction(moveTo); // 定时器 棋子移动完后再进行下一步操作

    setTimeout(function () {
      //1.黑棋被吃掉
      var eatBlackStone = _this4.piecesArrArr[row][col];
      eatBlackStone.m_is_dead = true;
      eatBlackStone.m_piecePrefab.removeFromParent(); //2.存的的红棋的位置置空

      _this4.piecesArrArr[_this4.m_cur_click_stone.m_row][_this4.m_cur_click_stone.m_col] = null;
      var old_row = _this4.m_cur_click_stone.m_row;
      var old_col = _this4.m_cur_click_stone.m_col; //3.走棋后修改红旗属性

      _this4.m_cur_click_stone.m_row = row;
      _this4.m_cur_click_stone.m_col = col; //4.修改红旗新的UI位置

      var x = col * Constant.cell_size - Constant.left_bottom_pos.len_x;
      var y = row * Constant.cell_size - Constant.left_bottom_pos.len_y;

      _this4.m_cur_click_stone.m_piecePrefab.setPosition(x, y); //5.刷新存储


      _this4.piecesArrArr[row][col] = _this4.m_cur_click_stone; // 向服务器发送走棋记录

      _this4.send_game_board_info(_this4.piecesArrArr, row, col, old_row, old_col, _this4.red_or_black, _this4.m_cur_click_stone.m_stone_type, _this4.websocket); //6.走完棋后设置当前未选中棋子


      var prefab = _this4.m_cur_click_stone.m_piecePrefab;
      prefab.stopAllActions();
      prefab.scale = 1;
      _this4.m_cur_click_stone = null; //7.轮到对方走棋

      _this4.isMyTurn = !_this4.isMyTurn; //
      // console.log('吃!'); 动画

      var eatPrefab = cc.instantiate(_this4.eatPrefab);
      eatPrefab.setPosition(4 * Constant.cell_size - Constant.left_bottom_pos.len_x, 4.5 * Constant.cell_size - Constant.left_bottom_pos.len_y);

      _this4.node.addChild(eatPrefab);

      eatPrefab.runAction(cc.fadeTo(2));
      setTimeout(function () {
        eatPrefab.removeFromParent();
      }, 2000); // 胜利条件 将帅被吃

      if (eatBlackStone.m_stone_type === Constant.stone_type.jiang) {
        _this4.show_win(!eatBlackStone.m_turn_type);
      } //清除可移动点的预制体


      _this4.clear_can_move_dot(); // 标记移动前后的位置


      _this4.move_front_back(row, col, old_row, old_col); // 将军 绝杀


      _this4.final_hit();

      _this4.countdown = 300;
    }, 200);
  },
  //移动棋子
  move_stone: function move_stone(row, col) {
    var _this5 = this;

    // 棋子移动动画
    var mySprite = this.m_cur_click_stone.m_piecePrefab;
    var moveTo = cc.moveTo(0.3, col * Constant.cell_size - Constant.left_bottom_pos.len_x, row * Constant.cell_size - Constant.left_bottom_pos.len_y);
    mySprite.runAction(moveTo); // 定时器 棋子移动完后再进行下一步操作

    setTimeout(function () {
      //1.清理原来位置
      var old_row = _this5.m_cur_click_stone.m_row;
      var old_col = _this5.m_cur_click_stone.m_col;
      _this5.piecesArrArr[old_row][old_col] = null; //2.设置新的数据

      _this5.m_cur_click_stone.m_row = row;
      _this5.m_cur_click_stone.m_col = col;
      _this5.piecesArrArr[row][col] = _this5.m_cur_click_stone; //3.更新位置

      var x = col * Constant.cell_size - Constant.left_bottom_pos.len_x;
      var y = row * Constant.cell_size - Constant.left_bottom_pos.len_y;

      _this5.m_cur_click_stone.m_piecePrefab.setPosition(x, y); // 向服务器发送走棋记录


      _this5.send_game_board_info(_this5.piecesArrArr, row, col, old_row, old_col, _this5.red_or_black, _this5.m_cur_click_stone.m_stone_type, _this5.websocket); //4.走完棋子停止动作


      var prefab = _this5.m_cur_click_stone.m_piecePrefab;
      prefab.stopAllActions();
      prefab.scale = 1;
      _this5.m_cur_click_stone = null; //5.轮到对方走棋

      _this5.isMyTurn = !_this5.isMyTurn; //
      //清除可移动点的预制体

      _this5.clear_can_move_dot(); // 标记移动前后的位置


      _this5.move_front_back(row, col, old_row, old_col); // 将军 绝杀


      _this5.final_hit();

      _this5.countdown = 300;
    }, 301);
  },
  //初始化32颗棋子
  init32Stones: function init32Stones() {
    //初始化棋子数组信息
    for (var row = 0; row <= 9; row++) {
      this.piecesArrArr[row] = [];

      for (var col = 0; col <= 8; col++) {
        this.piecesArrArr[row][col] = null;
      }
    } //棋子初始化信息


    var game_board_init_info = Constant.game_board_init_info;

    for (var k in game_board_init_info) {
      var stone_info = game_board_init_info[k];
      var row = stone_info.row;
      var col = stone_info.col;
      var turn_type = stone_info.turn_type;
      var stone_type = stone_info.stone_type;
      var piecePrefab = this.createOnePieceByName(Constant.stone_res_config[turn_type][stone_type]); //创建一颗棋子

      var stone = new Stone(turn_type, stone_type, false, row, col, piecePrefab);
      var x = col * Constant.cell_size - Constant.left_bottom_pos.len_x;
      var y = row * Constant.cell_size - Constant.left_bottom_pos.len_y;
      stone.m_piecePrefab.setPosition(x, y);
      this.node.addChild(stone.m_piecePrefab); //存储棋子信息

      this.piecesArrArr[row][col] = stone;
    }
  },
  //初始化观看者棋子变化
  lookerStones: function lookerStones(data) {
    var game_board_info = JSON.parse(data); // if(MoveHistory.pointer < 1){
    // 	var game_board_info = JSON.parse(MoveHistory.history[0]);
    // } else {
    // 	MoveHistory.pointer--;
    // 	var game_board_info = JSON.parse(MoveHistory.history[MoveHistory.pointer]);
    // 	MoveHistory.history.pop();
    // }
    // console.log(game_board_info.move.r_o_b, game_board_info, this.isMyTurn);
    //初始化棋子数组信息

    for (var row = 0; row <= 9; row++) {
      // this.piecesArrArr[row] = [];
      for (var col = 0; col <= 8; col++) {
        if (this.piecesArrArr[row][col]) {
          this.piecesArrArr[row][col].m_piecePrefab.removeFromParent();
          this.piecesArrArr[row][col] = null;
        }
      }
    }

    this.clear_can_move_dot();
    this.move_front_back(game_board_info.move.r, game_board_info.move.c, game_board_info.move.o_r, game_board_info.move.o_c);
    this.isMyTurn = game_board_info.move.r_o_b;
    this.red_or_black = this.isMyTurn ? Constant.turn_type.red : Constant.turn_type.black; //棋子初始化信息

    var game_board_init_info = game_board_info.data;

    for (var k in game_board_init_info) {
      var stone_info = game_board_init_info[k];
      var row = stone_info.r;
      var col = stone_info.c;
      var turn_type = stone_info.t_t;
      var stone_type = stone_info.s_t;
      var piecePrefab = this.createOnePieceByName(Constant.stone_res_config[turn_type][stone_type]); //创建一颗棋子

      var stone = new Stone(turn_type, stone_type, false, row, col, piecePrefab); //棋盘旋转后每次渲染旋转棋子

      if (this.rotate == 0) {
        stone.m_piecePrefab.is3DNode = true;
        stone.m_piecePrefab.eulerAngles = cc.v3(180, 180, 0); // stone.m_piecePrefab.runAction(cc.rotateTo(0, 180, 180))
      }

      var x = col * Constant.cell_size - Constant.left_bottom_pos.len_x;
      var y = row * Constant.cell_size - Constant.left_bottom_pos.len_y;
      stone.m_piecePrefab.setPosition(x, y); //初始化倒计时

      this.countdown = 300;
      this.node.addChild(stone.m_piecePrefab); //存储棋子信息

      this.piecesArrArr[row][col] = stone;
    }
  },
  //根据棋子名称创建一颗棋子
  createOnePieceByName: function createOnePieceByName(pieceName) {
    var piece = cc.instantiate(this.piecePrefab);
    piece.getComponent(cc.Sprite).spriteFrame = this.piecesAtlas.getSpriteFrame(pieceName);
    return piece;
  },
  // 发送请求
  send_game_board_info: function send_game_board_info(piecesArrArr, row, col, old_row, old_col, red_or_black, stone_type, websocket) {
    var arr = [];
    piecesArrArr.forEach(function (item) {
      arr.push.apply(arr, _toConsumableArray(item));
    }); // 移动请求数据

    var game_board_info = [];
    arr.forEach(function (item) {
      if (item) {
        game_board_info.push({
          s_t: item.m_stone_type,
          t_t: item.m_turn_type,
          r: item.m_row,
          c: item.m_col
        });
      }
    });
    var data = {
      data: game_board_info,
      move: {
        r_o_b: red_or_black,
        s_t: stone_type,
        r: row,
        c: col,
        o_r: old_row,
        o_c: old_col
      }
    }; // console.log(this.websocket)

    this.websocket.send(JSON.stringify(data));
  },
  // url编码
  checkUrl: function checkUrl(searchStr) {
    function getQueryString(name) {
      var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)');
      var r = window.location.search.substr(1).match(reg); // var r = 'roomid=4683456&uin=45613'.match(reg);

      if (r != null) return unescape(r[2]);
      return '';
    }

    return encodeURIComponent(getQueryString(searchStr));
  },
  getwebsocket: function getwebsocket() {
    var _this6 = this;

    //新建websocket的函数 页面初始化 断开连接时重新调用
    var roomid = this.checkUrl('roomid') || '4683456';
    var uin = this.checkUrl('uin') || '45613';
    var wsUrl = 'ws://192.168.2.141:8010/ws?roomid=' + roomid + '&uin=' + uin;
    this.websocket = new WebSocket(wsUrl);

    this.websocket.onopen = function (event) {
      _this6.init32Stones();
    }; // this.websocket.onclose = (event) => {
    // 	//console.log('websocket服务关闭了');
    // };


    this.websocket.onmessage = function (event) {
      console.log(event.data);

      if (!evt.data) {// 初始棋子历史记录
        // this.send_game_board_info(this.piecesArrArr, 20, 20, 20, 20, Constant.turn_type.black, this.websocket);
      } else {
        console.log(evt.data);
        this.lookerStones(evt.data);
      }
    };
  }
});

cc._RF.pop();