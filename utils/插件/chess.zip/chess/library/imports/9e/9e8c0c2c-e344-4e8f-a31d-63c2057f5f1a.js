"use strict";
cc._RF.push(module, '9e8c0ws40ROj6MdY8IFf18a', 'StoneAnimControl');
// scripts/StoneAnimControl.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    anim: cc.Animation
  },
  // onLoad () {},
  start: function start() {
    this.playRun();
  },
  playRun: function playRun() {
    this.anim = cc.find("stone").getComponent(cc.Animation);
    this.anim.play('move');
  } // update (dt) {},

});

cc._RF.pop();