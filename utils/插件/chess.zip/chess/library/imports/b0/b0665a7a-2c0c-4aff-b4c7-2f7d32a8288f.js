"use strict";
cc._RF.push(module, 'b0665p6LAxK/7THL30yqCiP', 'MoveHistory');
// scripts/MoveHistory.js

"use strict";

// 移动历史记录
var history = []; // 指针

var pointer = -1;
module.exports = {
  history: history,
  pointer: pointer
};

cc._RF.pop();