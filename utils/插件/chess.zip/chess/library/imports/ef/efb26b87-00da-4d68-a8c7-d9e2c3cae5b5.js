"use strict";
cc._RF.push(module, 'efb26uHANpNaKjH2eLDyuW1', 'Request');
// scripts/Request.js

"use strict";

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

var MoveHistory = require("./MoveHistory.js"); // 发送请求


var send_game_board_info = function send_game_board_info(piecesArrArr, row, col, old_row, old_col, red_or_black, stone_type, websocket) {
  var arr = [];
  piecesArrArr.forEach(function (item) {
    arr.push.apply(arr, _toConsumableArray(item));
  }); // 移动请求数据

  var game_board_info = [];
  arr.forEach(function (item) {
    if (item) {
      game_board_info.push({
        s_t: item.m_stone_type,
        t_t: item.m_turn_type,
        r: item.m_row,
        c: item.m_col
      });
    }
  });
  var data = {
    data: game_board_info,
    move: {
      r_o_b: red_or_black,
      s_t: stone_type,
      r: row,
      c: col,
      o_r: old_row,
      o_c: old_col
    }
  }; // console.log(data, JSON.stringify(data));

  MoveHistory.history.push(JSON.stringify(data));
  MoveHistory.pointer++; // var httpRequest = new XMLHttpRequest();
  // httpRequest.open('POST', 'http://192.168.2.141:8000', true);
  // // httpRequest.setRequestHeader("Content-type","application/json");
  // httpRequest.send(JSON.stringify(data));
  // httpRequest.onreadystatechange = function () {
  // 	if (httpRequest.readyState == 4 && httpRequest.status == 200) {
  // 		var json = httpRequest.responseText; //获取到服务端返回的数据
  // 		console.log(json);
  // 	}
  // };
  // console.log(data, websocket)
  // websocket.onopen = function() {

  websocket.send(JSON.stringify(data)); // }

  if (websocket.readyState === 1) {
    // console.log(websocket.onmessage)
    websocket.onmessage = function (evt) {
      console.log(evt);
    };

    console.log(websocket.readyState);
  } // websocket.addEventListener('open', function () {
  // });

};

module.exports = {
  send_game_board_info: send_game_board_info
};

cc._RF.pop();