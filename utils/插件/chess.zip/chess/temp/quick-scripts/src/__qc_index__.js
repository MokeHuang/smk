
require('./assets/migration/use_v2.0.x_cc.Toggle_event');
require('./assets/scripts/Constant');
require('./assets/scripts/GameBoard');
require('./assets/scripts/MoveHistory');
require('./assets/scripts/MoveRule');
require('./assets/scripts/Request');
require('./assets/scripts/Stone');
require('./assets/scripts/StoneAnimControl');
