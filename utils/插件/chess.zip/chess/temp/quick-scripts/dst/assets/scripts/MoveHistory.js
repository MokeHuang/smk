
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/MoveHistory.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b0665p6LAxK/7THL30yqCiP', 'MoveHistory');
// scripts/MoveHistory.js

"use strict";

// 移动历史记录
var history = []; // 指针

var pointer = -1;
module.exports = {
  history: history,
  pointer: pointer
};

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9zY3JpcHRzL01vdmVIaXN0b3J5LmpzIl0sIm5hbWVzIjpbImhpc3RvcnkiLCJwb2ludGVyIiwibW9kdWxlIiwiZXhwb3J0cyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBLElBQUlBLE9BQU8sR0FBRyxFQUFkLEVBRUE7O0FBQ0EsSUFBSUMsT0FBTyxHQUFHLENBQUMsQ0FBZjtBQUVBQyxNQUFNLENBQUNDLE9BQVAsR0FBaUI7QUFDYkgsRUFBQUEsT0FBTyxFQUFFQSxPQURJO0FBRWhCQyxFQUFBQSxPQUFPLEVBQUVBO0FBRk8sQ0FBakIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIOenu+WKqOWOhuWPsuiusOW9lVxudmFyIGhpc3RvcnkgPSBbXTtcblxuLy8g5oyH6ZKIXG52YXIgcG9pbnRlciA9IC0xO1xuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgICBoaXN0b3J5OiBoaXN0b3J5LFxuXHRwb2ludGVyOiBwb2ludGVyXG59XG4iXX0=