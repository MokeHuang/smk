
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/Stone.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b094e19WPlEJbHhZq0SclmZ', 'Stone');
// scripts/Stone.js

"use strict";

/**
 * 棋盘中的一颗棋子
 */

/**
 * turn_type     红黑哪一方
 * stone_type    棋子类型
 * is_dead       是否已经死了
 * row           棋子所在行
 * col           棋子所在列
 * pieceFrefab   棋子对应的prefab图片
 */
var Stone = function Stone(turn_type, stone_type, is_dead, row, col, piecePrefab) {
  this.m_turn_type = turn_type;
  this.m_stone_type = stone_type;
  this.m_is_dead = is_dead;
  this.m_row = row;
  this.m_col = col;
  this.m_piecePrefab = piecePrefab;
};

module.exports = Stone;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9zY3JpcHRzL1N0b25lLmpzIl0sIm5hbWVzIjpbIlN0b25lIiwidHVybl90eXBlIiwic3RvbmVfdHlwZSIsImlzX2RlYWQiLCJyb3ciLCJjb2wiLCJwaWVjZVByZWZhYiIsIm1fdHVybl90eXBlIiwibV9zdG9uZV90eXBlIiwibV9pc19kZWFkIiwibV9yb3ciLCJtX2NvbCIsIm1fcGllY2VQcmVmYWIiLCJtb2R1bGUiLCJleHBvcnRzIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBOzs7O0FBSUE7Ozs7Ozs7O0FBUUEsSUFBSUEsS0FBSyxHQUFHLFNBQVJBLEtBQVEsQ0FBU0MsU0FBVCxFQUFvQkMsVUFBcEIsRUFBZ0NDLE9BQWhDLEVBQXlDQyxHQUF6QyxFQUE4Q0MsR0FBOUMsRUFBbURDLFdBQW5ELEVBQStEO0FBQ3ZFLE9BQUtDLFdBQUwsR0FBbUJOLFNBQW5CO0FBQ0EsT0FBS08sWUFBTCxHQUFvQk4sVUFBcEI7QUFDQSxPQUFLTyxTQUFMLEdBQWlCTixPQUFqQjtBQUNBLE9BQUtPLEtBQUwsR0FBYU4sR0FBYjtBQUNBLE9BQUtPLEtBQUwsR0FBYU4sR0FBYjtBQUNBLE9BQUtPLGFBQUwsR0FBcUJOLFdBQXJCO0FBQ0gsQ0FQRDs7QUFVQU8sTUFBTSxDQUFDQyxPQUFQLEdBQWlCZCxLQUFqQiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiDmo4vnm5jkuK3nmoTkuIDpopfmo4vlrZBcbiAqL1xuXG4vKipcbiAqIHR1cm5fdHlwZSAgICAg57qi6buR5ZOq5LiA5pa5XG4gKiBzdG9uZV90eXBlICAgIOaji+WtkOexu+Wei1xuICogaXNfZGVhZCAgICAgICDmmK/lkKblt7Lnu4/mrbvkuoZcbiAqIHJvdyAgICAgICAgICAg5qOL5a2Q5omA5Zyo6KGMXG4gKiBjb2wgICAgICAgICAgIOaji+WtkOaJgOWcqOWIl1xuICogcGllY2VGcmVmYWIgICDmo4vlrZDlr7nlupTnmoRwcmVmYWLlm77niYdcbiAqL1xudmFyIFN0b25lID0gZnVuY3Rpb24odHVybl90eXBlLCBzdG9uZV90eXBlLCBpc19kZWFkLCByb3csIGNvbCwgcGllY2VQcmVmYWIpe1xuICAgIHRoaXMubV90dXJuX3R5cGUgPSB0dXJuX3R5cGU7XG4gICAgdGhpcy5tX3N0b25lX3R5cGUgPSBzdG9uZV90eXBlO1xuICAgIHRoaXMubV9pc19kZWFkID0gaXNfZGVhZDtcbiAgICB0aGlzLm1fcm93ID0gcm93O1xuICAgIHRoaXMubV9jb2wgPSBjb2w7XG4gICAgdGhpcy5tX3BpZWNlUHJlZmFiID0gcGllY2VQcmVmYWI7XG59XG5cblxubW9kdWxlLmV4cG9ydHMgPSBTdG9uZTsiXX0=