
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/Request.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'efb26uHANpNaKjH2eLDyuW1', 'Request');
// scripts/Request.js

"use strict";

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

var MoveHistory = require("./MoveHistory.js"); // 发送请求


var send_game_board_info = function send_game_board_info(piecesArrArr, row, col, old_row, old_col, red_or_black, stone_type, websocket) {
  var arr = [];
  piecesArrArr.forEach(function (item) {
    arr.push.apply(arr, _toConsumableArray(item));
  }); // 移动请求数据

  var game_board_info = [];
  arr.forEach(function (item) {
    if (item) {
      game_board_info.push({
        s_t: item.m_stone_type,
        t_t: item.m_turn_type,
        r: item.m_row,
        c: item.m_col
      });
    }
  });
  var data = {
    data: game_board_info,
    move: {
      r_o_b: red_or_black,
      s_t: stone_type,
      r: row,
      c: col,
      o_r: old_row,
      o_c: old_col
    }
  }; // console.log(data, JSON.stringify(data));

  MoveHistory.history.push(JSON.stringify(data));
  MoveHistory.pointer++; // var httpRequest = new XMLHttpRequest();
  // httpRequest.open('POST', 'http://192.168.2.141:8000', true);
  // // httpRequest.setRequestHeader("Content-type","application/json");
  // httpRequest.send(JSON.stringify(data));
  // httpRequest.onreadystatechange = function () {
  // 	if (httpRequest.readyState == 4 && httpRequest.status == 200) {
  // 		var json = httpRequest.responseText; //获取到服务端返回的数据
  // 		console.log(json);
  // 	}
  // };
  // console.log(data, websocket)
  // websocket.onopen = function() {

  websocket.send(JSON.stringify(data)); // }

  if (websocket.readyState === 1) {
    // console.log(websocket.onmessage)
    websocket.onmessage = function (evt) {
      console.log(evt);
    };

    console.log(websocket.readyState);
  } // websocket.addEventListener('open', function () {
  // });

};

module.exports = {
  send_game_board_info: send_game_board_info
};

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9zY3JpcHRzL1JlcXVlc3QuanMiXSwibmFtZXMiOlsiTW92ZUhpc3RvcnkiLCJyZXF1aXJlIiwic2VuZF9nYW1lX2JvYXJkX2luZm8iLCJwaWVjZXNBcnJBcnIiLCJyb3ciLCJjb2wiLCJvbGRfcm93Iiwib2xkX2NvbCIsInJlZF9vcl9ibGFjayIsInN0b25lX3R5cGUiLCJ3ZWJzb2NrZXQiLCJhcnIiLCJmb3JFYWNoIiwiaXRlbSIsInB1c2giLCJnYW1lX2JvYXJkX2luZm8iLCJzX3QiLCJtX3N0b25lX3R5cGUiLCJ0X3QiLCJtX3R1cm5fdHlwZSIsInIiLCJtX3JvdyIsImMiLCJtX2NvbCIsImRhdGEiLCJtb3ZlIiwicl9vX2IiLCJvX3IiLCJvX2MiLCJoaXN0b3J5IiwiSlNPTiIsInN0cmluZ2lmeSIsInBvaW50ZXIiLCJzZW5kIiwicmVhZHlTdGF0ZSIsIm9ubWVzc2FnZSIsImV2dCIsImNvbnNvbGUiLCJsb2ciLCJtb2R1bGUiLCJleHBvcnRzIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBSUEsV0FBVyxHQUFHQyxPQUFPLENBQUMsa0JBQUQsQ0FBekIsRUFFQTs7O0FBQ0EsSUFBSUMsb0JBQW9CLEdBQUcsU0FBdkJBLG9CQUF1QixDQUFTQyxZQUFULEVBQXVCQyxHQUF2QixFQUE0QkMsR0FBNUIsRUFBaUNDLE9BQWpDLEVBQTBDQyxPQUExQyxFQUFtREMsWUFBbkQsRUFBaUVDLFVBQWpFLEVBQTZFQyxTQUE3RSxFQUF3RjtBQUVsSCxNQUFNQyxHQUFHLEdBQUcsRUFBWjtBQUNBUixFQUFBQSxZQUFZLENBQUNTLE9BQWIsQ0FBcUIsVUFBQUMsSUFBSSxFQUFJO0FBQzVCRixJQUFBQSxHQUFHLENBQUNHLElBQUosT0FBQUgsR0FBRyxxQkFBU0UsSUFBVCxFQUFIO0FBQ0EsR0FGRCxFQUhrSCxDQU9sSDs7QUFDQSxNQUFJRSxlQUFlLEdBQUcsRUFBdEI7QUFDQUosRUFBQUEsR0FBRyxDQUFDQyxPQUFKLENBQVksVUFBQUMsSUFBSSxFQUFJO0FBQ25CLFFBQUdBLElBQUgsRUFBUTtBQUNQRSxNQUFBQSxlQUFlLENBQUNELElBQWhCLENBQXFCO0FBQ3BCRSxRQUFBQSxHQUFHLEVBQUVILElBQUksQ0FBQ0ksWUFEVTtBQUVwQkMsUUFBQUEsR0FBRyxFQUFFTCxJQUFJLENBQUNNLFdBRlU7QUFHcEJDLFFBQUFBLENBQUMsRUFBRVAsSUFBSSxDQUFDUSxLQUhZO0FBSXBCQyxRQUFBQSxDQUFDLEVBQUVULElBQUksQ0FBQ1U7QUFKWSxPQUFyQjtBQU1BO0FBQ0QsR0FURDtBQVdBLE1BQU1DLElBQUksR0FBRztBQUNaQSxJQUFBQSxJQUFJLEVBQUVULGVBRE07QUFFWlUsSUFBQUEsSUFBSSxFQUFFO0FBQ0xDLE1BQUFBLEtBQUssRUFBRWxCLFlBREY7QUFFTFEsTUFBQUEsR0FBRyxFQUFFUCxVQUZBO0FBR0xXLE1BQUFBLENBQUMsRUFBRWhCLEdBSEU7QUFJTGtCLE1BQUFBLENBQUMsRUFBRWpCLEdBSkU7QUFLTHNCLE1BQUFBLEdBQUcsRUFBRXJCLE9BTEE7QUFNTHNCLE1BQUFBLEdBQUcsRUFBRXJCO0FBTkE7QUFGTSxHQUFiLENBcEJrSCxDQStCbEg7O0FBRUFQLEVBQUFBLFdBQVcsQ0FBQzZCLE9BQVosQ0FBb0JmLElBQXBCLENBQXlCZ0IsSUFBSSxDQUFDQyxTQUFMLENBQWVQLElBQWYsQ0FBekI7QUFDQXhCLEVBQUFBLFdBQVcsQ0FBQ2dDLE9BQVosR0FsQ2tILENBb0NsSDtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBRUE7O0FBRUF0QixFQUFBQSxTQUFTLENBQUN1QixJQUFWLENBQWVILElBQUksQ0FBQ0MsU0FBTCxDQUFlUCxJQUFmLENBQWYsRUFwRGtILENBcURsSDs7QUFFQSxNQUFHZCxTQUFTLENBQUN3QixVQUFWLEtBQXlCLENBQTVCLEVBQThCO0FBQzdCO0FBRUF4QixJQUFBQSxTQUFTLENBQUN5QixTQUFWLEdBQXNCLFVBQVNDLEdBQVQsRUFBYTtBQUVsQ0MsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlGLEdBQVo7QUFDQSxLQUhEOztBQUlBQyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWTVCLFNBQVMsQ0FBQ3dCLFVBQXRCO0FBQ0EsR0EvRGlILENBaUVsSDtBQUVBOztBQUdBLENBdEVEOztBQXdFQUssTUFBTSxDQUFDQyxPQUFQLEdBQWlCO0FBQ2J0QyxFQUFBQSxvQkFBb0IsRUFBRUE7QUFEVCxDQUFqQiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsidmFyIE1vdmVIaXN0b3J5ID0gcmVxdWlyZShcIi4vTW92ZUhpc3RvcnkuanNcIik7XG5cbi8vIOWPkemAgeivt+axglxudmFyIHNlbmRfZ2FtZV9ib2FyZF9pbmZvID0gZnVuY3Rpb24ocGllY2VzQXJyQXJyLCByb3csIGNvbCwgb2xkX3Jvdywgb2xkX2NvbCwgcmVkX29yX2JsYWNrLCBzdG9uZV90eXBlLCB3ZWJzb2NrZXQpIHtcblx0XG5cdGNvbnN0IGFyciA9IFtdXG5cdHBpZWNlc0FyckFyci5mb3JFYWNoKGl0ZW0gPT4ge1xuXHRcdGFyci5wdXNoKC4uLml0ZW0pXG5cdH0pXG5cdFxuXHQvLyDnp7vliqjor7fmsYLmlbDmja5cblx0dmFyIGdhbWVfYm9hcmRfaW5mbyA9IFtdXG5cdGFyci5mb3JFYWNoKGl0ZW0gPT4ge1xuXHRcdGlmKGl0ZW0pe1xuXHRcdFx0Z2FtZV9ib2FyZF9pbmZvLnB1c2goe1xuXHRcdFx0XHRzX3Q6IGl0ZW0ubV9zdG9uZV90eXBlLFxuXHRcdFx0XHR0X3Q6IGl0ZW0ubV90dXJuX3R5cGUsXG5cdFx0XHRcdHI6IGl0ZW0ubV9yb3csXG5cdFx0XHRcdGM6IGl0ZW0ubV9jb2xcblx0XHRcdH0pXG5cdFx0fVxuXHR9KVxuXHRcblx0Y29uc3QgZGF0YSA9IHtcblx0XHRkYXRhOiBnYW1lX2JvYXJkX2luZm8sXG5cdFx0bW92ZToge1xuXHRcdFx0cl9vX2I6IHJlZF9vcl9ibGFjayxcblx0XHRcdHNfdDogc3RvbmVfdHlwZSxcblx0XHRcdHI6IHJvdyxcblx0XHRcdGM6IGNvbCxcblx0XHRcdG9fcjogb2xkX3Jvdyxcblx0XHRcdG9fYzogb2xkX2NvbCxcblx0XHR9XG5cdH1cblx0Ly8gY29uc29sZS5sb2coZGF0YSwgSlNPTi5zdHJpbmdpZnkoZGF0YSkpO1xuXHRcblx0TW92ZUhpc3RvcnkuaGlzdG9yeS5wdXNoKEpTT04uc3RyaW5naWZ5KGRhdGEpKTtcblx0TW92ZUhpc3RvcnkucG9pbnRlcisrO1xuXHRcblx0Ly8gdmFyIGh0dHBSZXF1ZXN0ID0gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XG5cdC8vIGh0dHBSZXF1ZXN0Lm9wZW4oJ1BPU1QnLCAnaHR0cDovLzE5Mi4xNjguMi4xNDE6ODAwMCcsIHRydWUpO1xuXHQvLyAvLyBodHRwUmVxdWVzdC5zZXRSZXF1ZXN0SGVhZGVyKFwiQ29udGVudC10eXBlXCIsXCJhcHBsaWNhdGlvbi9qc29uXCIpO1xuXHQvLyBodHRwUmVxdWVzdC5zZW5kKEpTT04uc3RyaW5naWZ5KGRhdGEpKTtcblx0XG5cdC8vIGh0dHBSZXF1ZXN0Lm9ucmVhZHlzdGF0ZWNoYW5nZSA9IGZ1bmN0aW9uICgpIHtcblx0Ly8gXHRpZiAoaHR0cFJlcXVlc3QucmVhZHlTdGF0ZSA9PSA0ICYmIGh0dHBSZXF1ZXN0LnN0YXR1cyA9PSAyMDApIHtcblx0Ly8gXHRcdHZhciBqc29uID0gaHR0cFJlcXVlc3QucmVzcG9uc2VUZXh0OyAvL+iOt+WPluWIsOacjeWKoeerr+i/lOWbnueahOaVsOaNrlxuXHQvLyBcdFx0Y29uc29sZS5sb2coanNvbik7XG5cdC8vIFx0fVxuXHQvLyB9O1xuXHRcblx0Ly8gY29uc29sZS5sb2coZGF0YSwgd2Vic29ja2V0KVxuXHRcblx0Ly8gd2Vic29ja2V0Lm9ub3BlbiA9IGZ1bmN0aW9uKCkge1xuXHRcdFxuXHR3ZWJzb2NrZXQuc2VuZChKU09OLnN0cmluZ2lmeShkYXRhKSk7XG5cdC8vIH1cblx0XG5cdGlmKHdlYnNvY2tldC5yZWFkeVN0YXRlID09PSAxKXtcblx0XHQvLyBjb25zb2xlLmxvZyh3ZWJzb2NrZXQub25tZXNzYWdlKVxuXHRcdFxuXHRcdHdlYnNvY2tldC5vbm1lc3NhZ2UgPSBmdW5jdGlvbihldnQpe1xuXHRcdFxuXHRcdFx0Y29uc29sZS5sb2coZXZ0KVxuXHRcdH1cblx0XHRjb25zb2xlLmxvZyh3ZWJzb2NrZXQucmVhZHlTdGF0ZSlcblx0fVxuXHRcblx0Ly8gd2Vic29ja2V0LmFkZEV2ZW50TGlzdGVuZXIoJ29wZW4nLCBmdW5jdGlvbiAoKSB7XG5cdFx0XG5cdC8vIH0pO1xuXHRcdFxuXHRcbn1cblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gICAgc2VuZF9nYW1lX2JvYXJkX2luZm86IHNlbmRfZ2FtZV9ib2FyZF9pbmZvXG59XG4iXX0=