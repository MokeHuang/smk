
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/GameBoard.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '1c684KaTNJHgJr7+0e0Eb0M', 'GameBoard');
// scripts/GameBoard.js

"use strict";

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

/**
 * 功能：游戏棋盘相关逻辑
 */
var Constant = require('./Constant.js');

var Stone = require('./Stone.js');

var MoveRule = require("./MoveRule.js");

var Request = require("./Request.js");

var MoveHistory = require("./MoveHistory.js");

var getName = function getName() {
  console.log(123);
}; //


cc.Class({
  "extends": cc.Component,
  properties: {
    //图集资源，用于初始化棋子prefab
    piecesAtlas: {
      "default": null,
      type: cc.SpriteAtlas
    },
    //棋子prefab
    piecePrefab: {
      "default": null,
      type: cc.Prefab
    },
    //可走点prefab
    dotPrefab: {
      "default": null,
      type: cc.Prefab
    },
    //移动前后标识prefab
    boxPrefab: {
      "default": null,
      type: cc.Prefab
    },
    //移动前后标识prefab
    eatPrefab: {
      "default": null,
      type: cc.Prefab
    },
    //游戏结束prefab
    gameOverPrefab: {
      "default": null,
      type: cc.Prefab
    },
    //将军prefab
    killPrefab: {
      "default": null,
      type: cc.Prefab
    },
    //二维数组存储棋子数据
    piecesArrArr: [],
    //是否获胜
    isWin: null,
    //是否轮到我下棋了
    isMyTurn: true,
    //旋转角度	180或0
    rotate: 180,
    //自己点击的棋子
    m_cur_click_stone: null,
    //红黑走棋对换
    red_or_black: Constant.turn_type.red,
    //可移动点预制体集合
    can_move_dot_list: [],
    // 将帅位置	初始为将位置
    jiang_shuai_row: 9,
    jiang_shuai_col: 4,
    websocket: '',
    // 避免重复连接
    lockReconnect: false,
    //红黑方
    redLabel: '123456',
    blackLabel: '45613',
    time: cc.Label,
    countdown: 300,
    //    倒计时的时间 为10秒
    move: cc.Animation
  },
  update: function update() {
    var _this = this;

    this.websocket.onmessage = function (evt) {
      // console.log(evt.data);
      if (!evt.data) {// 初始棋子历史记录
        // this.send_game_board_info(this.piecesArrArr, 20, 20, 20, 20, Constant.turn_type.black, this.websocket);
      } else {
        _this.lookerStones(evt.data);
      }
    };
  },
  // 测试全局接口
  getName: function getName(name) {
    console.log(name);
  },
  //组件加载时，进行变量初始化操作
  onLoad: function onLoad() {
    this.fn_countdown();
    getName = this.getName;
    getName('这是一个全局函数，我的名字叫做沙摩柯！'); // 创建连接并初始化棋子
    // this.getwebsocket()
    //初始化32颗棋子

    this.init32Stones(); // 初始化点击事件 求和 认输 悔棋 重开

    var self = this;
    cc.find("Canvas/spr_board_bg/retract").on(cc.Node.EventType.TOUCH_START, function (e) {
      // this.lookerStones();
      this.rotateGameBoard();
    }.bind(this));
    cc.find("button").on(cc.Node.EventType.TOUCH_START, function (e) {
      cc.find("stone").addComponent('StoneAnimControl');
      cc.log(cc.find("stone").getComponent(cc.Animation));
    }.bind(this));
    cc.find("Canvas/spr_board_bg/give_up").on(cc.Node.EventType.TOUCH_START, function (e) {
      console.log(self.isMyTurn);
      self.show_win(self.isMyTurn);
    }.bind(this));
    cc.find("Canvas/spr_board_bg/draw").on(cc.Node.EventType.TOUCH_START, function (e) {
      console.log('和棋');
      self.isWin = 2;
      this.countdown = 0;
      var gameOverPrefab = cc.instantiate(this.gameOverPrefab);
      console.log(this.gameOverPrefab);
      gameOverPrefab.setPosition(4 * Constant.cell_size - Constant.left_bottom_pos.len_x, 4.5 * Constant.cell_size - Constant.left_bottom_pos.len_y);
      this.node.addChild(gameOverPrefab);
      gameOverPrefab.runAction(cc.fadeTo(2));
    }.bind(this));
    cc.find("Canvas/spr_board_bg/reopen").on(cc.Node.EventType.TOUCH_START, function (e) {
      console.log('重开');
      this.countdown = 300;
      this.isWin = null; //初始化棋子数组信息

      for (var row = 0; row <= 9; row++) {
        for (var col = 0; col <= 8; col++) {
          if (self.piecesArrArr[row][col]) {
            self.piecesArrArr[row][col].m_piecePrefab.removeFromParent();
            self.piecesArrArr[row][col] = null;
          }
        }
      }

      MoveHistory.history = [];
      self.clear_can_move_dot();
      self.red_or_black = Constant.turn_type.red;
      self.isMyTurn = true;
      self.init32Stones();
    }.bind(this)); //初始化点击事件

    this.node.on(cc.Node.EventType.TOUCH_START, function (e) {
      if (this.isWin !== null) {
        console.log('对弈结束，请重新开始');
        return;
      }

      this.red_or_black = this.isMyTurn ? Constant.turn_type.red : Constant.turn_type.black; //
      //判断是否有走棋的权限

      if (this.red_or_black === Constant.turn_type.red) {
        // this.checkUrl('uin')
        if (this.redLabel != '123456') {
          return;
        } else {// console.log(123456);
        }
      } else if (this.red_or_black === Constant.turn_type.black) {
        if (this.blackLabel != '45613') {
          return;
        } else {// console.log(45613);
        }
      } //


      var click_info = this.get_select_row_col_by_click(e);
      var row = click_info.row;
      var col = click_info.col; //

      if (row < 0 || row > 9 || col < 0 || col > 8) {
        return;
      } else {
        var click_stone = this.piecesArrArr[row][col]; //点中了一个棋子

        if (click_stone) {
          //点了红旗，切换当前选中的棋子
          // if(click_stone.m_turn_type === Constant.turn_type.red){
          if (click_stone.m_turn_type === this.red_or_black) {
            //
            this.select_one_stone(click_stone);
          } //点了黑棋，1.如果当前没有选中棋子，则报错 2.选中了棋子，则试图吃掉当前的黑棋
          else {
              if (!this.m_cur_click_stone) {
                console.log('轮到' + (this.red_or_black ? 'black' : 'red') + '走棋！');
              } else {
                //试图去吃黑色棋子 this.m_cur_click_stone
                if (MoveRule.canMove(this, row, col)) {
                  this.kill_stone(row, col);
                }
              }
            }
        } //选中棋子后，又选择了一个空位置
        else {
            if (!this.m_cur_click_stone) {} else {
              if (MoveRule.canMove(this, row, col)) {
                this.move_stone(row, col);
              }
            }
          }
      }
    }.bind(this), this);
  },
  //旋转棋盘
  rotateGameBoard: function rotateGameBoard() {
    var _this2 = this;

    this.node.runAction(cc.rotateTo(0, this.rotate, this.rotate));
    this.node.children.forEach(function (item) {
      item.runAction(cc.rotateTo(0, _this2.rotate, _this2.rotate));
    });
    this.rotate = this.rotate == 180 ? 0 : 180;
  },
  fn_countdown: function fn_countdown() {
    this.time.string = 300; //  场景文本框为 显示10

    this.countdown = 300;

    if (this.countdown >= 0) {
      this.schedule(function () {
        // 计时器将每隔 1s 执行一次。
        this.DoSomething();
      }, 1);
    }
  },
  DoSomething: function DoSomething() {
    // 倒计时算法
    if (this.countdown >= 1) {
      this.countdown = this.countdown - 1;
      this.time.string = this.countdown; //场景中文本框显示
    } else {
      this.show_win(!this.red_or_black);
    }
  },
  //根据点击点获取点击的行列
  get_select_row_col_by_click: function get_select_row_col_by_click(e) {
    var pos = this.node.convertToNodeSpaceAR(e.getLocation());
    var row = Math.floor((pos.y + Constant.left_bottom_pos.len_y + Constant.cell_size * 0.5) / Constant.cell_size);
    var col = Math.floor((pos.x + Constant.left_bottom_pos.len_x + Constant.cell_size * 0.5) / Constant.cell_size);
    return {
      row: row,
      col: col
    };
  },
  //选中一颗棋子后 显示可移动的点
  can_move_dot: function can_move_dot() {
    for (var r = 0; r < 10; r++) {
      for (var c = 0; c < 9; c++) {
        if (MoveRule.canMove(this, r, c)) {
          var x = c * Constant.cell_size - Constant.left_bottom_pos.len_x;
          var y = r * Constant.cell_size - Constant.left_bottom_pos.len_y; //创建可移动dot预制体 并存储

          var dotPrefab = cc.instantiate(this.dotPrefab);
          dotPrefab.setPosition(x, y);
          this.node.addChild(dotPrefab);
          this.can_move_dot_list.push(dotPrefab);
        }
      }
    }
  },
  //清除可移动点dot 移动前后标记box 传参
  clear_can_move_dot: function clear_can_move_dot(no_box) {
    if (this.can_move_dot_list.length === 0) return; // 第一个为box则不清除，则0，1都为box不清除，否在全部清除

    if (this.can_move_dot_list[0].name === no_box) {
      this.can_move_dot_list.slice(2).forEach(function (item) {
        item.removeFromParent();
      });
      this.can_move_dot_list = this.can_move_dot_list.slice(0, 2);
    } else {
      this.can_move_dot_list.forEach(function (item) {
        item.removeFromParent();
      });
      this.can_move_dot_list = [];
    }
  },
  // 记录移动前后棋子的位置
  move_front_back: function move_front_back(row, col, old_row, old_col) {
    var x = col * Constant.cell_size - Constant.left_bottom_pos.len_x;
    var y = row * Constant.cell_size - Constant.left_bottom_pos.len_y;

    for (var i = 0; i < 2; i++) {
      var boxPrefab = cc.instantiate(this.boxPrefab);
      boxPrefab.setPosition(x, y);
      this.node.addChild(boxPrefab);
      this.can_move_dot_list.push(boxPrefab);
      x = old_col * Constant.cell_size - Constant.left_bottom_pos.len_x;
      y = old_row * Constant.cell_size - Constant.left_bottom_pos.len_y;
    }
  },
  show_win: function show_win(turn_type) {
    // 胜利条件判断
    if (turn_type) {
      console.log('黑方胜利！！！');
      this.isWin = Constant.turn_type.black;
    } else {
      console.log('红方胜利！！！');
      this.isWin = Constant.turn_type.red;
    }

    this.countdown = 0;
    var gameOverPrefab = cc.instantiate(this.gameOverPrefab);
    gameOverPrefab.setPosition(4 * Constant.cell_size - Constant.left_bottom_pos.len_x, 4.5 * Constant.cell_size - Constant.left_bottom_pos.len_y);
    this.node.addChild(gameOverPrefab);
    gameOverPrefab.runAction(cc.fadeTo(2));
  },
  // 将帅能移动位置
  fn_jiang_shuai_can_move: function fn_jiang_shuai_can_move() {
    // 存储将或帅能走的位置
    var jiang_shuai_can_move = new Set(); // 赋予当前点击对象为将或帅

    this.m_cur_click_stone = this.piecesArrArr[this.jiang_shuai_row][this.jiang_shuai_col]; // 添加将帅自己的位置

    jiang_shuai_can_move.add('{"row":' + this.jiang_shuai_row + ',' + '"col":' + this.jiang_shuai_col + '}');

    for (var r = 0; r < 10; r++) {
      for (var c = 3; c <= 5; c++) {
        // 跳过九宫格外的其他位置 记录将或帅位置
        r = r === 3 ? 7 : r; // 总为移动方将帅位置

        if (this.piecesArrArr[r][c] && this.piecesArrArr[r][c].m_stone_type === 6 && this.piecesArrArr[r][c].m_turn_type === this.red_or_black) {
          this.jiang_shuai_row = r;
          this.jiang_shuai_col = c;
        } // 判断将帅可移动的位置
        //      if(MoveRule.canMove(this, r, c)){
        // jiang_shuai_can_move.add('{"row":' + r + ',' + '"col":' + c + '}');
        //      }

      }
    }

    return jiang_shuai_can_move;
  },
  // 本方棋子的攻击范围
  fn_m_attack_scope: function fn_m_attack_scope(old_jiang_shuai_row, old_jiang_shuai_col) {
    var _this3 = this;

    var m_all_can_move = new Set(); // 本方所有棋子能走的位置

    var arr = [];
    this.piecesArrArr.forEach(function (item) {
      arr.push.apply(arr, _toConsumableArray(item));
    });
    arr.forEach(function (item) {
      // 本方
      if (item && item.m_turn_type === _this3.red_or_black) {
        _this3.m_cur_click_stone = item;

        for (var r = 0; r < 10; r++) {
          for (var c = 0; c < 9; c++) {
            // 本方所有棋子能走的位置
            if (MoveRule.canMove(_this3, r, c)) {
              if (_this3.m_cur_click_stone.m_stone_type === 4) {
                // 炮 特殊，需要隔子
                if (old_jiang_shuai_row === r && old_jiang_shuai_col === c) {
                  if (MoveRule.get_stone_num_between_row_col(_this3, _this3.m_cur_click_stone.m_row, _this3.m_cur_click_stone.m_col, old_jiang_shuai_row, old_jiang_shuai_col) === 1) {
                    if (_this3.m_cur_click_stone.m_row === old_jiang_shuai_row) {
                      if (!_this3.piecesArrArr[r][c + 1]) {
                        m_all_can_move.add('{"row":' + r + ',' + '"col":' + (c + 1) + '}');
                      }

                      if (!_this3.piecesArrArr[r][c - 1]) {
                        m_all_can_move.add('{"row":' + r + ',' + '"col":' + (c - 1) + '}');
                      }
                    }

                    if (_this3.m_cur_click_stone.m_col === old_jiang_shuai_col) {
                      if (r + 1 <= 9 && !_this3.piecesArrArr[r + 1][c]) {
                        m_all_can_move.add('{"row":' + (r + 1) + ',' + '"col":' + c + '}');
                      }

                      if (r - 1 >= 0 && !_this3.piecesArrArr[r - 1][c]) {
                        m_all_can_move.add('{"row":' + (r - 1) + ',' + '"col":' + c + '}');
                      }
                    }

                    m_all_can_move.add('{"row":' + r + ',' + '"col":' + c + '}');
                  }
                }
              } else {
                m_all_can_move.add('{"row":' + r + ',' + '"col":' + c + '}');
              }
            }
          }
        }
      }
    });
    return m_all_can_move;
  },
  // 将军	// 绝杀
  final_hit: function final_hit() {
    var temp = this.m_cur_click_stone; // 存储本方全部子能移动的位置 先

    var m_all_can_move = this.fn_m_attack_scope(this.jiang_shuai_row, this.jiang_shuai_col); // 存储将或帅能移动的位置 后

    var jiang_shuai_can_move = this.fn_jiang_shuai_can_move();
    this.m_cur_click_stone = temp;
    var size = jiang_shuai_can_move.size; // 清除当前将帅的当前点击

    jiang_shuai_can_move.forEach(function (item) {
      // 判断将帅可移动的位置 是否在 本方所有棋子可移动位置范围内
      if (m_all_can_move.has(item)) {
        jiang_shuai_can_move["delete"](item);
      }
    });

    if (size !== jiang_shuai_can_move.size) {
      console.log('将军'); // 动画

      var killPrefab = cc.instantiate(this.killPrefab);
      killPrefab.setPosition(4 * Constant.cell_size - Constant.left_bottom_pos.len_x, 4.5 * Constant.cell_size - Constant.left_bottom_pos.len_y);
      this.node.addChild(killPrefab);
      killPrefab.runAction(cc.fadeTo(2));
      setTimeout(function () {
        killPrefab.removeFromParent();
      }, 2000);
    }

    for (var i = 0; i < 10; i++) {
      if (this.piecesArrArr[i][this.jiang_shuai_col] && this.piecesArrArr[i][this.jiang_shuai_col].m_stone_type === 6 && this.piecesArrArr[i][this.jiang_shuai_col].m_row !== this.jiang_shuai_row) {
        if (MoveRule.get_stone_num_between_row_col(this, i, this.jiang_shuai_col, this.jiang_shuai_row, this.jiang_shuai_col) === 0) {
          this.show_win(!this.red_or_black);
          return;
        }
      }
    }
  },
  //选中一颗棋子
  select_one_stone: function select_one_stone(click_stone) {
    if (this.can_move_dot_list) {
      this.clear_can_move_dot('box');
    }

    if (this.m_cur_click_stone) {
      var pre_prefab = this.m_cur_click_stone.m_piecePrefab;
      pre_prefab.stopAllActions();
      pre_prefab.scale = 1;
    } //刷新新的棋子


    this.m_cur_click_stone = click_stone;
    var prefab = this.m_cur_click_stone.m_piecePrefab;
    prefab.stopAllActions();
    prefab.scale = 1;
    prefab.runAction(cc.repeatForever(cc.sequence(cc.scaleTo(0.5, 0.8), cc.scaleTo(0.5, 1.0)))); //判断可移动点

    this.can_move_dot();
  },
  //杀死棋子
  kill_stone: function kill_stone(row, col) {
    var _this4 = this;

    // 棋子移动动画
    var mySprite = this.m_cur_click_stone.m_piecePrefab;
    var moveTo = cc.moveTo(0.2, col * Constant.cell_size - Constant.left_bottom_pos.len_x, row * Constant.cell_size - Constant.left_bottom_pos.len_y);
    mySprite.runAction(moveTo); // 定时器 棋子移动完后再进行下一步操作

    setTimeout(function () {
      //1.黑棋被吃掉
      var eatBlackStone = _this4.piecesArrArr[row][col];
      eatBlackStone.m_is_dead = true;
      eatBlackStone.m_piecePrefab.removeFromParent(); //2.存的的红棋的位置置空

      _this4.piecesArrArr[_this4.m_cur_click_stone.m_row][_this4.m_cur_click_stone.m_col] = null;
      var old_row = _this4.m_cur_click_stone.m_row;
      var old_col = _this4.m_cur_click_stone.m_col; //3.走棋后修改红旗属性

      _this4.m_cur_click_stone.m_row = row;
      _this4.m_cur_click_stone.m_col = col; //4.修改红旗新的UI位置

      var x = col * Constant.cell_size - Constant.left_bottom_pos.len_x;
      var y = row * Constant.cell_size - Constant.left_bottom_pos.len_y;

      _this4.m_cur_click_stone.m_piecePrefab.setPosition(x, y); //5.刷新存储


      _this4.piecesArrArr[row][col] = _this4.m_cur_click_stone; // 向服务器发送走棋记录

      _this4.send_game_board_info(_this4.piecesArrArr, row, col, old_row, old_col, _this4.red_or_black, _this4.m_cur_click_stone.m_stone_type, _this4.websocket); //6.走完棋后设置当前未选中棋子


      var prefab = _this4.m_cur_click_stone.m_piecePrefab;
      prefab.stopAllActions();
      prefab.scale = 1;
      _this4.m_cur_click_stone = null; //7.轮到对方走棋

      _this4.isMyTurn = !_this4.isMyTurn; //
      // console.log('吃!'); 动画

      var eatPrefab = cc.instantiate(_this4.eatPrefab);
      eatPrefab.setPosition(4 * Constant.cell_size - Constant.left_bottom_pos.len_x, 4.5 * Constant.cell_size - Constant.left_bottom_pos.len_y);

      _this4.node.addChild(eatPrefab);

      eatPrefab.runAction(cc.fadeTo(2));
      setTimeout(function () {
        eatPrefab.removeFromParent();
      }, 2000); // 胜利条件 将帅被吃

      if (eatBlackStone.m_stone_type === Constant.stone_type.jiang) {
        _this4.show_win(!eatBlackStone.m_turn_type);
      } //清除可移动点的预制体


      _this4.clear_can_move_dot(); // 标记移动前后的位置


      _this4.move_front_back(row, col, old_row, old_col); // 将军 绝杀


      _this4.final_hit();

      _this4.countdown = 300;
    }, 200);
  },
  //移动棋子
  move_stone: function move_stone(row, col) {
    var _this5 = this;

    // 棋子移动动画
    var mySprite = this.m_cur_click_stone.m_piecePrefab;
    var moveTo = cc.moveTo(0.3, col * Constant.cell_size - Constant.left_bottom_pos.len_x, row * Constant.cell_size - Constant.left_bottom_pos.len_y);
    mySprite.runAction(moveTo); // 定时器 棋子移动完后再进行下一步操作

    setTimeout(function () {
      //1.清理原来位置
      var old_row = _this5.m_cur_click_stone.m_row;
      var old_col = _this5.m_cur_click_stone.m_col;
      _this5.piecesArrArr[old_row][old_col] = null; //2.设置新的数据

      _this5.m_cur_click_stone.m_row = row;
      _this5.m_cur_click_stone.m_col = col;
      _this5.piecesArrArr[row][col] = _this5.m_cur_click_stone; //3.更新位置

      var x = col * Constant.cell_size - Constant.left_bottom_pos.len_x;
      var y = row * Constant.cell_size - Constant.left_bottom_pos.len_y;

      _this5.m_cur_click_stone.m_piecePrefab.setPosition(x, y); // 向服务器发送走棋记录


      _this5.send_game_board_info(_this5.piecesArrArr, row, col, old_row, old_col, _this5.red_or_black, _this5.m_cur_click_stone.m_stone_type, _this5.websocket); //4.走完棋子停止动作


      var prefab = _this5.m_cur_click_stone.m_piecePrefab;
      prefab.stopAllActions();
      prefab.scale = 1;
      _this5.m_cur_click_stone = null; //5.轮到对方走棋

      _this5.isMyTurn = !_this5.isMyTurn; //
      //清除可移动点的预制体

      _this5.clear_can_move_dot(); // 标记移动前后的位置


      _this5.move_front_back(row, col, old_row, old_col); // 将军 绝杀


      _this5.final_hit();

      _this5.countdown = 300;
    }, 301);
  },
  //初始化32颗棋子
  init32Stones: function init32Stones() {
    //初始化棋子数组信息
    for (var row = 0; row <= 9; row++) {
      this.piecesArrArr[row] = [];

      for (var col = 0; col <= 8; col++) {
        this.piecesArrArr[row][col] = null;
      }
    } //棋子初始化信息


    var game_board_init_info = Constant.game_board_init_info;

    for (var k in game_board_init_info) {
      var stone_info = game_board_init_info[k];
      var row = stone_info.row;
      var col = stone_info.col;
      var turn_type = stone_info.turn_type;
      var stone_type = stone_info.stone_type;
      var piecePrefab = this.createOnePieceByName(Constant.stone_res_config[turn_type][stone_type]); //创建一颗棋子

      var stone = new Stone(turn_type, stone_type, false, row, col, piecePrefab);
      var x = col * Constant.cell_size - Constant.left_bottom_pos.len_x;
      var y = row * Constant.cell_size - Constant.left_bottom_pos.len_y;
      stone.m_piecePrefab.setPosition(x, y);
      this.node.addChild(stone.m_piecePrefab); //存储棋子信息

      this.piecesArrArr[row][col] = stone;
    }
  },
  //初始化观看者棋子变化
  lookerStones: function lookerStones(data) {
    var game_board_info = JSON.parse(data); // if(MoveHistory.pointer < 1){
    // 	var game_board_info = JSON.parse(MoveHistory.history[0]);
    // } else {
    // 	MoveHistory.pointer--;
    // 	var game_board_info = JSON.parse(MoveHistory.history[MoveHistory.pointer]);
    // 	MoveHistory.history.pop();
    // }
    // console.log(game_board_info.move.r_o_b, game_board_info, this.isMyTurn);
    //初始化棋子数组信息

    for (var row = 0; row <= 9; row++) {
      // this.piecesArrArr[row] = [];
      for (var col = 0; col <= 8; col++) {
        if (this.piecesArrArr[row][col]) {
          this.piecesArrArr[row][col].m_piecePrefab.removeFromParent();
          this.piecesArrArr[row][col] = null;
        }
      }
    }

    this.clear_can_move_dot();
    this.move_front_back(game_board_info.move.r, game_board_info.move.c, game_board_info.move.o_r, game_board_info.move.o_c);
    this.isMyTurn = game_board_info.move.r_o_b;
    this.red_or_black = this.isMyTurn ? Constant.turn_type.red : Constant.turn_type.black; //棋子初始化信息

    var game_board_init_info = game_board_info.data;

    for (var k in game_board_init_info) {
      var stone_info = game_board_init_info[k];
      var row = stone_info.r;
      var col = stone_info.c;
      var turn_type = stone_info.t_t;
      var stone_type = stone_info.s_t;
      var piecePrefab = this.createOnePieceByName(Constant.stone_res_config[turn_type][stone_type]); //创建一颗棋子

      var stone = new Stone(turn_type, stone_type, false, row, col, piecePrefab); //棋盘旋转后每次渲染旋转棋子

      if (this.rotate == 0) {
        stone.m_piecePrefab.is3DNode = true;
        stone.m_piecePrefab.eulerAngles = cc.v3(180, 180, 0); // stone.m_piecePrefab.runAction(cc.rotateTo(0, 180, 180))
      }

      var x = col * Constant.cell_size - Constant.left_bottom_pos.len_x;
      var y = row * Constant.cell_size - Constant.left_bottom_pos.len_y;
      stone.m_piecePrefab.setPosition(x, y); //初始化倒计时

      this.countdown = 300;
      this.node.addChild(stone.m_piecePrefab); //存储棋子信息

      this.piecesArrArr[row][col] = stone;
    }
  },
  //根据棋子名称创建一颗棋子
  createOnePieceByName: function createOnePieceByName(pieceName) {
    var piece = cc.instantiate(this.piecePrefab);
    piece.getComponent(cc.Sprite).spriteFrame = this.piecesAtlas.getSpriteFrame(pieceName);
    return piece;
  },
  // 发送请求
  send_game_board_info: function send_game_board_info(piecesArrArr, row, col, old_row, old_col, red_or_black, stone_type, websocket) {
    var arr = [];
    piecesArrArr.forEach(function (item) {
      arr.push.apply(arr, _toConsumableArray(item));
    }); // 移动请求数据

    var game_board_info = [];
    arr.forEach(function (item) {
      if (item) {
        game_board_info.push({
          s_t: item.m_stone_type,
          t_t: item.m_turn_type,
          r: item.m_row,
          c: item.m_col
        });
      }
    });
    var data = {
      data: game_board_info,
      move: {
        r_o_b: red_or_black,
        s_t: stone_type,
        r: row,
        c: col,
        o_r: old_row,
        o_c: old_col
      }
    }; // console.log(this.websocket)

    this.websocket.send(JSON.stringify(data));
  },
  // url编码
  checkUrl: function checkUrl(searchStr) {
    function getQueryString(name) {
      var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)');
      var r = window.location.search.substr(1).match(reg); // var r = 'roomid=4683456&uin=45613'.match(reg);

      if (r != null) return unescape(r[2]);
      return '';
    }

    return encodeURIComponent(getQueryString(searchStr));
  },
  getwebsocket: function getwebsocket() {
    var _this6 = this;

    //新建websocket的函数 页面初始化 断开连接时重新调用
    var roomid = this.checkUrl('roomid') || '4683456';
    var uin = this.checkUrl('uin') || '45613';
    var wsUrl = 'ws://192.168.2.141:8010/ws?roomid=' + roomid + '&uin=' + uin;
    this.websocket = new WebSocket(wsUrl);

    this.websocket.onopen = function (event) {
      _this6.init32Stones();
    }; // this.websocket.onclose = (event) => {
    // 	//console.log('websocket服务关闭了');
    // };


    this.websocket.onmessage = function (event) {
      console.log(event.data);

      if (!evt.data) {// 初始棋子历史记录
        // this.send_game_board_info(this.piecesArrArr, 20, 20, 20, 20, Constant.turn_type.black, this.websocket);
      } else {
        console.log(evt.data);
        this.lookerStones(evt.data);
      }
    };
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9zY3JpcHRzL0dhbWVCb2FyZC5qcyJdLCJuYW1lcyI6WyJDb25zdGFudCIsInJlcXVpcmUiLCJTdG9uZSIsIk1vdmVSdWxlIiwiUmVxdWVzdCIsIk1vdmVIaXN0b3J5IiwiZ2V0TmFtZSIsImNvbnNvbGUiLCJsb2ciLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInBpZWNlc0F0bGFzIiwidHlwZSIsIlNwcml0ZUF0bGFzIiwicGllY2VQcmVmYWIiLCJQcmVmYWIiLCJkb3RQcmVmYWIiLCJib3hQcmVmYWIiLCJlYXRQcmVmYWIiLCJnYW1lT3ZlclByZWZhYiIsImtpbGxQcmVmYWIiLCJwaWVjZXNBcnJBcnIiLCJpc1dpbiIsImlzTXlUdXJuIiwicm90YXRlIiwibV9jdXJfY2xpY2tfc3RvbmUiLCJyZWRfb3JfYmxhY2siLCJ0dXJuX3R5cGUiLCJyZWQiLCJjYW5fbW92ZV9kb3RfbGlzdCIsImppYW5nX3NodWFpX3JvdyIsImppYW5nX3NodWFpX2NvbCIsIndlYnNvY2tldCIsImxvY2tSZWNvbm5lY3QiLCJyZWRMYWJlbCIsImJsYWNrTGFiZWwiLCJ0aW1lIiwiTGFiZWwiLCJjb3VudGRvd24iLCJtb3ZlIiwiQW5pbWF0aW9uIiwidXBkYXRlIiwib25tZXNzYWdlIiwiZXZ0IiwiZGF0YSIsImxvb2tlclN0b25lcyIsIm5hbWUiLCJvbkxvYWQiLCJmbl9jb3VudGRvd24iLCJpbml0MzJTdG9uZXMiLCJzZWxmIiwiZmluZCIsIm9uIiwiTm9kZSIsIkV2ZW50VHlwZSIsIlRPVUNIX1NUQVJUIiwiZSIsInJvdGF0ZUdhbWVCb2FyZCIsImJpbmQiLCJhZGRDb21wb25lbnQiLCJnZXRDb21wb25lbnQiLCJzaG93X3dpbiIsImluc3RhbnRpYXRlIiwic2V0UG9zaXRpb24iLCJjZWxsX3NpemUiLCJsZWZ0X2JvdHRvbV9wb3MiLCJsZW5feCIsImxlbl95Iiwibm9kZSIsImFkZENoaWxkIiwicnVuQWN0aW9uIiwiZmFkZVRvIiwicm93IiwiY29sIiwibV9waWVjZVByZWZhYiIsInJlbW92ZUZyb21QYXJlbnQiLCJoaXN0b3J5IiwiY2xlYXJfY2FuX21vdmVfZG90IiwiYmxhY2siLCJjbGlja19pbmZvIiwiZ2V0X3NlbGVjdF9yb3dfY29sX2J5X2NsaWNrIiwiY2xpY2tfc3RvbmUiLCJtX3R1cm5fdHlwZSIsInNlbGVjdF9vbmVfc3RvbmUiLCJjYW5Nb3ZlIiwia2lsbF9zdG9uZSIsIm1vdmVfc3RvbmUiLCJyb3RhdGVUbyIsImNoaWxkcmVuIiwiZm9yRWFjaCIsIml0ZW0iLCJzdHJpbmciLCJzY2hlZHVsZSIsIkRvU29tZXRoaW5nIiwicG9zIiwiY29udmVydFRvTm9kZVNwYWNlQVIiLCJnZXRMb2NhdGlvbiIsIk1hdGgiLCJmbG9vciIsInkiLCJ4IiwiY2FuX21vdmVfZG90IiwiciIsImMiLCJwdXNoIiwibm9fYm94IiwibGVuZ3RoIiwic2xpY2UiLCJtb3ZlX2Zyb250X2JhY2siLCJvbGRfcm93Iiwib2xkX2NvbCIsImkiLCJmbl9qaWFuZ19zaHVhaV9jYW5fbW92ZSIsImppYW5nX3NodWFpX2Nhbl9tb3ZlIiwiU2V0IiwiYWRkIiwibV9zdG9uZV90eXBlIiwiZm5fbV9hdHRhY2tfc2NvcGUiLCJvbGRfamlhbmdfc2h1YWlfcm93Iiwib2xkX2ppYW5nX3NodWFpX2NvbCIsIm1fYWxsX2Nhbl9tb3ZlIiwiYXJyIiwiZ2V0X3N0b25lX251bV9iZXR3ZWVuX3Jvd19jb2wiLCJtX3JvdyIsIm1fY29sIiwiZmluYWxfaGl0IiwidGVtcCIsInNpemUiLCJoYXMiLCJzZXRUaW1lb3V0IiwicHJlX3ByZWZhYiIsInN0b3BBbGxBY3Rpb25zIiwic2NhbGUiLCJwcmVmYWIiLCJyZXBlYXRGb3JldmVyIiwic2VxdWVuY2UiLCJzY2FsZVRvIiwibXlTcHJpdGUiLCJtb3ZlVG8iLCJlYXRCbGFja1N0b25lIiwibV9pc19kZWFkIiwic2VuZF9nYW1lX2JvYXJkX2luZm8iLCJzdG9uZV90eXBlIiwiamlhbmciLCJnYW1lX2JvYXJkX2luaXRfaW5mbyIsImsiLCJzdG9uZV9pbmZvIiwiY3JlYXRlT25lUGllY2VCeU5hbWUiLCJzdG9uZV9yZXNfY29uZmlnIiwic3RvbmUiLCJnYW1lX2JvYXJkX2luZm8iLCJKU09OIiwicGFyc2UiLCJvX3IiLCJvX2MiLCJyX29fYiIsInRfdCIsInNfdCIsImlzM0ROb2RlIiwiZXVsZXJBbmdsZXMiLCJ2MyIsInBpZWNlTmFtZSIsInBpZWNlIiwiU3ByaXRlIiwic3ByaXRlRnJhbWUiLCJnZXRTcHJpdGVGcmFtZSIsInNlbmQiLCJzdHJpbmdpZnkiLCJjaGVja1VybCIsInNlYXJjaFN0ciIsImdldFF1ZXJ5U3RyaW5nIiwicmVnIiwiUmVnRXhwIiwid2luZG93IiwibG9jYXRpb24iLCJzZWFyY2giLCJzdWJzdHIiLCJtYXRjaCIsInVuZXNjYXBlIiwiZW5jb2RlVVJJQ29tcG9uZW50IiwiZ2V0d2Vic29ja2V0Iiwicm9vbWlkIiwidWluIiwid3NVcmwiLCJXZWJTb2NrZXQiLCJvbm9wZW4iLCJldmVudCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBOzs7QUFJQSxJQUFJQSxRQUFRLEdBQUdDLE9BQU8sQ0FBQyxlQUFELENBQXRCOztBQUNBLElBQUlDLEtBQUssR0FBR0QsT0FBTyxDQUFDLFlBQUQsQ0FBbkI7O0FBQ0EsSUFBSUUsUUFBUSxHQUFHRixPQUFPLENBQUMsZUFBRCxDQUF0Qjs7QUFDQSxJQUFJRyxPQUFPLEdBQUdILE9BQU8sQ0FBQyxjQUFELENBQXJCOztBQUNBLElBQUlJLFdBQVcsR0FBR0osT0FBTyxDQUFDLGtCQUFELENBQXpCOztBQUVBLElBQUlLLE9BQU8sR0FBRyxtQkFBWTtBQUN6QkMsRUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksR0FBWjtBQUNBLENBRkQsRUFLQTs7O0FBQ0FDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUVSO0FBQ0FDLElBQUFBLFdBQVcsRUFBRTtBQUNULGlCQUFTLElBREE7QUFFVEMsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0FBRkEsS0FITDtBQVFSO0FBQ0FDLElBQUFBLFdBQVcsRUFBQztBQUNSLGlCQUFTLElBREQ7QUFFUkYsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNRO0FBRkQsS0FUSjtBQWNSO0FBQ0FDLElBQUFBLFNBQVMsRUFBQztBQUNOLGlCQUFTLElBREg7QUFFTkosTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNRO0FBRkgsS0FmRjtBQW9CZDtBQUNBRSxJQUFBQSxTQUFTLEVBQUM7QUFDTixpQkFBUyxJQURIO0FBRU5MLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDUTtBQUZILEtBckJJO0FBMEJkO0FBQ0FHLElBQUFBLFNBQVMsRUFBQztBQUNOLGlCQUFTLElBREg7QUFFTk4sTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNRO0FBRkgsS0EzQkk7QUFnQ2Q7QUFDQUksSUFBQUEsY0FBYyxFQUFDO0FBQ1gsaUJBQVMsSUFERTtBQUVYUCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ1E7QUFGRSxLQWpDRDtBQXNDZDtBQUNBSyxJQUFBQSxVQUFVLEVBQUM7QUFDUCxpQkFBUyxJQURGO0FBRVBSLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDUTtBQUZGLEtBdkNHO0FBNENSO0FBQ0FNLElBQUFBLFlBQVksRUFBQyxFQTdDTDtBQStDZDtBQUNBQyxJQUFBQSxLQUFLLEVBQUUsSUFoRE87QUFrRFI7QUFDQUMsSUFBQUEsUUFBUSxFQUFFLElBbkRGO0FBcURkO0FBQ0FDLElBQUFBLE1BQU0sRUFBRSxHQXRETTtBQXdEUjtBQUNBQyxJQUFBQSxpQkFBaUIsRUFBRSxJQXpEWDtBQTJEZDtBQUNBQyxJQUFBQSxZQUFZLEVBQUU1QixRQUFRLENBQUM2QixTQUFULENBQW1CQyxHQTVEbkI7QUE4RFI7QUFDQUMsSUFBQUEsaUJBQWlCLEVBQUUsRUEvRFg7QUFpRWQ7QUFDQUMsSUFBQUEsZUFBZSxFQUFFLENBbEVIO0FBbUVkQyxJQUFBQSxlQUFlLEVBQUUsQ0FuRUg7QUFxRWRDLElBQUFBLFNBQVMsRUFBRSxFQXJFRztBQXNFZDtBQUNBQyxJQUFBQSxhQUFhLEVBQUUsS0F2RUQ7QUF5RWQ7QUFDQUMsSUFBQUEsUUFBUSxFQUFFLFFBMUVJO0FBMkVkQyxJQUFBQSxVQUFVLEVBQUUsT0EzRUU7QUE2RWRDLElBQUFBLElBQUksRUFBRTdCLEVBQUUsQ0FBQzhCLEtBN0VLO0FBOEVkQyxJQUFBQSxTQUFTLEVBQUUsR0E5RUc7QUE4RWM7QUFFNUJDLElBQUFBLElBQUksRUFBRWhDLEVBQUUsQ0FBQ2lDO0FBaEZLLEdBSFA7QUFzRlJDLEVBQUFBLE1BdEZRLG9CQXNGQztBQUFBOztBQUNSLFNBQUtULFNBQUwsQ0FBZVUsU0FBZixHQUEyQixVQUFDQyxHQUFELEVBQVM7QUFDbkM7QUFDQSxVQUFHLENBQUNBLEdBQUcsQ0FBQ0MsSUFBUixFQUFhLENBRVo7QUFDQTtBQUNBLE9BSkQsTUFLSztBQUVKLFFBQUEsS0FBSSxDQUFDQyxZQUFMLENBQWtCRixHQUFHLENBQUNDLElBQXRCO0FBQ0E7QUFDRCxLQVhEO0FBWUEsR0FuR087QUFvR1I7QUFDQXhDLEVBQUFBLE9BQU8sRUFBRSxpQkFBVTBDLElBQVYsRUFBZ0I7QUFDeEJ6QyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWXdDLElBQVo7QUFDQSxHQXZHTztBQXlHTDtBQUNBQyxFQUFBQSxNQTFHSyxvQkEwR0s7QUFFWixTQUFLQyxZQUFMO0FBRUc1QyxJQUFBQSxPQUFPLEdBQUcsS0FBS0EsT0FBZjtBQUNIQSxJQUFBQSxPQUFPLENBQUMscUJBQUQsQ0FBUCxDQUxZLENBT1o7QUFDQTtBQUVBOztBQUNBLFNBQUs2QyxZQUFMLEdBWFksQ0FhWjs7QUFDQSxRQUFNQyxJQUFJLEdBQUcsSUFBYjtBQUNBM0MsSUFBQUEsRUFBRSxDQUFDNEMsSUFBSCxDQUFRLDZCQUFSLEVBQXVDQyxFQUF2QyxDQUEwQzdDLEVBQUUsQ0FBQzhDLElBQUgsQ0FBUUMsU0FBUixDQUFrQkMsV0FBNUQsRUFBeUUsVUFBU0MsQ0FBVCxFQUFXO0FBRW5GO0FBRUEsV0FBS0MsZUFBTDtBQUdBLEtBUHdFLENBT3ZFQyxJQVB1RSxDQU9sRSxJQVBrRSxDQUF6RTtBQVNBbkQsSUFBQUEsRUFBRSxDQUFDNEMsSUFBSCxDQUFRLFFBQVIsRUFBa0JDLEVBQWxCLENBQXFCN0MsRUFBRSxDQUFDOEMsSUFBSCxDQUFRQyxTQUFSLENBQWtCQyxXQUF2QyxFQUFvRCxVQUFTQyxDQUFULEVBQVc7QUFDOURqRCxNQUFBQSxFQUFFLENBQUM0QyxJQUFILENBQVEsT0FBUixFQUFpQlEsWUFBakIsQ0FBOEIsa0JBQTlCO0FBQ0FwRCxNQUFBQSxFQUFFLENBQUNELEdBQUgsQ0FBT0MsRUFBRSxDQUFDNEMsSUFBSCxDQUFRLE9BQVIsRUFBaUJTLFlBQWpCLENBQThCckQsRUFBRSxDQUFDaUMsU0FBakMsQ0FBUDtBQUNBLEtBSG1ELENBR2xEa0IsSUFIa0QsQ0FHN0MsSUFINkMsQ0FBcEQ7QUFNQW5ELElBQUFBLEVBQUUsQ0FBQzRDLElBQUgsQ0FBUSw2QkFBUixFQUF1Q0MsRUFBdkMsQ0FBMEM3QyxFQUFFLENBQUM4QyxJQUFILENBQVFDLFNBQVIsQ0FBa0JDLFdBQTVELEVBQXlFLFVBQVNDLENBQVQsRUFBVztBQUNuRm5ELE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZNEMsSUFBSSxDQUFDM0IsUUFBakI7QUFDQTJCLE1BQUFBLElBQUksQ0FBQ1csUUFBTCxDQUFjWCxJQUFJLENBQUMzQixRQUFuQjtBQUNBLEtBSHdFLENBR3ZFbUMsSUFIdUUsQ0FHbEUsSUFIa0UsQ0FBekU7QUFLQW5ELElBQUFBLEVBQUUsQ0FBQzRDLElBQUgsQ0FBUSwwQkFBUixFQUFvQ0MsRUFBcEMsQ0FBdUM3QyxFQUFFLENBQUM4QyxJQUFILENBQVFDLFNBQVIsQ0FBa0JDLFdBQXpELEVBQXNFLFVBQVNDLENBQVQsRUFBVztBQUNoRm5ELE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLElBQVo7QUFDQTRDLE1BQUFBLElBQUksQ0FBQzVCLEtBQUwsR0FBYSxDQUFiO0FBQ0EsV0FBS2dCLFNBQUwsR0FBaUIsQ0FBakI7QUFDQSxVQUFJbkIsY0FBYyxHQUFHWixFQUFFLENBQUN1RCxXQUFILENBQWUsS0FBSzNDLGNBQXBCLENBQXJCO0FBQ0FkLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQUthLGNBQWpCO0FBQ0FBLE1BQUFBLGNBQWMsQ0FBQzRDLFdBQWYsQ0FBMkIsSUFBSWpFLFFBQVEsQ0FBQ2tFLFNBQWIsR0FBeUJsRSxRQUFRLENBQUNtRSxlQUFULENBQXlCQyxLQUE3RSxFQUNDLE1BQU1wRSxRQUFRLENBQUNrRSxTQUFmLEdBQTJCbEUsUUFBUSxDQUFDbUUsZUFBVCxDQUF5QkUsS0FEckQ7QUFFQSxXQUFLQyxJQUFMLENBQVVDLFFBQVYsQ0FBbUJsRCxjQUFuQjtBQUNBQSxNQUFBQSxjQUFjLENBQUNtRCxTQUFmLENBQXlCL0QsRUFBRSxDQUFDZ0UsTUFBSCxDQUFVLENBQVYsQ0FBekI7QUFDQSxLQVZxRSxDQVVwRWIsSUFWb0UsQ0FVL0QsSUFWK0QsQ0FBdEU7QUFZQW5ELElBQUFBLEVBQUUsQ0FBQzRDLElBQUgsQ0FBUSw0QkFBUixFQUFzQ0MsRUFBdEMsQ0FBeUM3QyxFQUFFLENBQUM4QyxJQUFILENBQVFDLFNBQVIsQ0FBa0JDLFdBQTNELEVBQXdFLFVBQVNDLENBQVQsRUFBVztBQUNsRm5ELE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLElBQVo7QUFDQSxXQUFLZ0MsU0FBTCxHQUFpQixHQUFqQjtBQUNBLFdBQUtoQixLQUFMLEdBQWEsSUFBYixDQUhrRixDQUlsRjs7QUFDQSxXQUFJLElBQUlrRCxHQUFHLEdBQUcsQ0FBZCxFQUFpQkEsR0FBRyxJQUFJLENBQXhCLEVBQTJCQSxHQUFHLEVBQTlCLEVBQWlDO0FBQzdCLGFBQUksSUFBSUMsR0FBRyxHQUFHLENBQWQsRUFBaUJBLEdBQUcsSUFBSSxDQUF4QixFQUEyQkEsR0FBRyxFQUE5QixFQUFpQztBQUNuQyxjQUFHdkIsSUFBSSxDQUFDN0IsWUFBTCxDQUFrQm1ELEdBQWxCLEVBQXVCQyxHQUF2QixDQUFILEVBQStCO0FBQzlCdkIsWUFBQUEsSUFBSSxDQUFDN0IsWUFBTCxDQUFrQm1ELEdBQWxCLEVBQXVCQyxHQUF2QixFQUE0QkMsYUFBNUIsQ0FBMENDLGdCQUExQztBQUNBekIsWUFBQUEsSUFBSSxDQUFDN0IsWUFBTCxDQUFrQm1ELEdBQWxCLEVBQXVCQyxHQUF2QixJQUE4QixJQUE5QjtBQUNBO0FBQ0U7QUFDSjs7QUFDRHRFLE1BQUFBLFdBQVcsQ0FBQ3lFLE9BQVosR0FBc0IsRUFBdEI7QUFDQTFCLE1BQUFBLElBQUksQ0FBQzJCLGtCQUFMO0FBQ0EzQixNQUFBQSxJQUFJLENBQUN4QixZQUFMLEdBQW9CNUIsUUFBUSxDQUFDNkIsU0FBVCxDQUFtQkMsR0FBdkM7QUFDQXNCLE1BQUFBLElBQUksQ0FBQzNCLFFBQUwsR0FBZ0IsSUFBaEI7QUFDQTJCLE1BQUFBLElBQUksQ0FBQ0QsWUFBTDtBQUNBLEtBbEJ1RSxDQWtCdEVTLElBbEJzRSxDQWtCakUsSUFsQmlFLENBQXhFLEVBL0NZLENBbUVOOztBQUNBLFNBQUtVLElBQUwsQ0FBVWhCLEVBQVYsQ0FBYTdDLEVBQUUsQ0FBQzhDLElBQUgsQ0FBUUMsU0FBUixDQUFrQkMsV0FBL0IsRUFBNEMsVUFBU0MsQ0FBVCxFQUFXO0FBRW5ELFVBQUcsS0FBS2xDLEtBQUwsS0FBZSxJQUFsQixFQUF1QjtBQUNuQmpCLFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFlBQVo7QUFDQTtBQUNIOztBQUVWLFdBQUtvQixZQUFMLEdBQW9CLEtBQUtILFFBQUwsR0FBZ0J6QixRQUFRLENBQUM2QixTQUFULENBQW1CQyxHQUFuQyxHQUF5QzlCLFFBQVEsQ0FBQzZCLFNBQVQsQ0FBbUJtRCxLQUFoRixDQVA0RCxDQU8wQjtBQUV0Rjs7QUFDQSxVQUFHLEtBQUtwRCxZQUFMLEtBQXNCNUIsUUFBUSxDQUFDNkIsU0FBVCxDQUFtQkMsR0FBNUMsRUFBZ0Q7QUFDL0M7QUFDQSxZQUFJLEtBQUtNLFFBQUwsSUFBaUIsUUFBckIsRUFBOEI7QUFDN0I7QUFDQSxTQUZELE1BRU8sQ0FDTjtBQUNBO0FBQ0QsT0FQRCxNQU9NLElBQUksS0FBS1IsWUFBTCxLQUFzQjVCLFFBQVEsQ0FBQzZCLFNBQVQsQ0FBbUJtRCxLQUE3QyxFQUFtRDtBQUN4RCxZQUFJLEtBQUszQyxVQUFMLElBQW1CLE9BQXZCLEVBQStCO0FBQzlCO0FBQ0EsU0FGRCxNQUVPLENBQ047QUFDQTtBQUNELE9BdkIyRCxDQTBCbkQ7OztBQUNBLFVBQUk0QyxVQUFVLEdBQUcsS0FBS0MsMkJBQUwsQ0FBaUN4QixDQUFqQyxDQUFqQjtBQUNBLFVBQUlnQixHQUFHLEdBQUdPLFVBQVUsQ0FBQ1AsR0FBckI7QUFDQSxVQUFJQyxHQUFHLEdBQUdNLFVBQVUsQ0FBQ04sR0FBckIsQ0E3Qm1ELENBK0JuRDs7QUFDQSxVQUFHRCxHQUFHLEdBQUcsQ0FBTixJQUFXQSxHQUFHLEdBQUcsQ0FBakIsSUFBc0JDLEdBQUcsR0FBRyxDQUE1QixJQUFpQ0EsR0FBRyxHQUFHLENBQTFDLEVBQTRDO0FBQ3hDO0FBQ0gsT0FGRCxNQUVLO0FBQ0QsWUFBSVEsV0FBVyxHQUFHLEtBQUs1RCxZQUFMLENBQWtCbUQsR0FBbEIsRUFBdUJDLEdBQXZCLENBQWxCLENBREMsQ0FHYjs7QUFDQSxZQUFHUSxXQUFILEVBQWU7QUFDZDtBQUNBO0FBQ0EsY0FBR0EsV0FBVyxDQUFDQyxXQUFaLEtBQTRCLEtBQUt4RCxZQUFwQyxFQUFpRDtBQUFFO0FBRWxELGlCQUFLeUQsZ0JBQUwsQ0FBc0JGLFdBQXRCO0FBRUEsV0FKRCxDQUtBO0FBTEEsZUFNSTtBQUVILGtCQUFHLENBQUMsS0FBS3hELGlCQUFULEVBQTJCO0FBRTFCcEIsZ0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFFBQVEsS0FBS29CLFlBQUwsR0FBb0IsT0FBcEIsR0FBOEIsS0FBdEMsSUFBK0MsS0FBM0Q7QUFFQSxlQUpELE1BSUs7QUFFSjtBQUNBLG9CQUFHekIsUUFBUSxDQUFDbUYsT0FBVCxDQUFpQixJQUFqQixFQUF1QlosR0FBdkIsRUFBNEJDLEdBQTVCLENBQUgsRUFBb0M7QUFDbkMsdUJBQUtZLFVBQUwsQ0FBZ0JiLEdBQWhCLEVBQXFCQyxHQUFyQjtBQUNBO0FBQ0Q7QUFDRDtBQUNELFNBdkJELENBd0JBO0FBeEJBLGFBeUJJO0FBQ0gsZ0JBQUcsQ0FBQyxLQUFLaEQsaUJBQVQsRUFBMkIsQ0FFMUIsQ0FGRCxNQUVLO0FBQ0osa0JBQUd4QixRQUFRLENBQUNtRixPQUFULENBQWlCLElBQWpCLEVBQXVCWixHQUF2QixFQUE0QkMsR0FBNUIsQ0FBSCxFQUFvQztBQUVuQyxxQkFBS2EsVUFBTCxDQUFnQmQsR0FBaEIsRUFBcUJDLEdBQXJCO0FBQ0E7QUFDRDtBQUNEO0FBR1E7QUFFSixLQTdFMkMsQ0E2RTFDZixJQTdFMEMsQ0E2RXJDLElBN0VxQyxDQUE1QyxFQTZFYyxJQTdFZDtBQThFSCxHQTVQSTtBQThQUjtBQUNBRCxFQUFBQSxlQUFlLEVBQUUsMkJBQVk7QUFBQTs7QUFFNUIsU0FBS1csSUFBTCxDQUFVRSxTQUFWLENBQW9CL0QsRUFBRSxDQUFDZ0YsUUFBSCxDQUFZLENBQVosRUFBZSxLQUFLL0QsTUFBcEIsRUFBNEIsS0FBS0EsTUFBakMsQ0FBcEI7QUFDQSxTQUFLNEMsSUFBTCxDQUFVb0IsUUFBVixDQUFtQkMsT0FBbkIsQ0FBMkIsVUFBQ0MsSUFBRCxFQUFVO0FBQ3BDQSxNQUFBQSxJQUFJLENBQUNwQixTQUFMLENBQWUvRCxFQUFFLENBQUNnRixRQUFILENBQVksQ0FBWixFQUFlLE1BQUksQ0FBQy9ELE1BQXBCLEVBQTRCLE1BQUksQ0FBQ0EsTUFBakMsQ0FBZjtBQUNBLEtBRkQ7QUFHQSxTQUFLQSxNQUFMLEdBQWMsS0FBS0EsTUFBTCxJQUFlLEdBQWYsR0FBcUIsQ0FBckIsR0FBeUIsR0FBdkM7QUFDQSxHQXRRTztBQXdRUndCLEVBQUFBLFlBeFFRLDBCQXdRTztBQUNkLFNBQUtaLElBQUwsQ0FBVXVELE1BQVYsR0FBbUIsR0FBbkIsQ0FEYyxDQUNvQjs7QUFDbEMsU0FBS3JELFNBQUwsR0FBaUIsR0FBakI7O0FBQ0EsUUFBSSxLQUFLQSxTQUFMLElBQWtCLENBQXRCLEVBQXlCO0FBQ3hCLFdBQUtzRCxRQUFMLENBQWMsWUFBWTtBQUFLO0FBRTlCLGFBQUtDLFdBQUw7QUFDQSxPQUhELEVBR0csQ0FISDtBQUlBO0FBQ0QsR0FqUk87QUFrUlJBLEVBQUFBLFdBbFJRLHlCQWtSTTtBQUFpQjtBQUM5QixRQUFJLEtBQUt2RCxTQUFMLElBQWtCLENBQXRCLEVBQXlCO0FBQ3hCLFdBQUtBLFNBQUwsR0FBaUIsS0FBS0EsU0FBTCxHQUFpQixDQUFsQztBQUNBLFdBQUtGLElBQUwsQ0FBVXVELE1BQVYsR0FBbUIsS0FBS3JELFNBQXhCLENBRndCLENBRWM7QUFDdEMsS0FIRCxNQUdPO0FBQ04sV0FBS3VCLFFBQUwsQ0FBYyxDQUFDLEtBQUtuQyxZQUFwQjtBQUNBO0FBQ0QsR0F6Uk87QUEyUkw7QUFDQXNELEVBQUFBLDJCQUEyQixFQUFFLHFDQUFTeEIsQ0FBVCxFQUFXO0FBQ3BDLFFBQUlzQyxHQUFHLEdBQUcsS0FBSzFCLElBQUwsQ0FBVTJCLG9CQUFWLENBQStCdkMsQ0FBQyxDQUFDd0MsV0FBRixFQUEvQixDQUFWO0FBRUEsUUFBSXhCLEdBQUcsR0FBR3lCLElBQUksQ0FBQ0MsS0FBTCxDQUFZLENBQUNKLEdBQUcsQ0FBQ0ssQ0FBSixHQUFRckcsUUFBUSxDQUFDbUUsZUFBVCxDQUF5QkUsS0FBakMsR0FBeUNyRSxRQUFRLENBQUNrRSxTQUFULEdBQW1CLEdBQTdELElBQW9FbEUsUUFBUSxDQUFDa0UsU0FBekYsQ0FBVjtBQUNBLFFBQUlTLEdBQUcsR0FBR3dCLElBQUksQ0FBQ0MsS0FBTCxDQUFZLENBQUNKLEdBQUcsQ0FBQ00sQ0FBSixHQUFRdEcsUUFBUSxDQUFDbUUsZUFBVCxDQUF5QkMsS0FBakMsR0FBeUNwRSxRQUFRLENBQUNrRSxTQUFULEdBQW1CLEdBQTdELElBQW9FbEUsUUFBUSxDQUFDa0UsU0FBekYsQ0FBVjtBQUVBLFdBQU87QUFDSFEsTUFBQUEsR0FBRyxFQUFFQSxHQURGO0FBRUhDLE1BQUFBLEdBQUcsRUFBRUE7QUFGRixLQUFQO0FBSUgsR0F0U0k7QUF3U0w7QUFDQTRCLEVBQUFBLFlBQVksRUFBRSx3QkFBVztBQUVyQixTQUFJLElBQUlDLENBQUMsR0FBRyxDQUFaLEVBQWVBLENBQUMsR0FBRyxFQUFuQixFQUF1QkEsQ0FBQyxFQUF4QixFQUEyQjtBQUV2QixXQUFJLElBQUlDLENBQUMsR0FBRyxDQUFaLEVBQWVBLENBQUMsR0FBRyxDQUFuQixFQUFzQkEsQ0FBQyxFQUF2QixFQUEwQjtBQUV0QixZQUFHdEcsUUFBUSxDQUFDbUYsT0FBVCxDQUFpQixJQUFqQixFQUF1QmtCLENBQXZCLEVBQTBCQyxDQUExQixDQUFILEVBQWdDO0FBRTVCLGNBQUlILENBQUMsR0FBSUcsQ0FBQyxHQUFHekcsUUFBUSxDQUFDa0UsU0FBYixHQUF5QmxFLFFBQVEsQ0FBQ21FLGVBQVQsQ0FBeUJDLEtBQTNEO0FBQ0EsY0FBSWlDLENBQUMsR0FBSUcsQ0FBQyxHQUFHeEcsUUFBUSxDQUFDa0UsU0FBYixHQUF5QmxFLFFBQVEsQ0FBQ21FLGVBQVQsQ0FBeUJFLEtBQTNELENBSDRCLENBSzVCOztBQUNBLGNBQUluRCxTQUFTLEdBQUdULEVBQUUsQ0FBQ3VELFdBQUgsQ0FBZSxLQUFLOUMsU0FBcEIsQ0FBaEI7QUFDQUEsVUFBQUEsU0FBUyxDQUFDK0MsV0FBVixDQUFzQnFDLENBQXRCLEVBQXlCRCxDQUF6QjtBQUNBLGVBQUsvQixJQUFMLENBQVVDLFFBQVYsQ0FBbUJyRCxTQUFuQjtBQUNBLGVBQUthLGlCQUFMLENBQXVCMkUsSUFBdkIsQ0FBNEJ4RixTQUE1QjtBQUNIO0FBQ0o7QUFDSjtBQUNKLEdBNVRJO0FBOFRMO0FBQ0E2RCxFQUFBQSxrQkFBa0IsRUFBRSw0QkFBVTRCLE1BQVYsRUFBaUI7QUFFdkMsUUFBRyxLQUFLNUUsaUJBQUwsQ0FBdUI2RSxNQUF2QixLQUFrQyxDQUFyQyxFQUF3QyxPQUZELENBR3ZDOztBQUNBLFFBQUcsS0FBSzdFLGlCQUFMLENBQXVCLENBQXZCLEVBQTBCaUIsSUFBMUIsS0FBbUMyRCxNQUF0QyxFQUE2QztBQUU1QyxXQUFLNUUsaUJBQUwsQ0FBdUI4RSxLQUF2QixDQUE2QixDQUE3QixFQUFnQ2xCLE9BQWhDLENBQXdDLFVBQUFDLElBQUksRUFBSTtBQUUvQ0EsUUFBQUEsSUFBSSxDQUFDZixnQkFBTDtBQUNBLE9BSEQ7QUFJQSxXQUFLOUMsaUJBQUwsR0FBeUIsS0FBS0EsaUJBQUwsQ0FBdUI4RSxLQUF2QixDQUE2QixDQUE3QixFQUFnQyxDQUFoQyxDQUF6QjtBQUVBLEtBUkQsTUFRTztBQUNOLFdBQUs5RSxpQkFBTCxDQUF1QjRELE9BQXZCLENBQStCLFVBQUFDLElBQUksRUFBSTtBQUV0Q0EsUUFBQUEsSUFBSSxDQUFDZixnQkFBTDtBQUNBLE9BSEQ7QUFJQSxXQUFLOUMsaUJBQUwsR0FBeUIsRUFBekI7QUFDQTtBQUNFLEdBbFZJO0FBb1ZSO0FBQ0ErRSxFQUFBQSxlQUFlLEVBQUUseUJBQVNwQyxHQUFULEVBQWNDLEdBQWQsRUFBbUJvQyxPQUFuQixFQUE0QkMsT0FBNUIsRUFBcUM7QUFFckQsUUFBSVYsQ0FBQyxHQUFJM0IsR0FBRyxHQUFHM0UsUUFBUSxDQUFDa0UsU0FBZixHQUEyQmxFLFFBQVEsQ0FBQ21FLGVBQVQsQ0FBeUJDLEtBQTdEO0FBQ0EsUUFBSWlDLENBQUMsR0FBSTNCLEdBQUcsR0FBRzFFLFFBQVEsQ0FBQ2tFLFNBQWYsR0FBMkJsRSxRQUFRLENBQUNtRSxlQUFULENBQXlCRSxLQUE3RDs7QUFFQSxTQUFJLElBQUk0QyxDQUFDLEdBQUcsQ0FBWixFQUFlQSxDQUFDLEdBQUcsQ0FBbkIsRUFBc0JBLENBQUMsRUFBdkIsRUFBMEI7QUFFekIsVUFBSTlGLFNBQVMsR0FBR1YsRUFBRSxDQUFDdUQsV0FBSCxDQUFlLEtBQUs3QyxTQUFwQixDQUFoQjtBQUVBQSxNQUFBQSxTQUFTLENBQUM4QyxXQUFWLENBQXNCcUMsQ0FBdEIsRUFBeUJELENBQXpCO0FBQ0EsV0FBSy9CLElBQUwsQ0FBVUMsUUFBVixDQUFtQnBELFNBQW5CO0FBQ0EsV0FBS1ksaUJBQUwsQ0FBdUIyRSxJQUF2QixDQUE0QnZGLFNBQTVCO0FBQ0FtRixNQUFBQSxDQUFDLEdBQUlVLE9BQU8sR0FBR2hILFFBQVEsQ0FBQ2tFLFNBQW5CLEdBQStCbEUsUUFBUSxDQUFDbUUsZUFBVCxDQUF5QkMsS0FBN0Q7QUFDQWlDLE1BQUFBLENBQUMsR0FBSVUsT0FBTyxHQUFHL0csUUFBUSxDQUFDa0UsU0FBbkIsR0FBK0JsRSxRQUFRLENBQUNtRSxlQUFULENBQXlCRSxLQUE3RDtBQUNBO0FBQ0QsR0FwV087QUFzV1JOLEVBQUFBLFFBQVEsRUFBRSxrQkFBU2xDLFNBQVQsRUFBb0I7QUFDN0I7QUFDQSxRQUFJQSxTQUFKLEVBQWU7QUFDWHRCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFNBQVo7QUFDQSxXQUFLZ0IsS0FBTCxHQUFheEIsUUFBUSxDQUFDNkIsU0FBVCxDQUFtQm1ELEtBQWhDO0FBQ0gsS0FIRCxNQUdRO0FBQ0p6RSxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxTQUFaO0FBQ0gsV0FBS2dCLEtBQUwsR0FBYXhCLFFBQVEsQ0FBQzZCLFNBQVQsQ0FBbUJDLEdBQWhDO0FBQ0E7O0FBQ0QsU0FBS1UsU0FBTCxHQUFpQixDQUFqQjtBQUNBLFFBQUluQixjQUFjLEdBQUdaLEVBQUUsQ0FBQ3VELFdBQUgsQ0FBZSxLQUFLM0MsY0FBcEIsQ0FBckI7QUFDQUEsSUFBQUEsY0FBYyxDQUFDNEMsV0FBZixDQUEyQixJQUFJakUsUUFBUSxDQUFDa0UsU0FBYixHQUF5QmxFLFFBQVEsQ0FBQ21FLGVBQVQsQ0FBeUJDLEtBQTdFLEVBQ0MsTUFBTXBFLFFBQVEsQ0FBQ2tFLFNBQWYsR0FBMkJsRSxRQUFRLENBQUNtRSxlQUFULENBQXlCRSxLQURyRDtBQUVBLFNBQUtDLElBQUwsQ0FBVUMsUUFBVixDQUFtQmxELGNBQW5CO0FBQ0FBLElBQUFBLGNBQWMsQ0FBQ21ELFNBQWYsQ0FBeUIvRCxFQUFFLENBQUNnRSxNQUFILENBQVUsQ0FBVixDQUF6QjtBQUNBLEdBclhPO0FBdVhSO0FBQ0F5QyxFQUFBQSx1QkFBdUIsRUFBRSxtQ0FBVztBQUNuQztBQUNBLFFBQUlDLG9CQUFvQixHQUFHLElBQUlDLEdBQUosRUFBM0IsQ0FGbUMsQ0FHbkM7O0FBQ0EsU0FBS3pGLGlCQUFMLEdBQXlCLEtBQUtKLFlBQUwsQ0FBa0IsS0FBS1MsZUFBdkIsRUFBd0MsS0FBS0MsZUFBN0MsQ0FBekIsQ0FKbUMsQ0FNbkM7O0FBQ0FrRixJQUFBQSxvQkFBb0IsQ0FBQ0UsR0FBckIsQ0FBeUIsWUFBWSxLQUFLckYsZUFBakIsR0FBbUMsR0FBbkMsR0FBeUMsUUFBekMsR0FBb0QsS0FBS0MsZUFBekQsR0FBMkUsR0FBcEc7O0FBQ0EsU0FBSSxJQUFJdUUsQ0FBQyxHQUFHLENBQVosRUFBZUEsQ0FBQyxHQUFHLEVBQW5CLEVBQXVCQSxDQUFDLEVBQXhCLEVBQTJCO0FBRXZCLFdBQUksSUFBSUMsQ0FBQyxHQUFHLENBQVosRUFBZUEsQ0FBQyxJQUFJLENBQXBCLEVBQXVCQSxDQUFDLEVBQXhCLEVBQTJCO0FBQzdCO0FBQ0FELFFBQUFBLENBQUMsR0FBR0EsQ0FBQyxLQUFLLENBQU4sR0FBVSxDQUFWLEdBQWNBLENBQWxCLENBRjZCLENBRzdCOztBQUNBLFlBQ0MsS0FBS2pGLFlBQUwsQ0FBa0JpRixDQUFsQixFQUFxQkMsQ0FBckIsS0FDQSxLQUFLbEYsWUFBTCxDQUFrQmlGLENBQWxCLEVBQXFCQyxDQUFyQixFQUF3QmEsWUFBeEIsS0FBeUMsQ0FEekMsSUFFQSxLQUFLL0YsWUFBTCxDQUFrQmlGLENBQWxCLEVBQXFCQyxDQUFyQixFQUF3QnJCLFdBQXhCLEtBQXdDLEtBQUt4RCxZQUg5QyxFQUlDO0FBQ0EsZUFBS0ksZUFBTCxHQUF1QndFLENBQXZCO0FBQ0EsZUFBS3ZFLGVBQUwsR0FBdUJ3RSxDQUF2QjtBQUNBLFNBWDRCLENBWTdCO0FBQ0M7QUFFQTtBQUNBOztBQUNFO0FBQ0o7O0FBQ0QsV0FBT1Usb0JBQVA7QUFDQSxHQXRaTztBQXdaUjtBQUNBSSxFQUFBQSxpQkFBaUIsRUFBRSwyQkFBU0MsbUJBQVQsRUFBOEJDLG1CQUE5QixFQUFtRDtBQUFBOztBQUNyRSxRQUFJQyxjQUFjLEdBQUcsSUFBSU4sR0FBSixFQUFyQixDQURxRSxDQUVyRTs7QUFDQSxRQUFNTyxHQUFHLEdBQUcsRUFBWjtBQUNBLFNBQUtwRyxZQUFMLENBQWtCb0UsT0FBbEIsQ0FBMEIsVUFBQUMsSUFBSSxFQUFJO0FBQ2pDK0IsTUFBQUEsR0FBRyxDQUFDakIsSUFBSixPQUFBaUIsR0FBRyxxQkFBUy9CLElBQVQsRUFBSDtBQUNBLEtBRkQ7QUFJQStCLElBQUFBLEdBQUcsQ0FBQ2hDLE9BQUosQ0FBWSxVQUFBQyxJQUFJLEVBQUk7QUFDbkI7QUFDQSxVQUFHQSxJQUFJLElBQUlBLElBQUksQ0FBQ1IsV0FBTCxLQUFxQixNQUFJLENBQUN4RCxZQUFyQyxFQUFrRDtBQUVqRCxRQUFBLE1BQUksQ0FBQ0QsaUJBQUwsR0FBeUJpRSxJQUF6Qjs7QUFFQSxhQUFJLElBQUlZLENBQUMsR0FBRyxDQUFaLEVBQWVBLENBQUMsR0FBRyxFQUFuQixFQUF1QkEsQ0FBQyxFQUF4QixFQUEyQjtBQUV2QixlQUFJLElBQUlDLENBQUMsR0FBRyxDQUFaLEVBQWVBLENBQUMsR0FBRyxDQUFuQixFQUFzQkEsQ0FBQyxFQUF2QixFQUEwQjtBQUM1QjtBQUNBLGdCQUFHdEcsUUFBUSxDQUFDbUYsT0FBVCxDQUFpQixNQUFqQixFQUF1QmtCLENBQXZCLEVBQTBCQyxDQUExQixDQUFILEVBQWdDO0FBRS9CLGtCQUFHLE1BQUksQ0FBQzlFLGlCQUFMLENBQXVCMkYsWUFBdkIsS0FBd0MsQ0FBM0MsRUFBNkM7QUFDNUM7QUFDQSxvQkFBR0UsbUJBQW1CLEtBQUtoQixDQUF4QixJQUE2QmlCLG1CQUFtQixLQUFLaEIsQ0FBeEQsRUFBMEQ7QUFFekQsc0JBQUd0RyxRQUFRLENBQUN5SCw2QkFBVCxDQUF1QyxNQUF2QyxFQUE2QyxNQUFJLENBQUNqRyxpQkFBTCxDQUF1QmtHLEtBQXBFLEVBQ0YsTUFBSSxDQUFDbEcsaUJBQUwsQ0FBdUJtRyxLQURyQixFQUM0Qk4sbUJBRDVCLEVBQ2lEQyxtQkFEakQsTUFDMEUsQ0FEN0UsRUFDK0U7QUFFOUUsd0JBQUcsTUFBSSxDQUFDOUYsaUJBQUwsQ0FBdUJrRyxLQUF2QixLQUFpQ0wsbUJBQXBDLEVBQXdEO0FBQ3ZELDBCQUFHLENBQUMsTUFBSSxDQUFDakcsWUFBTCxDQUFrQmlGLENBQWxCLEVBQXFCQyxDQUFDLEdBQUcsQ0FBekIsQ0FBSixFQUFnQztBQUMvQmlCLHdCQUFBQSxjQUFjLENBQUNMLEdBQWYsQ0FBbUIsWUFBWWIsQ0FBWixHQUFnQixHQUFoQixHQUFzQixRQUF0QixJQUFrQ0MsQ0FBQyxHQUFHLENBQXRDLElBQTJDLEdBQTlEO0FBQ0E7O0FBQ0QsMEJBQUcsQ0FBQyxNQUFJLENBQUNsRixZQUFMLENBQWtCaUYsQ0FBbEIsRUFBcUJDLENBQUMsR0FBRyxDQUF6QixDQUFKLEVBQWdDO0FBQy9CaUIsd0JBQUFBLGNBQWMsQ0FBQ0wsR0FBZixDQUFtQixZQUFZYixDQUFaLEdBQWdCLEdBQWhCLEdBQXNCLFFBQXRCLElBQWtDQyxDQUFDLEdBQUcsQ0FBdEMsSUFBMkMsR0FBOUQ7QUFDQTtBQUNEOztBQUNELHdCQUFHLE1BQUksQ0FBQzlFLGlCQUFMLENBQXVCbUcsS0FBdkIsS0FBaUNMLG1CQUFwQyxFQUF3RDtBQUN2RCwwQkFBSWpCLENBQUMsR0FBRyxDQUFMLElBQVcsQ0FBWCxJQUFnQixDQUFDLE1BQUksQ0FBQ2pGLFlBQUwsQ0FBa0JpRixDQUFDLEdBQUcsQ0FBdEIsRUFBeUJDLENBQXpCLENBQXBCLEVBQWdEO0FBQy9DaUIsd0JBQUFBLGNBQWMsQ0FBQ0wsR0FBZixDQUFtQixhQUFhYixDQUFDLEdBQUcsQ0FBakIsSUFBc0IsR0FBdEIsR0FBNEIsUUFBNUIsR0FBdUNDLENBQXZDLEdBQTJDLEdBQTlEO0FBQ0E7O0FBQ0QsMEJBQUlELENBQUMsR0FBRyxDQUFMLElBQVcsQ0FBWCxJQUFnQixDQUFDLE1BQUksQ0FBQ2pGLFlBQUwsQ0FBa0JpRixDQUFDLEdBQUcsQ0FBdEIsRUFBeUJDLENBQXpCLENBQXBCLEVBQWdEO0FBQy9DaUIsd0JBQUFBLGNBQWMsQ0FBQ0wsR0FBZixDQUFtQixhQUFhYixDQUFDLEdBQUcsQ0FBakIsSUFBc0IsR0FBdEIsR0FBNEIsUUFBNUIsR0FBdUNDLENBQXZDLEdBQTJDLEdBQTlEO0FBQ0E7QUFDRDs7QUFFRGlCLG9CQUFBQSxjQUFjLENBQUNMLEdBQWYsQ0FBbUIsWUFBWWIsQ0FBWixHQUFnQixHQUFoQixHQUFzQixRQUF0QixHQUFpQ0MsQ0FBakMsR0FBcUMsR0FBeEQ7QUFDQTtBQUNEO0FBQ0QsZUEzQkQsTUEyQk87QUFDTmlCLGdCQUFBQSxjQUFjLENBQUNMLEdBQWYsQ0FBbUIsWUFBWWIsQ0FBWixHQUFnQixHQUFoQixHQUFzQixRQUF0QixHQUFpQ0MsQ0FBakMsR0FBcUMsR0FBeEQ7QUFDQTtBQUNEO0FBQ0U7QUFDSjtBQUNEO0FBQ0QsS0E5Q0Q7QUErQ0EsV0FBT2lCLGNBQVA7QUFDQSxHQWpkTztBQW1kUjtBQUNBSyxFQUFBQSxTQUFTLEVBQUUscUJBQVc7QUFFckIsUUFBTUMsSUFBSSxHQUFHLEtBQUtyRyxpQkFBbEIsQ0FGcUIsQ0FJckI7O0FBQ0EsUUFBSStGLGNBQWMsR0FBRyxLQUFLSCxpQkFBTCxDQUF1QixLQUFLdkYsZUFBNUIsRUFBNkMsS0FBS0MsZUFBbEQsQ0FBckIsQ0FMcUIsQ0FPckI7O0FBQ0EsUUFBSWtGLG9CQUFvQixHQUFHLEtBQUtELHVCQUFMLEVBQTNCO0FBRUEsU0FBS3ZGLGlCQUFMLEdBQXlCcUcsSUFBekI7QUFFQSxRQUFJQyxJQUFJLEdBQUdkLG9CQUFvQixDQUFDYyxJQUFoQyxDQVpxQixDQWFyQjs7QUFDQWQsSUFBQUEsb0JBQW9CLENBQUN4QixPQUFyQixDQUE2QixVQUFBQyxJQUFJLEVBQUk7QUFDcEM7QUFDQSxVQUFHOEIsY0FBYyxDQUFDUSxHQUFmLENBQW1CdEMsSUFBbkIsQ0FBSCxFQUE0QjtBQUUzQnVCLFFBQUFBLG9CQUFvQixVQUFwQixDQUE0QnZCLElBQTVCO0FBQ0E7QUFDRCxLQU5EOztBQU9BLFFBQUdxQyxJQUFJLEtBQUtkLG9CQUFvQixDQUFDYyxJQUFqQyxFQUFzQztBQUNyQzFILE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLElBQVosRUFEcUMsQ0FDbEI7O0FBQ25CLFVBQUljLFVBQVUsR0FBR2IsRUFBRSxDQUFDdUQsV0FBSCxDQUFlLEtBQUsxQyxVQUFwQixDQUFqQjtBQUNBQSxNQUFBQSxVQUFVLENBQUMyQyxXQUFYLENBQXVCLElBQUlqRSxRQUFRLENBQUNrRSxTQUFiLEdBQXlCbEUsUUFBUSxDQUFDbUUsZUFBVCxDQUF5QkMsS0FBekUsRUFBZ0YsTUFBTXBFLFFBQVEsQ0FBQ2tFLFNBQWYsR0FBMkJsRSxRQUFRLENBQUNtRSxlQUFULENBQXlCRSxLQUFwSTtBQUNBLFdBQUtDLElBQUwsQ0FBVUMsUUFBVixDQUFtQmpELFVBQW5CO0FBQ0FBLE1BQUFBLFVBQVUsQ0FBQ2tELFNBQVgsQ0FBcUIvRCxFQUFFLENBQUNnRSxNQUFILENBQVUsQ0FBVixDQUFyQjtBQUNBMEQsTUFBQUEsVUFBVSxDQUFDLFlBQU07QUFDaEI3RyxRQUFBQSxVQUFVLENBQUN1RCxnQkFBWDtBQUNBLE9BRlMsRUFFUCxJQUZPLENBQVY7QUFHQTs7QUFDRCxTQUFLLElBQUlvQyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHLEVBQXBCLEVBQXdCQSxDQUFDLEVBQXpCLEVBQTZCO0FBRTVCLFVBQUcsS0FBSzFGLFlBQUwsQ0FBa0IwRixDQUFsQixFQUFxQixLQUFLaEYsZUFBMUIsS0FDRixLQUFLVixZQUFMLENBQWtCMEYsQ0FBbEIsRUFBcUIsS0FBS2hGLGVBQTFCLEVBQTJDcUYsWUFBM0MsS0FBNEQsQ0FEMUQsSUFFRixLQUFLL0YsWUFBTCxDQUFrQjBGLENBQWxCLEVBQXFCLEtBQUtoRixlQUExQixFQUEyQzRGLEtBQTNDLEtBQXFELEtBQUs3RixlQUYzRCxFQUUyRTtBQUUxRSxZQUFJN0IsUUFBUSxDQUFDeUgsNkJBQVQsQ0FBdUMsSUFBdkMsRUFBNkNYLENBQTdDLEVBQWdELEtBQUtoRixlQUFyRCxFQUFzRSxLQUFLRCxlQUEzRSxFQUE0RixLQUFLQyxlQUFqRyxNQUFzSCxDQUExSCxFQUE0SDtBQUMzSCxlQUFLOEIsUUFBTCxDQUFjLENBQUMsS0FBS25DLFlBQXBCO0FBQ0E7QUFDQTtBQUNEO0FBQ0Q7QUFDRCxHQS9mTztBQWlnQkw7QUFDQXlELEVBQUFBLGdCQUFnQixFQUFFLDBCQUFTRixXQUFULEVBQXFCO0FBRW5DLFFBQUcsS0FBS3BELGlCQUFSLEVBQTBCO0FBRXRCLFdBQUtnRCxrQkFBTCxDQUF3QixLQUF4QjtBQUNIOztBQUVELFFBQUcsS0FBS3BELGlCQUFSLEVBQTBCO0FBQ3RCLFVBQUl5RyxVQUFVLEdBQUcsS0FBS3pHLGlCQUFMLENBQXVCaUQsYUFBeEM7QUFDQXdELE1BQUFBLFVBQVUsQ0FBQ0MsY0FBWDtBQUNBRCxNQUFBQSxVQUFVLENBQUNFLEtBQVgsR0FBbUIsQ0FBbkI7QUFDSCxLQVhrQyxDQWFuQzs7O0FBQ0EsU0FBSzNHLGlCQUFMLEdBQXlCd0QsV0FBekI7QUFDQSxRQUFJb0QsTUFBTSxHQUFHLEtBQUs1RyxpQkFBTCxDQUF1QmlELGFBQXBDO0FBQ0EyRCxJQUFBQSxNQUFNLENBQUNGLGNBQVA7QUFDQUUsSUFBQUEsTUFBTSxDQUFDRCxLQUFQLEdBQWUsQ0FBZjtBQUNBQyxJQUFBQSxNQUFNLENBQUMvRCxTQUFQLENBQWlCL0QsRUFBRSxDQUFDK0gsYUFBSCxDQUFpQi9ILEVBQUUsQ0FBQ2dJLFFBQUgsQ0FBWWhJLEVBQUUsQ0FBQ2lJLE9BQUgsQ0FBVyxHQUFYLEVBQWdCLEdBQWhCLENBQVosRUFBa0NqSSxFQUFFLENBQUNpSSxPQUFILENBQVcsR0FBWCxFQUFnQixHQUFoQixDQUFsQyxDQUFqQixDQUFqQixFQWxCbUMsQ0FvQm5DOztBQUNBLFNBQUtuQyxZQUFMO0FBQ0gsR0F4aEJJO0FBMGhCTDtBQUNBaEIsRUFBQUEsVUFBVSxFQUFFLG9CQUFTYixHQUFULEVBQWNDLEdBQWQsRUFBa0I7QUFBQTs7QUFFaEM7QUFDQSxRQUFNZ0UsUUFBUSxHQUFHLEtBQUtoSCxpQkFBTCxDQUF1QmlELGFBQXhDO0FBQ0EsUUFBTWdFLE1BQU0sR0FBR25JLEVBQUUsQ0FBQ21JLE1BQUgsQ0FBVSxHQUFWLEVBQWVqRSxHQUFHLEdBQUczRSxRQUFRLENBQUNrRSxTQUFmLEdBQTJCbEUsUUFBUSxDQUFDbUUsZUFBVCxDQUF5QkMsS0FBbkUsRUFBMEVNLEdBQUcsR0FBRzFFLFFBQVEsQ0FBQ2tFLFNBQWYsR0FBMkJsRSxRQUFRLENBQUNtRSxlQUFULENBQXlCRSxLQUE5SCxDQUFmO0FBQ0FzRSxJQUFBQSxRQUFRLENBQUNuRSxTQUFULENBQW1Cb0UsTUFBbkIsRUFMZ0MsQ0FPaEM7O0FBQ0FULElBQUFBLFVBQVUsQ0FBQyxZQUFNO0FBQ2hCO0FBQ0EsVUFBSVUsYUFBYSxHQUFHLE1BQUksQ0FBQ3RILFlBQUwsQ0FBa0JtRCxHQUFsQixFQUF1QkMsR0FBdkIsQ0FBcEI7QUFFQWtFLE1BQUFBLGFBQWEsQ0FBQ0MsU0FBZCxHQUEwQixJQUExQjtBQUNBRCxNQUFBQSxhQUFhLENBQUNqRSxhQUFkLENBQTRCQyxnQkFBNUIsR0FMZ0IsQ0FPaEI7O0FBQ0EsTUFBQSxNQUFJLENBQUN0RCxZQUFMLENBQWtCLE1BQUksQ0FBQ0ksaUJBQUwsQ0FBdUJrRyxLQUF6QyxFQUFnRCxNQUFJLENBQUNsRyxpQkFBTCxDQUF1Qm1HLEtBQXZFLElBQWdGLElBQWhGO0FBQ0EsVUFBSWYsT0FBTyxHQUFHLE1BQUksQ0FBQ3BGLGlCQUFMLENBQXVCa0csS0FBckM7QUFDQSxVQUFJYixPQUFPLEdBQUcsTUFBSSxDQUFDckYsaUJBQUwsQ0FBdUJtRyxLQUFyQyxDQVZnQixDQVloQjs7QUFDQSxNQUFBLE1BQUksQ0FBQ25HLGlCQUFMLENBQXVCa0csS0FBdkIsR0FBK0JuRCxHQUEvQjtBQUNBLE1BQUEsTUFBSSxDQUFDL0MsaUJBQUwsQ0FBdUJtRyxLQUF2QixHQUErQm5ELEdBQS9CLENBZGdCLENBZ0JoQjs7QUFDQSxVQUFJMkIsQ0FBQyxHQUFJM0IsR0FBRyxHQUFHM0UsUUFBUSxDQUFDa0UsU0FBZixHQUEyQmxFLFFBQVEsQ0FBQ21FLGVBQVQsQ0FBeUJDLEtBQTdEO0FBQ0EsVUFBSWlDLENBQUMsR0FBSTNCLEdBQUcsR0FBRzFFLFFBQVEsQ0FBQ2tFLFNBQWYsR0FBMkJsRSxRQUFRLENBQUNtRSxlQUFULENBQXlCRSxLQUE3RDs7QUFDQSxNQUFBLE1BQUksQ0FBQzFDLGlCQUFMLENBQXVCaUQsYUFBdkIsQ0FBcUNYLFdBQXJDLENBQWlEcUMsQ0FBakQsRUFBb0RELENBQXBELEVBbkJnQixDQXFCaEI7OztBQUNBLE1BQUEsTUFBSSxDQUFDOUUsWUFBTCxDQUFrQm1ELEdBQWxCLEVBQXVCQyxHQUF2QixJQUE4QixNQUFJLENBQUNoRCxpQkFBbkMsQ0F0QmdCLENBd0JoQjs7QUFDQSxNQUFBLE1BQUksQ0FBQ29ILG9CQUFMLENBQTBCLE1BQUksQ0FBQ3hILFlBQS9CLEVBQTZDbUQsR0FBN0MsRUFBa0RDLEdBQWxELEVBQXVEb0MsT0FBdkQsRUFBZ0VDLE9BQWhFLEVBQ0MsTUFBSSxDQUFDcEYsWUFETixFQUNvQixNQUFJLENBQUNELGlCQUFMLENBQXVCMkYsWUFEM0MsRUFDeUQsTUFBSSxDQUFDcEYsU0FEOUQsRUF6QmdCLENBNEJoQjs7O0FBQ0EsVUFBSXFHLE1BQU0sR0FBRyxNQUFJLENBQUM1RyxpQkFBTCxDQUF1QmlELGFBQXBDO0FBQ0EyRCxNQUFBQSxNQUFNLENBQUNGLGNBQVA7QUFDQUUsTUFBQUEsTUFBTSxDQUFDRCxLQUFQLEdBQWUsQ0FBZjtBQUNBLE1BQUEsTUFBSSxDQUFDM0csaUJBQUwsR0FBeUIsSUFBekIsQ0FoQ2dCLENBa0NoQjs7QUFDQSxNQUFBLE1BQUksQ0FBQ0YsUUFBTCxHQUFnQixDQUFDLE1BQUksQ0FBQ0EsUUFBdEIsQ0FuQ2dCLENBbUNlO0FBRS9COztBQUNBLFVBQUlMLFNBQVMsR0FBR1gsRUFBRSxDQUFDdUQsV0FBSCxDQUFlLE1BQUksQ0FBQzVDLFNBQXBCLENBQWhCO0FBQ0FBLE1BQUFBLFNBQVMsQ0FBQzZDLFdBQVYsQ0FBc0IsSUFBSWpFLFFBQVEsQ0FBQ2tFLFNBQWIsR0FBeUJsRSxRQUFRLENBQUNtRSxlQUFULENBQXlCQyxLQUF4RSxFQUNDLE1BQU1wRSxRQUFRLENBQUNrRSxTQUFmLEdBQTJCbEUsUUFBUSxDQUFDbUUsZUFBVCxDQUF5QkUsS0FEckQ7O0FBRUEsTUFBQSxNQUFJLENBQUNDLElBQUwsQ0FBVUMsUUFBVixDQUFtQm5ELFNBQW5COztBQUNBQSxNQUFBQSxTQUFTLENBQUNvRCxTQUFWLENBQW9CL0QsRUFBRSxDQUFDZ0UsTUFBSCxDQUFVLENBQVYsQ0FBcEI7QUFDQTBELE1BQUFBLFVBQVUsQ0FBQyxZQUFNO0FBQ2hCL0csUUFBQUEsU0FBUyxDQUFDeUQsZ0JBQVY7QUFDQSxPQUZTLEVBRVAsSUFGTyxDQUFWLENBM0NnQixDQStDaEI7O0FBQ0EsVUFBR2dFLGFBQWEsQ0FBQ3ZCLFlBQWQsS0FBK0J0SCxRQUFRLENBQUNnSixVQUFULENBQW9CQyxLQUF0RCxFQUE0RDtBQUMzRCxRQUFBLE1BQUksQ0FBQ2xGLFFBQUwsQ0FBYyxDQUFDOEUsYUFBYSxDQUFDekQsV0FBN0I7QUFDQSxPQWxEZSxDQW9EaEI7OztBQUNBLE1BQUEsTUFBSSxDQUFDTCxrQkFBTCxHQXJEZ0IsQ0F1RGhCOzs7QUFDQSxNQUFBLE1BQUksQ0FBQytCLGVBQUwsQ0FBcUJwQyxHQUFyQixFQUEwQkMsR0FBMUIsRUFBK0JvQyxPQUEvQixFQUF3Q0MsT0FBeEMsRUF4RGdCLENBMERoQjs7O0FBQ0EsTUFBQSxNQUFJLENBQUNlLFNBQUw7O0FBRUEsTUFBQSxNQUFJLENBQUN2RixTQUFMLEdBQWlCLEdBQWpCO0FBRUEsS0EvRFMsRUErRFAsR0EvRE8sQ0FBVjtBQWdFRyxHQW5tQkk7QUFvbUJMO0FBQ0FnRCxFQUFBQSxVQUFVLEVBQUUsb0JBQVNkLEdBQVQsRUFBY0MsR0FBZCxFQUFrQjtBQUFBOztBQUVoQztBQUNBLFFBQU1nRSxRQUFRLEdBQUcsS0FBS2hILGlCQUFMLENBQXVCaUQsYUFBeEM7QUFDQSxRQUFNZ0UsTUFBTSxHQUFHbkksRUFBRSxDQUFDbUksTUFBSCxDQUFVLEdBQVYsRUFBZWpFLEdBQUcsR0FBRzNFLFFBQVEsQ0FBQ2tFLFNBQWYsR0FBMkJsRSxRQUFRLENBQUNtRSxlQUFULENBQXlCQyxLQUFuRSxFQUNkTSxHQUFHLEdBQUcxRSxRQUFRLENBQUNrRSxTQUFmLEdBQTJCbEUsUUFBUSxDQUFDbUUsZUFBVCxDQUF5QkUsS0FEdEMsQ0FBZjtBQUVBc0UsSUFBQUEsUUFBUSxDQUFDbkUsU0FBVCxDQUFtQm9FLE1BQW5CLEVBTmdDLENBU2hDOztBQUNBVCxJQUFBQSxVQUFVLENBQUMsWUFBTTtBQUNoQjtBQUNBLFVBQUlwQixPQUFPLEdBQUcsTUFBSSxDQUFDcEYsaUJBQUwsQ0FBdUJrRyxLQUFyQztBQUNBLFVBQUliLE9BQU8sR0FBRyxNQUFJLENBQUNyRixpQkFBTCxDQUF1Qm1HLEtBQXJDO0FBQ0EsTUFBQSxNQUFJLENBQUN2RyxZQUFMLENBQWtCd0YsT0FBbEIsRUFBMkJDLE9BQTNCLElBQXNDLElBQXRDLENBSmdCLENBT2hCOztBQUNBLE1BQUEsTUFBSSxDQUFDckYsaUJBQUwsQ0FBdUJrRyxLQUF2QixHQUErQm5ELEdBQS9CO0FBQ0EsTUFBQSxNQUFJLENBQUMvQyxpQkFBTCxDQUF1Qm1HLEtBQXZCLEdBQStCbkQsR0FBL0I7QUFDQSxNQUFBLE1BQUksQ0FBQ3BELFlBQUwsQ0FBa0JtRCxHQUFsQixFQUF1QkMsR0FBdkIsSUFBOEIsTUFBSSxDQUFDaEQsaUJBQW5DLENBVmdCLENBWWhCOztBQUNBLFVBQUkyRSxDQUFDLEdBQUkzQixHQUFHLEdBQUczRSxRQUFRLENBQUNrRSxTQUFmLEdBQTJCbEUsUUFBUSxDQUFDbUUsZUFBVCxDQUF5QkMsS0FBN0Q7QUFDQSxVQUFJaUMsQ0FBQyxHQUFJM0IsR0FBRyxHQUFHMUUsUUFBUSxDQUFDa0UsU0FBZixHQUEyQmxFLFFBQVEsQ0FBQ21FLGVBQVQsQ0FBeUJFLEtBQTdEOztBQUNBLE1BQUEsTUFBSSxDQUFDMUMsaUJBQUwsQ0FBdUJpRCxhQUF2QixDQUFxQ1gsV0FBckMsQ0FBaURxQyxDQUFqRCxFQUFvREQsQ0FBcEQsRUFmZ0IsQ0FpQmhCOzs7QUFDQSxNQUFBLE1BQUksQ0FBQzBDLG9CQUFMLENBQTBCLE1BQUksQ0FBQ3hILFlBQS9CLEVBQTZDbUQsR0FBN0MsRUFBa0RDLEdBQWxELEVBQXVEb0MsT0FBdkQsRUFBZ0VDLE9BQWhFLEVBQ0MsTUFBSSxDQUFDcEYsWUFETixFQUNvQixNQUFJLENBQUNELGlCQUFMLENBQXVCMkYsWUFEM0MsRUFDeUQsTUFBSSxDQUFDcEYsU0FEOUQsRUFsQmdCLENBcUJoQjs7O0FBQ0EsVUFBSXFHLE1BQU0sR0FBRyxNQUFJLENBQUM1RyxpQkFBTCxDQUF1QmlELGFBQXBDO0FBQ0EyRCxNQUFBQSxNQUFNLENBQUNGLGNBQVA7QUFDQUUsTUFBQUEsTUFBTSxDQUFDRCxLQUFQLEdBQWUsQ0FBZjtBQUNBLE1BQUEsTUFBSSxDQUFDM0csaUJBQUwsR0FBeUIsSUFBekIsQ0F6QmdCLENBMkJoQjs7QUFDQSxNQUFBLE1BQUksQ0FBQ0YsUUFBTCxHQUFnQixDQUFDLE1BQUksQ0FBQ0EsUUFBdEIsQ0E1QmdCLENBNEJlO0FBRS9COztBQUNBLE1BQUEsTUFBSSxDQUFDc0Qsa0JBQUwsR0EvQmdCLENBaUNoQjs7O0FBQ0EsTUFBQSxNQUFJLENBQUMrQixlQUFMLENBQXFCcEMsR0FBckIsRUFBMEJDLEdBQTFCLEVBQStCb0MsT0FBL0IsRUFBd0NDLE9BQXhDLEVBbENnQixDQW9DaEI7OztBQUNBLE1BQUEsTUFBSSxDQUFDZSxTQUFMOztBQUVBLE1BQUEsTUFBSSxDQUFDdkYsU0FBTCxHQUFpQixHQUFqQjtBQUVBLEtBekNTLEVBeUNQLEdBekNPLENBQVY7QUEwQ0csR0F6cEJJO0FBMnBCTDtBQUNBVyxFQUFBQSxZQUFZLEVBQUUsd0JBQVU7QUFFcEI7QUFDQSxTQUFJLElBQUl1QixHQUFHLEdBQUcsQ0FBZCxFQUFpQkEsR0FBRyxJQUFJLENBQXhCLEVBQTJCQSxHQUFHLEVBQTlCLEVBQWlDO0FBQzdCLFdBQUtuRCxZQUFMLENBQWtCbUQsR0FBbEIsSUFBeUIsRUFBekI7O0FBQ0EsV0FBSSxJQUFJQyxHQUFHLEdBQUcsQ0FBZCxFQUFpQkEsR0FBRyxJQUFJLENBQXhCLEVBQTJCQSxHQUFHLEVBQTlCLEVBQWlDO0FBQzdCLGFBQUtwRCxZQUFMLENBQWtCbUQsR0FBbEIsRUFBdUJDLEdBQXZCLElBQThCLElBQTlCO0FBQ0g7QUFDSixLQVJtQixDQVVwQjs7O0FBQ0EsUUFBSXVFLG9CQUFvQixHQUFHbEosUUFBUSxDQUFDa0osb0JBQXBDOztBQUVBLFNBQUksSUFBSUMsQ0FBUixJQUFhRCxvQkFBYixFQUFrQztBQUM5QixVQUFJRSxVQUFVLEdBQUdGLG9CQUFvQixDQUFDQyxDQUFELENBQXJDO0FBRUEsVUFBSXpFLEdBQUcsR0FBRzBFLFVBQVUsQ0FBQzFFLEdBQXJCO0FBQ0EsVUFBSUMsR0FBRyxHQUFHeUUsVUFBVSxDQUFDekUsR0FBckI7QUFDQSxVQUFJOUMsU0FBUyxHQUFHdUgsVUFBVSxDQUFDdkgsU0FBM0I7QUFDQSxVQUFJbUgsVUFBVSxHQUFHSSxVQUFVLENBQUNKLFVBQTVCO0FBQ0EsVUFBSWhJLFdBQVcsR0FBRyxLQUFLcUksb0JBQUwsQ0FBMEJySixRQUFRLENBQUNzSixnQkFBVCxDQUEwQnpILFNBQTFCLEVBQXFDbUgsVUFBckMsQ0FBMUIsQ0FBbEIsQ0FQOEIsQ0FTOUI7O0FBQ0EsVUFBSU8sS0FBSyxHQUFHLElBQUlySixLQUFKLENBQVUyQixTQUFWLEVBQXFCbUgsVUFBckIsRUFBaUMsS0FBakMsRUFBd0N0RSxHQUF4QyxFQUE2Q0MsR0FBN0MsRUFBa0QzRCxXQUFsRCxDQUFaO0FBRUEsVUFBSXNGLENBQUMsR0FBSTNCLEdBQUcsR0FBRzNFLFFBQVEsQ0FBQ2tFLFNBQWYsR0FBMkJsRSxRQUFRLENBQUNtRSxlQUFULENBQXlCQyxLQUE3RDtBQUNBLFVBQUlpQyxDQUFDLEdBQUkzQixHQUFHLEdBQUcxRSxRQUFRLENBQUNrRSxTQUFmLEdBQTJCbEUsUUFBUSxDQUFDbUUsZUFBVCxDQUF5QkUsS0FBN0Q7QUFDQWtGLE1BQUFBLEtBQUssQ0FBQzNFLGFBQU4sQ0FBb0JYLFdBQXBCLENBQWdDcUMsQ0FBaEMsRUFBbUNELENBQW5DO0FBQ0EsV0FBSy9CLElBQUwsQ0FBVUMsUUFBVixDQUFtQmdGLEtBQUssQ0FBQzNFLGFBQXpCLEVBZjhCLENBaUI5Qjs7QUFDQSxXQUFLckQsWUFBTCxDQUFrQm1ELEdBQWxCLEVBQXVCQyxHQUF2QixJQUE4QjRFLEtBQTlCO0FBQ0g7QUFDSixHQTdyQkk7QUErckJSO0FBQ0F4RyxFQUFBQSxZQUFZLEVBQUUsc0JBQVNELElBQVQsRUFBYztBQUMzQixRQUFJMEcsZUFBZSxHQUFHQyxJQUFJLENBQUNDLEtBQUwsQ0FBVzVHLElBQVgsQ0FBdEIsQ0FEMkIsQ0FHM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUVHOztBQUNBLFNBQUksSUFBSTRCLEdBQUcsR0FBRyxDQUFkLEVBQWlCQSxHQUFHLElBQUksQ0FBeEIsRUFBMkJBLEdBQUcsRUFBOUIsRUFBaUM7QUFDN0I7QUFDQSxXQUFJLElBQUlDLEdBQUcsR0FBRyxDQUFkLEVBQWlCQSxHQUFHLElBQUksQ0FBeEIsRUFBMkJBLEdBQUcsRUFBOUIsRUFBaUM7QUFDdEMsWUFBRyxLQUFLcEQsWUFBTCxDQUFrQm1ELEdBQWxCLEVBQXVCQyxHQUF2QixDQUFILEVBQStCO0FBQzlCLGVBQUtwRCxZQUFMLENBQWtCbUQsR0FBbEIsRUFBdUJDLEdBQXZCLEVBQTRCQyxhQUE1QixDQUEwQ0MsZ0JBQTFDO0FBQ0EsZUFBS3RELFlBQUwsQ0FBa0JtRCxHQUFsQixFQUF1QkMsR0FBdkIsSUFBOEIsSUFBOUI7QUFDQTtBQUNLO0FBQ0o7O0FBRUosU0FBS0ksa0JBQUw7QUFFQSxTQUFLK0IsZUFBTCxDQUFxQjBDLGVBQWUsQ0FBQy9HLElBQWhCLENBQXFCK0QsQ0FBMUMsRUFBNkNnRCxlQUFlLENBQUMvRyxJQUFoQixDQUFxQmdFLENBQWxFLEVBQXFFK0MsZUFBZSxDQUFDL0csSUFBaEIsQ0FBcUJrSCxHQUExRixFQUErRkgsZUFBZSxDQUFDL0csSUFBaEIsQ0FBcUJtSCxHQUFwSDtBQUVBLFNBQUtuSSxRQUFMLEdBQWdCK0gsZUFBZSxDQUFDL0csSUFBaEIsQ0FBcUJvSCxLQUFyQztBQUNBLFNBQUtqSSxZQUFMLEdBQW9CLEtBQUtILFFBQUwsR0FBZ0J6QixRQUFRLENBQUM2QixTQUFULENBQW1CQyxHQUFuQyxHQUF5QzlCLFFBQVEsQ0FBQzZCLFNBQVQsQ0FBbUJtRCxLQUFoRixDQTdCMkIsQ0ErQnhCOztBQUNBLFFBQUlrRSxvQkFBb0IsR0FBR00sZUFBZSxDQUFDMUcsSUFBM0M7O0FBRUEsU0FBSSxJQUFJcUcsQ0FBUixJQUFhRCxvQkFBYixFQUFrQztBQUM5QixVQUFJRSxVQUFVLEdBQUdGLG9CQUFvQixDQUFDQyxDQUFELENBQXJDO0FBRUEsVUFBSXpFLEdBQUcsR0FBRzBFLFVBQVUsQ0FBQzVDLENBQXJCO0FBQ0EsVUFBSTdCLEdBQUcsR0FBR3lFLFVBQVUsQ0FBQzNDLENBQXJCO0FBQ0EsVUFBSTVFLFNBQVMsR0FBR3VILFVBQVUsQ0FBQ1UsR0FBM0I7QUFDQSxVQUFJZCxVQUFVLEdBQUdJLFVBQVUsQ0FBQ1csR0FBNUI7QUFDQSxVQUFJL0ksV0FBVyxHQUFHLEtBQUtxSSxvQkFBTCxDQUEwQnJKLFFBQVEsQ0FBQ3NKLGdCQUFULENBQTBCekgsU0FBMUIsRUFBcUNtSCxVQUFyQyxDQUExQixDQUFsQixDQVA4QixDQVU5Qjs7QUFDQSxVQUFJTyxLQUFLLEdBQUcsSUFBSXJKLEtBQUosQ0FBVTJCLFNBQVYsRUFBcUJtSCxVQUFyQixFQUFpQyxLQUFqQyxFQUF3Q3RFLEdBQXhDLEVBQTZDQyxHQUE3QyxFQUFrRDNELFdBQWxELENBQVosQ0FYOEIsQ0FZcEM7O0FBQ0EsVUFBSSxLQUFLVSxNQUFMLElBQWUsQ0FBbkIsRUFBcUI7QUFDcEI2SCxRQUFBQSxLQUFLLENBQUMzRSxhQUFOLENBQW9Cb0YsUUFBcEIsR0FBK0IsSUFBL0I7QUFDQVQsUUFBQUEsS0FBSyxDQUFDM0UsYUFBTixDQUFvQnFGLFdBQXBCLEdBQWtDeEosRUFBRSxDQUFDeUosRUFBSCxDQUFNLEdBQU4sRUFBVyxHQUFYLEVBQWdCLENBQWhCLENBQWxDLENBRm9CLENBSXBCO0FBQ0E7O0FBRUssVUFBSTVELENBQUMsR0FBSTNCLEdBQUcsR0FBRzNFLFFBQVEsQ0FBQ2tFLFNBQWYsR0FBMkJsRSxRQUFRLENBQUNtRSxlQUFULENBQXlCQyxLQUE3RDtBQUNBLFVBQUlpQyxDQUFDLEdBQUkzQixHQUFHLEdBQUcxRSxRQUFRLENBQUNrRSxTQUFmLEdBQTJCbEUsUUFBUSxDQUFDbUUsZUFBVCxDQUF5QkUsS0FBN0Q7QUFDQWtGLE1BQUFBLEtBQUssQ0FBQzNFLGFBQU4sQ0FBb0JYLFdBQXBCLENBQWdDcUMsQ0FBaEMsRUFBbUNELENBQW5DLEVBdEI4QixDQXdCcEM7O0FBQ0EsV0FBSzdELFNBQUwsR0FBaUIsR0FBakI7QUFFTSxXQUFLOEIsSUFBTCxDQUFVQyxRQUFWLENBQW1CZ0YsS0FBSyxDQUFDM0UsYUFBekIsRUEzQjhCLENBNkI5Qjs7QUFDQSxXQUFLckQsWUFBTCxDQUFrQm1ELEdBQWxCLEVBQXVCQyxHQUF2QixJQUE4QjRFLEtBQTlCO0FBQ0g7QUFDSixHQWx3Qk87QUFvd0JMO0FBQ0FGLEVBQUFBLG9CQUFvQixFQUFFLDhCQUFTYyxTQUFULEVBQW1CO0FBQ3JDLFFBQUlDLEtBQUssR0FBRzNKLEVBQUUsQ0FBQ3VELFdBQUgsQ0FBZSxLQUFLaEQsV0FBcEIsQ0FBWjtBQUNBb0osSUFBQUEsS0FBSyxDQUFDdEcsWUFBTixDQUFtQnJELEVBQUUsQ0FBQzRKLE1BQXRCLEVBQThCQyxXQUE5QixHQUE0QyxLQUFLekosV0FBTCxDQUFpQjBKLGNBQWpCLENBQWdDSixTQUFoQyxDQUE1QztBQUNBLFdBQU9DLEtBQVA7QUFDSCxHQXp3Qkk7QUEyd0JSO0FBQ0FyQixFQUFBQSxvQkFBb0IsRUFBRSw4QkFBU3hILFlBQVQsRUFBdUJtRCxHQUF2QixFQUE0QkMsR0FBNUIsRUFBaUNvQyxPQUFqQyxFQUEwQ0MsT0FBMUMsRUFBbURwRixZQUFuRCxFQUFpRW9ILFVBQWpFLEVBQTZFOUcsU0FBN0UsRUFBd0Y7QUFFN0csUUFBTXlGLEdBQUcsR0FBRyxFQUFaO0FBQ0FwRyxJQUFBQSxZQUFZLENBQUNvRSxPQUFiLENBQXFCLFVBQUFDLElBQUksRUFBSTtBQUM1QitCLE1BQUFBLEdBQUcsQ0FBQ2pCLElBQUosT0FBQWlCLEdBQUcscUJBQVMvQixJQUFULEVBQUg7QUFDQSxLQUZELEVBSDZHLENBTzdHOztBQUNBLFFBQUk0RCxlQUFlLEdBQUcsRUFBdEI7QUFDQTdCLElBQUFBLEdBQUcsQ0FBQ2hDLE9BQUosQ0FBWSxVQUFBQyxJQUFJLEVBQUk7QUFDbkIsVUFBR0EsSUFBSCxFQUFRO0FBQ1A0RCxRQUFBQSxlQUFlLENBQUM5QyxJQUFoQixDQUFxQjtBQUNwQnFELFVBQUFBLEdBQUcsRUFBRW5FLElBQUksQ0FBQzBCLFlBRFU7QUFFcEJ3QyxVQUFBQSxHQUFHLEVBQUVsRSxJQUFJLENBQUNSLFdBRlU7QUFHcEJvQixVQUFBQSxDQUFDLEVBQUVaLElBQUksQ0FBQ2lDLEtBSFk7QUFJcEJwQixVQUFBQSxDQUFDLEVBQUViLElBQUksQ0FBQ2tDO0FBSlksU0FBckI7QUFNQTtBQUNELEtBVEQ7QUFXQSxRQUFNaEYsSUFBSSxHQUFHO0FBQ1pBLE1BQUFBLElBQUksRUFBRTBHLGVBRE07QUFFWi9HLE1BQUFBLElBQUksRUFBRTtBQUNMb0gsUUFBQUEsS0FBSyxFQUFFakksWUFERjtBQUVMbUksUUFBQUEsR0FBRyxFQUFFZixVQUZBO0FBR0x4QyxRQUFBQSxDQUFDLEVBQUU5QixHQUhFO0FBSUwrQixRQUFBQSxDQUFDLEVBQUU5QixHQUpFO0FBS0xnRixRQUFBQSxHQUFHLEVBQUU1QyxPQUxBO0FBTUw2QyxRQUFBQSxHQUFHLEVBQUU1QztBQU5BO0FBRk0sS0FBYixDQXBCNkcsQ0FnQzdHOztBQUNBLFNBQUs5RSxTQUFMLENBQWVzSSxJQUFmLENBQW9CZixJQUFJLENBQUNnQixTQUFMLENBQWUzSCxJQUFmLENBQXBCO0FBQ0EsR0E5eUJPO0FBK3lCUjtBQUNBNEgsRUFBQUEsUUFBUSxFQUFFLGtCQUFVQyxTQUFWLEVBQXFCO0FBQzlCLGFBQVNDLGNBQVQsQ0FBeUI1SCxJQUF6QixFQUErQjtBQUM3QixVQUFJNkgsR0FBRyxHQUFHLElBQUlDLE1BQUosQ0FBVyxVQUFVOUgsSUFBVixHQUFpQixlQUE1QixDQUFWO0FBQ0EsVUFBSXdELENBQUMsR0FBR3VFLE1BQU0sQ0FBQ0MsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJDLE1BQXZCLENBQThCLENBQTlCLEVBQWlDQyxLQUFqQyxDQUF1Q04sR0FBdkMsQ0FBUixDQUY2QixDQUc3Qjs7QUFDQSxVQUFJckUsQ0FBQyxJQUFJLElBQVQsRUFBZSxPQUFPNEUsUUFBUSxDQUFDNUUsQ0FBQyxDQUFDLENBQUQsQ0FBRixDQUFmO0FBQ2YsYUFBTyxFQUFQO0FBQ0Q7O0FBQ0QsV0FBTzZFLGtCQUFrQixDQUFDVCxjQUFjLENBQUNELFNBQUQsQ0FBZixDQUF6QjtBQUNBLEdBenpCTztBQTJ6QlJXLEVBQUFBLFlBQVksRUFBRSx3QkFBWTtBQUFBOztBQUFFO0FBRTNCLFFBQU1DLE1BQU0sR0FBRyxLQUFLYixRQUFMLENBQWMsUUFBZCxLQUEyQixTQUExQztBQUNBLFFBQU1jLEdBQUcsR0FBRyxLQUFLZCxRQUFMLENBQWMsS0FBZCxLQUF3QixPQUFwQztBQUNBLFFBQU1lLEtBQUssR0FBRyx1Q0FBdUNGLE1BQXZDLEdBQWdELE9BQWhELEdBQTBEQyxHQUF4RTtBQUNBLFNBQUt0SixTQUFMLEdBQWlCLElBQUl3SixTQUFKLENBQWNELEtBQWQsQ0FBakI7O0FBRUEsU0FBS3ZKLFNBQUwsQ0FBZXlKLE1BQWYsR0FBd0IsVUFBQ0MsS0FBRCxFQUFXO0FBQ2xDLE1BQUEsTUFBSSxDQUFDekksWUFBTDtBQUNBLEtBRkQsQ0FQeUIsQ0FVekI7QUFDQTtBQUNBOzs7QUFDQSxTQUFLakIsU0FBTCxDQUFlVSxTQUFmLEdBQTJCLFVBQVNnSixLQUFULEVBQWdCO0FBQzFDckwsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlvTCxLQUFLLENBQUM5SSxJQUFsQjs7QUFDQSxVQUFHLENBQUNELEdBQUcsQ0FBQ0MsSUFBUixFQUFhLENBRVo7QUFDQTtBQUNBLE9BSkQsTUFLSztBQUVKdkMsUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlxQyxHQUFHLENBQUNDLElBQWhCO0FBQ0EsYUFBS0MsWUFBTCxDQUFrQkYsR0FBRyxDQUFDQyxJQUF0QjtBQUNBO0FBRUQsS0FiRDtBQWNBO0FBdDFCTyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIOWKn+iDve+8mua4uOaIj+aji+ebmOebuOWFs+mAu+i+kVxuICovXG5cbnZhciBDb25zdGFudCA9IHJlcXVpcmUoJy4vQ29uc3RhbnQuanMnKTtcbnZhciBTdG9uZSA9IHJlcXVpcmUoJy4vU3RvbmUuanMnKTtcbnZhciBNb3ZlUnVsZSA9IHJlcXVpcmUoXCIuL01vdmVSdWxlLmpzXCIpO1xudmFyIFJlcXVlc3QgPSByZXF1aXJlKFwiLi9SZXF1ZXN0LmpzXCIpO1xudmFyIE1vdmVIaXN0b3J5ID0gcmVxdWlyZShcIi4vTW92ZUhpc3RvcnkuanNcIik7XG5cbnZhciBnZXROYW1lID0gZnVuY3Rpb24gKCkge1xuXHRjb25zb2xlLmxvZygxMjMpXG59O1xuXG5cbi8vXG5jYy5DbGFzcyh7XG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuXG4gICAgICAgIC8v5Zu+6ZuG6LWE5rqQ77yM55So5LqO5Yid5aeL5YyW5qOL5a2QcHJlZmFiXG4gICAgICAgIHBpZWNlc0F0bGFzOiB7XG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxuICAgICAgICAgICAgdHlwZTogY2MuU3ByaXRlQXRsYXNcbiAgICAgICAgfSxcblxuICAgICAgICAvL+aji+WtkHByZWZhYlxuICAgICAgICBwaWVjZVByZWZhYjp7XG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxuICAgICAgICAgICAgdHlwZTogY2MuUHJlZmFiXG4gICAgICAgIH0sXG5cbiAgICAgICAgLy/lj6/otbDngrlwcmVmYWJcbiAgICAgICAgZG90UHJlZmFiOntcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5QcmVmYWJcbiAgICAgICAgfSxcblxuXHRcdC8v56e75Yqo5YmN5ZCO5qCH6K+GcHJlZmFiXG5cdFx0Ym94UHJlZmFiOntcblx0XHQgICAgZGVmYXVsdDogbnVsbCxcblx0XHQgICAgdHlwZTogY2MuUHJlZmFiXG5cdFx0fSxcblxuXHRcdC8v56e75Yqo5YmN5ZCO5qCH6K+GcHJlZmFiXG5cdFx0ZWF0UHJlZmFiOntcblx0XHQgICAgZGVmYXVsdDogbnVsbCxcblx0XHQgICAgdHlwZTogY2MuUHJlZmFiXG5cdFx0fSxcblxuXHRcdC8v5ri45oiP57uT5p2fcHJlZmFiXG5cdFx0Z2FtZU92ZXJQcmVmYWI6e1xuXHRcdCAgICBkZWZhdWx0OiBudWxsLFxuXHRcdCAgICB0eXBlOiBjYy5QcmVmYWJcblx0XHR9LFxuXG5cdFx0Ly/lsIblhptwcmVmYWJcblx0XHRraWxsUHJlZmFiOntcblx0XHQgICAgZGVmYXVsdDogbnVsbCxcblx0XHQgICAgdHlwZTogY2MuUHJlZmFiXG5cdFx0fSxcblxuICAgICAgICAvL+S6jOe7tOaVsOe7hOWtmOWCqOaji+WtkOaVsOaNrlxuICAgICAgICBwaWVjZXNBcnJBcnI6W10sXG5cblx0XHQvL+aYr+WQpuiOt+iDnFxuXHRcdGlzV2luOiBudWxsLFxuXG4gICAgICAgIC8v5piv5ZCm6L2u5Yiw5oiR5LiL5qOL5LqGXG4gICAgICAgIGlzTXlUdXJuOiB0cnVlLFxuXG5cdFx0Ly/ml4vovazop5LluqZcdDE4MOaIljBcblx0XHRyb3RhdGU6IDE4MCxcblxuICAgICAgICAvL+iHquW3seeCueWHu+eahOaji+WtkFxuICAgICAgICBtX2N1cl9jbGlja19zdG9uZTogbnVsbCxcblxuXHRcdC8v57qi6buR6LWw5qOL5a+55o2iXG5cdFx0cmVkX29yX2JsYWNrOiBDb25zdGFudC50dXJuX3R5cGUucmVkLFxuXG4gICAgICAgIC8v5Y+v56e75Yqo54K56aKE5Yi25L2T6ZuG5ZCIXG4gICAgICAgIGNhbl9tb3ZlX2RvdF9saXN0OiBbXSxcblxuXHRcdC8vIOWwhuW4heS9jee9rlx05Yid5aeL5Li65bCG5L2N572uXG5cdFx0amlhbmdfc2h1YWlfcm93OiA5LFxuXHRcdGppYW5nX3NodWFpX2NvbDogNCxcblxuXHRcdHdlYnNvY2tldDogJycsXG5cdFx0Ly8g6YG/5YWN6YeN5aSN6L+e5o6lXG5cdFx0bG9ja1JlY29ubmVjdDogZmFsc2UsXG5cblx0XHQvL+e6oum7keaWuVxuXHRcdHJlZExhYmVsOiAnMTIzNDU2Jyxcblx0XHRibGFja0xhYmVsOiAnNDU2MTMnLFxuXG5cdFx0dGltZTogY2MuTGFiZWwsXG5cdFx0Y291bnRkb3duOiAzMDAsICAgICAgICAgICAgIC8vICAgIOWAkuiuoeaXtueahOaXtumXtCDkuLoxMOenklxuXG5cdFx0bW92ZTogY2MuQW5pbWF0aW9uXG4gICAgfSxcblxuXHR1cGRhdGUoKSB7XG5cdFx0dGhpcy53ZWJzb2NrZXQub25tZXNzYWdlID0gKGV2dCkgPT4ge1xuXHRcdFx0Ly8gY29uc29sZS5sb2coZXZ0LmRhdGEpO1xuXHRcdFx0aWYoIWV2dC5kYXRhKXtcblxuXHRcdFx0XHQvLyDliJ3lp4vmo4vlrZDljoblj7LorrDlvZVcblx0XHRcdFx0Ly8gdGhpcy5zZW5kX2dhbWVfYm9hcmRfaW5mbyh0aGlzLnBpZWNlc0FyckFyciwgMjAsIDIwLCAyMCwgMjAsIENvbnN0YW50LnR1cm5fdHlwZS5ibGFjaywgdGhpcy53ZWJzb2NrZXQpO1xuXHRcdFx0fVxuXHRcdFx0ZWxzZSB7XG5cblx0XHRcdFx0dGhpcy5sb29rZXJTdG9uZXMoZXZ0LmRhdGEpO1xuXHRcdFx0fVxuXHRcdH1cblx0fSxcblx0Ly8g5rWL6K+V5YWo5bGA5o6l5Y+jXG5cdGdldE5hbWU6IGZ1bmN0aW9uIChuYW1lKSB7XG5cdFx0Y29uc29sZS5sb2cobmFtZSlcblx0fSxcblxuICAgIC8v57uE5Lu25Yqg6L295pe277yM6L+b6KGM5Y+Y6YeP5Yid5aeL5YyW5pON5L2cXG4gICAgb25Mb2FkICgpIHtcblxuXHRcdHRoaXMuZm5fY291bnRkb3duKCk7XG5cbiAgICBcdGdldE5hbWUgPSB0aGlzLmdldE5hbWU7XG5cdFx0Z2V0TmFtZSgn6L+Z5piv5LiA5Liq5YWo5bGA5Ye95pWw77yM5oiR55qE5ZCN5a2X5Y+r5YGa5rKZ5pGp5p+v77yBJyk7XG5cblx0XHQvLyDliJvlu7rov57mjqXlubbliJ3lp4vljJbmo4vlrZBcblx0XHQvLyB0aGlzLmdldHdlYnNvY2tldCgpXG5cblx0XHQvL+WIneWni+WMljMy6aKX5qOL5a2QXG5cdFx0dGhpcy5pbml0MzJTdG9uZXMoKTtcblxuXHRcdC8vIOWIneWni+WMlueCueWHu+S6i+S7tiDmsYLlkowg6K6k6L6TIOaClOajiyDph43lvIBcblx0XHRjb25zdCBzZWxmID0gdGhpcztcblx0XHRjYy5maW5kKFwiQ2FudmFzL3Nwcl9ib2FyZF9iZy9yZXRyYWN0XCIpLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX1NUQVJULCBmdW5jdGlvbihlKXtcblxuXHRcdFx0Ly8gdGhpcy5sb29rZXJTdG9uZXMoKTtcblxuXHRcdFx0dGhpcy5yb3RhdGVHYW1lQm9hcmQoKTtcblxuXG5cdFx0fS5iaW5kKHRoaXMpKVxuXG5cdFx0Y2MuZmluZChcImJ1dHRvblwiKS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9TVEFSVCwgZnVuY3Rpb24oZSl7XG5cdFx0XHRjYy5maW5kKFwic3RvbmVcIikuYWRkQ29tcG9uZW50KCdTdG9uZUFuaW1Db250cm9sJyk7XG5cdFx0XHRjYy5sb2coY2MuZmluZChcInN0b25lXCIpLmdldENvbXBvbmVudChjYy5BbmltYXRpb24pKTtcblx0XHR9LmJpbmQodGhpcykpO1xuXG5cblx0XHRjYy5maW5kKFwiQ2FudmFzL3Nwcl9ib2FyZF9iZy9naXZlX3VwXCIpLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX1NUQVJULCBmdW5jdGlvbihlKXtcblx0XHRcdGNvbnNvbGUubG9nKHNlbGYuaXNNeVR1cm4pO1xuXHRcdFx0c2VsZi5zaG93X3dpbihzZWxmLmlzTXlUdXJuKTtcblx0XHR9LmJpbmQodGhpcykpO1xuXG5cdFx0Y2MuZmluZChcIkNhbnZhcy9zcHJfYm9hcmRfYmcvZHJhd1wiKS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9TVEFSVCwgZnVuY3Rpb24oZSl7XG5cdFx0XHRjb25zb2xlLmxvZygn5ZKM5qOLJyk7XG5cdFx0XHRzZWxmLmlzV2luID0gMjtcblx0XHRcdHRoaXMuY291bnRkb3duID0gMDtcblx0XHRcdHZhciBnYW1lT3ZlclByZWZhYiA9IGNjLmluc3RhbnRpYXRlKHRoaXMuZ2FtZU92ZXJQcmVmYWIpO1xuXHRcdFx0Y29uc29sZS5sb2codGhpcy5nYW1lT3ZlclByZWZhYilcblx0XHRcdGdhbWVPdmVyUHJlZmFiLnNldFBvc2l0aW9uKDQgKiBDb25zdGFudC5jZWxsX3NpemUgLSBDb25zdGFudC5sZWZ0X2JvdHRvbV9wb3MubGVuX3gsXG5cdFx0XHRcdDQuNSAqIENvbnN0YW50LmNlbGxfc2l6ZSAtIENvbnN0YW50LmxlZnRfYm90dG9tX3Bvcy5sZW5feSk7XG5cdFx0XHR0aGlzLm5vZGUuYWRkQ2hpbGQoZ2FtZU92ZXJQcmVmYWIpO1xuXHRcdFx0Z2FtZU92ZXJQcmVmYWIucnVuQWN0aW9uKGNjLmZhZGVUbygyKSlcblx0XHR9LmJpbmQodGhpcykpXG5cblx0XHRjYy5maW5kKFwiQ2FudmFzL3Nwcl9ib2FyZF9iZy9yZW9wZW5cIikub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsIGZ1bmN0aW9uKGUpe1xuXHRcdFx0Y29uc29sZS5sb2coJ+mHjeW8gCcpO1xuXHRcdFx0dGhpcy5jb3VudGRvd24gPSAzMDA7XG5cdFx0XHR0aGlzLmlzV2luID0gbnVsbDtcblx0XHRcdC8v5Yid5aeL5YyW5qOL5a2Q5pWw57uE5L+h5oGvXG5cdFx0XHRmb3IodmFyIHJvdyA9IDA7IHJvdyA8PSA5OyByb3crKyl7XG5cdFx0XHQgICAgZm9yKHZhciBjb2wgPSAwOyBjb2wgPD0gODsgY29sKyspe1xuXHRcdFx0XHRcdGlmKHNlbGYucGllY2VzQXJyQXJyW3Jvd11bY29sXSl7XG5cdFx0XHRcdFx0XHRzZWxmLnBpZWNlc0FyckFycltyb3ddW2NvbF0ubV9waWVjZVByZWZhYi5yZW1vdmVGcm9tUGFyZW50KCk7XG5cdFx0XHRcdFx0XHRzZWxmLnBpZWNlc0FyckFycltyb3ddW2NvbF0gPSBudWxsO1xuXHRcdFx0XHRcdH1cblx0XHRcdCAgICB9XG5cdFx0XHR9XG5cdFx0XHRNb3ZlSGlzdG9yeS5oaXN0b3J5ID0gW107XG5cdFx0XHRzZWxmLmNsZWFyX2Nhbl9tb3ZlX2RvdCgpO1xuXHRcdFx0c2VsZi5yZWRfb3JfYmxhY2sgPSBDb25zdGFudC50dXJuX3R5cGUucmVkO1xuXHRcdFx0c2VsZi5pc015VHVybiA9IHRydWU7XG5cdFx0XHRzZWxmLmluaXQzMlN0b25lcygpO1xuXHRcdH0uYmluZCh0aGlzKSlcblxuICAgICAgICAvL+WIneWni+WMlueCueWHu+S6i+S7tlxuICAgICAgICB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsIGZ1bmN0aW9uKGUpe1xuXG4gICAgICAgICAgICBpZih0aGlzLmlzV2luICE9PSBudWxsKXtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygn5a+55byI57uT5p2f77yM6K+36YeN5paw5byA5aeLJyk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuXG5cdFx0XHR0aGlzLnJlZF9vcl9ibGFjayA9IHRoaXMuaXNNeVR1cm4gPyBDb25zdGFudC50dXJuX3R5cGUucmVkIDogQ29uc3RhbnQudHVybl90eXBlLmJsYWNrXHQvL1xuXG5cdFx0XHQvL+WIpOaWreaYr+WQpuaciei1sOaji+eahOadg+mZkFxuXHRcdFx0aWYodGhpcy5yZWRfb3JfYmxhY2sgPT09IENvbnN0YW50LnR1cm5fdHlwZS5yZWQpe1xuXHRcdFx0XHQvLyB0aGlzLmNoZWNrVXJsKCd1aW4nKVxuXHRcdFx0XHRpZiAodGhpcy5yZWRMYWJlbCAhPSAnMTIzNDU2Jyl7XG5cdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdC8vIGNvbnNvbGUubG9nKDEyMzQ1Nik7XG5cdFx0XHRcdH1cblx0XHRcdH1lbHNlIGlmICh0aGlzLnJlZF9vcl9ibGFjayA9PT0gQ29uc3RhbnQudHVybl90eXBlLmJsYWNrKXtcblx0XHRcdFx0aWYgKHRoaXMuYmxhY2tMYWJlbCAhPSAnNDU2MTMnKXtcblx0XHRcdFx0XHRyZXR1cm47XG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0Ly8gY29uc29sZS5sb2coNDU2MTMpO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cblxuICAgICAgICAgICAgLy9cbiAgICAgICAgICAgIHZhciBjbGlja19pbmZvID0gdGhpcy5nZXRfc2VsZWN0X3Jvd19jb2xfYnlfY2xpY2soZSk7XG4gICAgICAgICAgICB2YXIgcm93ID0gY2xpY2tfaW5mby5yb3c7XG4gICAgICAgICAgICB2YXIgY29sID0gY2xpY2tfaW5mby5jb2w7XG5cbiAgICAgICAgICAgIC8vXG4gICAgICAgICAgICBpZihyb3cgPCAwIHx8IHJvdyA+IDkgfHwgY29sIDwgMCB8fCBjb2wgPiA4KXtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9ZWxzZXtcbiAgICAgICAgICAgICAgICB2YXIgY2xpY2tfc3RvbmUgPSB0aGlzLnBpZWNlc0FyckFycltyb3ddW2NvbF07XG5cblx0XHRcdFx0Ly/ngrnkuK3kuobkuIDkuKrmo4vlrZBcblx0XHRcdFx0aWYoY2xpY2tfc3RvbmUpe1xuXHRcdFx0XHRcdC8v54K55LqG57qi5peX77yM5YiH5o2i5b2T5YmN6YCJ5Lit55qE5qOL5a2QXG5cdFx0XHRcdFx0Ly8gaWYoY2xpY2tfc3RvbmUubV90dXJuX3R5cGUgPT09IENvbnN0YW50LnR1cm5fdHlwZS5yZWQpe1xuXHRcdFx0XHRcdGlmKGNsaWNrX3N0b25lLm1fdHVybl90eXBlID09PSB0aGlzLnJlZF9vcl9ibGFjayl7XHQvL1xuXG5cdFx0XHRcdFx0XHR0aGlzLnNlbGVjdF9vbmVfc3RvbmUoY2xpY2tfc3RvbmUpO1xuXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdC8v54K55LqG6buR5qOL77yMMS7lpoLmnpzlvZPliY3msqHmnInpgInkuK3mo4vlrZDvvIzliJnmiqXplJkgMi7pgInkuK3kuobmo4vlrZDvvIzliJnor5Xlm77lkIPmjonlvZPliY3nmoTpu5Hmo4tcblx0XHRcdFx0XHRlbHNle1xuXG5cdFx0XHRcdFx0XHRpZighdGhpcy5tX2N1cl9jbGlja19zdG9uZSl7XG5cblx0XHRcdFx0XHRcdFx0Y29uc29sZS5sb2coJ+i9ruWIsCcgKyAodGhpcy5yZWRfb3JfYmxhY2sgPyAnYmxhY2snIDogJ3JlZCcpICsgJ+i1sOaji++8gScpXG5cblx0XHRcdFx0XHRcdH1lbHNle1xuXG5cdFx0XHRcdFx0XHRcdC8v6K+V5Zu+5Y675ZCD6buR6Imy5qOL5a2QIHRoaXMubV9jdXJfY2xpY2tfc3RvbmVcblx0XHRcdFx0XHRcdFx0aWYoTW92ZVJ1bGUuY2FuTW92ZSh0aGlzLCByb3csIGNvbCkpe1xuXHRcdFx0XHRcdFx0XHRcdHRoaXMua2lsbF9zdG9uZShyb3csIGNvbCk7XG5cdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdFx0Ly/pgInkuK3mo4vlrZDlkI7vvIzlj4jpgInmi6nkuobkuIDkuKrnqbrkvY3nva5cblx0XHRcdFx0ZWxzZXtcblx0XHRcdFx0XHRpZighdGhpcy5tX2N1cl9jbGlja19zdG9uZSl7XG5cblx0XHRcdFx0XHR9ZWxzZXtcblx0XHRcdFx0XHRcdGlmKE1vdmVSdWxlLmNhbk1vdmUodGhpcywgcm93LCBjb2wpKXtcblxuXHRcdFx0XHRcdFx0XHR0aGlzLm1vdmVfc3RvbmUocm93LCBjb2wpO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXG5cbiAgICAgICAgICAgIH1cblxuICAgICAgICB9LmJpbmQodGhpcyksIHRoaXMpO1xuICAgIH0sXG5cblx0Ly/ml4vovazmo4vnm5hcblx0cm90YXRlR2FtZUJvYXJkOiBmdW5jdGlvbiAoKSB7XG5cblx0XHR0aGlzLm5vZGUucnVuQWN0aW9uKGNjLnJvdGF0ZVRvKDAsIHRoaXMucm90YXRlLCB0aGlzLnJvdGF0ZSkpXG5cdFx0dGhpcy5ub2RlLmNoaWxkcmVuLmZvckVhY2goKGl0ZW0pID0+IHtcblx0XHRcdGl0ZW0ucnVuQWN0aW9uKGNjLnJvdGF0ZVRvKDAsIHRoaXMucm90YXRlLCB0aGlzLnJvdGF0ZSkpXG5cdFx0fSlcblx0XHR0aGlzLnJvdGF0ZSA9IHRoaXMucm90YXRlID09IDE4MCA/IDAgOiAxODA7XG5cdH0sXG5cblx0Zm5fY291bnRkb3duKCkge1xuXHRcdHRoaXMudGltZS5zdHJpbmcgPSAzMDA7ICAgICAgICAgICAvLyAg5Zy65pmv5paH5pys5qGG5Li6IOaYvuekujEwXG5cdFx0dGhpcy5jb3VudGRvd24gPSAzMDA7XG5cdFx0aWYgKHRoaXMuY291bnRkb3duID49IDApIHtcblx0XHRcdHRoaXMuc2NoZWR1bGUoZnVuY3Rpb24gKCkgeyAgICAvLyDorqHml7blmajlsIbmr4/pmpQgMXMg5omn6KGM5LiA5qyh44CCXG5cblx0XHRcdFx0dGhpcy5Eb1NvbWV0aGluZygpO1xuXHRcdFx0fSwgMSk7XG5cdFx0fVxuXHR9LFxuXHREb1NvbWV0aGluZygpIHsgICAgICAgICAgICAgICAgLy8g5YCS6K6h5pe2566X5rOVXG5cdFx0aWYgKHRoaXMuY291bnRkb3duID49IDEpIHtcblx0XHRcdHRoaXMuY291bnRkb3duID0gdGhpcy5jb3VudGRvd24gLSAxO1xuXHRcdFx0dGhpcy50aW1lLnN0cmluZyA9IHRoaXMuY291bnRkb3duOyAgICAvL+WcuuaZr+S4reaWh+acrOahhuaYvuekulxuXHRcdH0gZWxzZSB7XG5cdFx0XHR0aGlzLnNob3dfd2luKCF0aGlzLnJlZF9vcl9ibGFjaylcblx0XHR9XG5cdH0sXG5cbiAgICAvL+agueaNrueCueWHu+eCueiOt+WPlueCueWHu+eahOihjOWIl1xuICAgIGdldF9zZWxlY3Rfcm93X2NvbF9ieV9jbGljazogZnVuY3Rpb24oZSl7XG4gICAgICAgIHZhciBwb3MgPSB0aGlzLm5vZGUuY29udmVydFRvTm9kZVNwYWNlQVIoZS5nZXRMb2NhdGlvbigpKTtcblxuICAgICAgICB2YXIgcm93ID0gTWF0aC5mbG9vciggKHBvcy55ICsgQ29uc3RhbnQubGVmdF9ib3R0b21fcG9zLmxlbl95ICsgQ29uc3RhbnQuY2VsbF9zaXplKjAuNSkgLyBDb25zdGFudC5jZWxsX3NpemUpO1xuICAgICAgICB2YXIgY29sID0gTWF0aC5mbG9vciggKHBvcy54ICsgQ29uc3RhbnQubGVmdF9ib3R0b21fcG9zLmxlbl94ICsgQ29uc3RhbnQuY2VsbF9zaXplKjAuNSkgLyBDb25zdGFudC5jZWxsX3NpemUpO1xuXG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICByb3c6IHJvdyxcbiAgICAgICAgICAgIGNvbDogY29sXG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgLy/pgInkuK3kuIDpopfmo4vlrZDlkI4g5pi+56S65Y+v56e75Yqo55qE54K5XG4gICAgY2FuX21vdmVfZG90OiBmdW5jdGlvbiAoKXtcblxuICAgICAgICBmb3IobGV0IHIgPSAwOyByIDwgMTA7IHIrKyl7XG5cbiAgICAgICAgICAgIGZvcihsZXQgYyA9IDA7IGMgPCA5OyBjKyspe1xuXG4gICAgICAgICAgICAgICAgaWYoTW92ZVJ1bGUuY2FuTW92ZSh0aGlzLCByLCBjKSl7XG5cbiAgICAgICAgICAgICAgICAgICAgdmFyIHggPSAgYyAqIENvbnN0YW50LmNlbGxfc2l6ZSAtIENvbnN0YW50LmxlZnRfYm90dG9tX3Bvcy5sZW5feDtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHkgPSAgciAqIENvbnN0YW50LmNlbGxfc2l6ZSAtIENvbnN0YW50LmxlZnRfYm90dG9tX3Bvcy5sZW5feTtcblxuICAgICAgICAgICAgICAgICAgICAvL+WIm+W7uuWPr+enu+WKqGRvdOmihOWItuS9kyDlubblrZjlgqhcbiAgICAgICAgICAgICAgICAgICAgdmFyIGRvdFByZWZhYiA9IGNjLmluc3RhbnRpYXRlKHRoaXMuZG90UHJlZmFiKTtcbiAgICAgICAgICAgICAgICAgICAgZG90UHJlZmFiLnNldFBvc2l0aW9uKHgsIHkpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLm5vZGUuYWRkQ2hpbGQoZG90UHJlZmFiKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jYW5fbW92ZV9kb3RfbGlzdC5wdXNoKGRvdFByZWZhYik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSxcblxuICAgIC8v5riF6Zmk5Y+v56e75Yqo54K5ZG90IOenu+WKqOWJjeWQjuagh+iusGJveCDkvKDlj4JcbiAgICBjbGVhcl9jYW5fbW92ZV9kb3Q6IGZ1bmN0aW9uIChub19ib3gpe1xuXG5cdFx0aWYodGhpcy5jYW5fbW92ZV9kb3RfbGlzdC5sZW5ndGggPT09IDApIHJldHVybjtcblx0XHQvLyDnrKzkuIDkuKrkuLpib3jliJnkuI3muIXpmaTvvIzliJkw77yMMemDveS4umJveOS4jea4hemZpO+8jOWQpuWcqOWFqOmDqOa4hemZpFxuXHRcdGlmKHRoaXMuY2FuX21vdmVfZG90X2xpc3RbMF0ubmFtZSA9PT0gbm9fYm94KXtcblxuXHRcdFx0dGhpcy5jYW5fbW92ZV9kb3RfbGlzdC5zbGljZSgyKS5mb3JFYWNoKGl0ZW0gPT4ge1xuXG5cdFx0XHRcdGl0ZW0ucmVtb3ZlRnJvbVBhcmVudCgpO1xuXHRcdFx0fSlcblx0XHRcdHRoaXMuY2FuX21vdmVfZG90X2xpc3QgPSB0aGlzLmNhbl9tb3ZlX2RvdF9saXN0LnNsaWNlKDAsIDIpO1xuXG5cdFx0fSBlbHNlIHtcblx0XHRcdHRoaXMuY2FuX21vdmVfZG90X2xpc3QuZm9yRWFjaChpdGVtID0+IHtcblxuXHRcdFx0XHRpdGVtLnJlbW92ZUZyb21QYXJlbnQoKTtcblx0XHRcdH0pXG5cdFx0XHR0aGlzLmNhbl9tb3ZlX2RvdF9saXN0ID0gW107XG5cdFx0fVxuICAgIH0sXG5cblx0Ly8g6K6w5b2V56e75Yqo5YmN5ZCO5qOL5a2Q55qE5L2N572uXG5cdG1vdmVfZnJvbnRfYmFjazogZnVuY3Rpb24ocm93LCBjb2wsIG9sZF9yb3csIG9sZF9jb2wpIHtcblxuXHRcdHZhciB4ID0gIGNvbCAqIENvbnN0YW50LmNlbGxfc2l6ZSAtIENvbnN0YW50LmxlZnRfYm90dG9tX3Bvcy5sZW5feDtcblx0XHR2YXIgeSA9ICByb3cgKiBDb25zdGFudC5jZWxsX3NpemUgLSBDb25zdGFudC5sZWZ0X2JvdHRvbV9wb3MubGVuX3k7XG5cblx0XHRmb3IobGV0IGkgPSAwOyBpIDwgMjsgaSsrKXtcblxuXHRcdFx0dmFyIGJveFByZWZhYiA9IGNjLmluc3RhbnRpYXRlKHRoaXMuYm94UHJlZmFiKTtcblxuXHRcdFx0Ym94UHJlZmFiLnNldFBvc2l0aW9uKHgsIHkpO1xuXHRcdFx0dGhpcy5ub2RlLmFkZENoaWxkKGJveFByZWZhYik7XG5cdFx0XHR0aGlzLmNhbl9tb3ZlX2RvdF9saXN0LnB1c2goYm94UHJlZmFiKTtcblx0XHRcdHggPSAgb2xkX2NvbCAqIENvbnN0YW50LmNlbGxfc2l6ZSAtIENvbnN0YW50LmxlZnRfYm90dG9tX3Bvcy5sZW5feDtcblx0XHRcdHkgPSAgb2xkX3JvdyAqIENvbnN0YW50LmNlbGxfc2l6ZSAtIENvbnN0YW50LmxlZnRfYm90dG9tX3Bvcy5sZW5feTtcblx0XHR9XG5cdH0sXG5cblx0c2hvd193aW46IGZ1bmN0aW9uKHR1cm5fdHlwZSkge1xuXHRcdC8vIOiDnOWIqeadoeS7tuWIpOaWrVxuXHRcdGlmICh0dXJuX3R5cGUpIHtcblx0XHQgICAgY29uc29sZS5sb2coJ+m7keaWueiDnOWIqe+8ge+8ge+8gScpO1xuXHRcdCAgICB0aGlzLmlzV2luID0gQ29uc3RhbnQudHVybl90eXBlLmJsYWNrO1xuXHRcdH0gZWxzZSAge1xuXHRcdCAgICBjb25zb2xlLmxvZygn57qi5pa56IOc5Yip77yB77yB77yBJyk7XG5cdFx0XHR0aGlzLmlzV2luID0gQ29uc3RhbnQudHVybl90eXBlLnJlZDtcblx0XHR9XG5cdFx0dGhpcy5jb3VudGRvd24gPSAwO1xuXHRcdHZhciBnYW1lT3ZlclByZWZhYiA9IGNjLmluc3RhbnRpYXRlKHRoaXMuZ2FtZU92ZXJQcmVmYWIpO1xuXHRcdGdhbWVPdmVyUHJlZmFiLnNldFBvc2l0aW9uKDQgKiBDb25zdGFudC5jZWxsX3NpemUgLSBDb25zdGFudC5sZWZ0X2JvdHRvbV9wb3MubGVuX3gsXG5cdFx0XHQ0LjUgKiBDb25zdGFudC5jZWxsX3NpemUgLSBDb25zdGFudC5sZWZ0X2JvdHRvbV9wb3MubGVuX3kpO1xuXHRcdHRoaXMubm9kZS5hZGRDaGlsZChnYW1lT3ZlclByZWZhYik7XG5cdFx0Z2FtZU92ZXJQcmVmYWIucnVuQWN0aW9uKGNjLmZhZGVUbygyKSlcblx0fSxcblxuXHQvLyDlsIbluIXog73np7vliqjkvY3nva5cblx0Zm5famlhbmdfc2h1YWlfY2FuX21vdmU6IGZ1bmN0aW9uKCkge1xuXHRcdC8vIOWtmOWCqOWwhuaIluW4heiDvei1sOeahOS9jee9rlxuXHRcdHZhciBqaWFuZ19zaHVhaV9jYW5fbW92ZSA9IG5ldyBTZXQoKTtcblx0XHQvLyDotYvkuojlvZPliY3ngrnlh7vlr7nosaHkuLrlsIbmiJbluIVcblx0XHR0aGlzLm1fY3VyX2NsaWNrX3N0b25lID0gdGhpcy5waWVjZXNBcnJBcnJbdGhpcy5qaWFuZ19zaHVhaV9yb3ddW3RoaXMuamlhbmdfc2h1YWlfY29sXVxuXG5cdFx0Ly8g5re75Yqg5bCG5biF6Ieq5bex55qE5L2N572uXG5cdFx0amlhbmdfc2h1YWlfY2FuX21vdmUuYWRkKCd7XCJyb3dcIjonICsgdGhpcy5qaWFuZ19zaHVhaV9yb3cgKyAnLCcgKyAnXCJjb2xcIjonICsgdGhpcy5qaWFuZ19zaHVhaV9jb2wgKyAnfScpO1xuXHRcdGZvcihsZXQgciA9IDA7IHIgPCAxMDsgcisrKXtcblxuXHRcdCAgICBmb3IobGV0IGMgPSAzOyBjIDw9IDU7IGMrKyl7XG5cdFx0XHRcdC8vIOi3s+i/h+S5neWuq+agvOWklueahOWFtuS7luS9jee9riDorrDlvZXlsIbmiJbluIXkvY3nva5cblx0XHRcdFx0ciA9IHIgPT09IDMgPyA3IDogcjtcblx0XHRcdFx0Ly8g5oC75Li656e75Yqo5pa55bCG5biF5L2N572uXG5cdFx0XHRcdGlmKFxuXHRcdFx0XHRcdHRoaXMucGllY2VzQXJyQXJyW3JdW2NdICYmXG5cdFx0XHRcdFx0dGhpcy5waWVjZXNBcnJBcnJbcl1bY10ubV9zdG9uZV90eXBlID09PSA2ICYmXG5cdFx0XHRcdFx0dGhpcy5waWVjZXNBcnJBcnJbcl1bY10ubV90dXJuX3R5cGUgPT09IHRoaXMucmVkX29yX2JsYWNrXG5cdFx0XHRcdCl7XG5cdFx0XHRcdFx0dGhpcy5qaWFuZ19zaHVhaV9yb3cgPSByO1xuXHRcdFx0XHRcdHRoaXMuamlhbmdfc2h1YWlfY29sID0gYztcblx0XHRcdFx0fVxuXHRcdFx0XHQvLyDliKTmlq3lsIbluIXlj6/np7vliqjnmoTkvY3nva5cblx0XHQgICAvLyAgICAgIGlmKE1vdmVSdWxlLmNhbk1vdmUodGhpcywgciwgYykpe1xuXG5cdFx0XHRcdFx0Ly8gamlhbmdfc2h1YWlfY2FuX21vdmUuYWRkKCd7XCJyb3dcIjonICsgciArICcsJyArICdcImNvbFwiOicgKyBjICsgJ30nKTtcblx0XHQgICAvLyAgICAgIH1cblx0XHQgICAgfVxuXHRcdH1cblx0XHRyZXR1cm4gamlhbmdfc2h1YWlfY2FuX21vdmU7XG5cdH0sXG5cblx0Ly8g5pys5pa55qOL5a2Q55qE5pS75Ye76IyD5Zu0XG5cdGZuX21fYXR0YWNrX3Njb3BlOiBmdW5jdGlvbihvbGRfamlhbmdfc2h1YWlfcm93LCBvbGRfamlhbmdfc2h1YWlfY29sKSB7XG5cdFx0dmFyIG1fYWxsX2Nhbl9tb3ZlID0gbmV3IFNldCgpO1xuXHRcdC8vIOacrOaWueaJgOacieaji+WtkOiDvei1sOeahOS9jee9rlxuXHRcdGNvbnN0IGFyciA9IFtdXG5cdFx0dGhpcy5waWVjZXNBcnJBcnIuZm9yRWFjaChpdGVtID0+IHtcblx0XHRcdGFyci5wdXNoKC4uLml0ZW0pXG5cdFx0fSlcblxuXHRcdGFyci5mb3JFYWNoKGl0ZW0gPT4ge1xuXHRcdFx0Ly8g5pys5pa5XG5cdFx0XHRpZihpdGVtICYmIGl0ZW0ubV90dXJuX3R5cGUgPT09IHRoaXMucmVkX29yX2JsYWNrKXtcblxuXHRcdFx0XHR0aGlzLm1fY3VyX2NsaWNrX3N0b25lID0gaXRlbVxuXG5cdFx0XHRcdGZvcihsZXQgciA9IDA7IHIgPCAxMDsgcisrKXtcblxuXHRcdFx0XHQgICAgZm9yKGxldCBjID0gMDsgYyA8IDk7IGMrKyl7XG5cdFx0XHRcdFx0XHQvLyDmnKzmlrnmiYDmnInmo4vlrZDog73otbDnmoTkvY3nva5cblx0XHRcdFx0XHRcdGlmKE1vdmVSdWxlLmNhbk1vdmUodGhpcywgciwgYykpe1xuXG5cdFx0XHRcdFx0XHRcdGlmKHRoaXMubV9jdXJfY2xpY2tfc3RvbmUubV9zdG9uZV90eXBlID09PSA0KXtcblx0XHRcdFx0XHRcdFx0XHQvLyDngq4g54m55q6K77yM6ZyA6KaB6ZqU5a2QXG5cdFx0XHRcdFx0XHRcdFx0aWYob2xkX2ppYW5nX3NodWFpX3JvdyA9PT0gciAmJiBvbGRfamlhbmdfc2h1YWlfY29sID09PSBjKXtcblxuXHRcdFx0XHRcdFx0XHRcdFx0aWYoTW92ZVJ1bGUuZ2V0X3N0b25lX251bV9iZXR3ZWVuX3Jvd19jb2wodGhpcywgdGhpcy5tX2N1cl9jbGlja19zdG9uZS5tX3Jvdyxcblx0XHRcdFx0XHRcdFx0XHRcdFx0dGhpcy5tX2N1cl9jbGlja19zdG9uZS5tX2NvbCwgb2xkX2ppYW5nX3NodWFpX3Jvdywgb2xkX2ppYW5nX3NodWFpX2NvbCkgPT09IDEpe1xuXG5cdFx0XHRcdFx0XHRcdFx0XHRcdGlmKHRoaXMubV9jdXJfY2xpY2tfc3RvbmUubV9yb3cgPT09IG9sZF9qaWFuZ19zaHVhaV9yb3cpe1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdGlmKCF0aGlzLnBpZWNlc0FyckFycltyXVtjICsgMV0pe1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0bV9hbGxfY2FuX21vdmUuYWRkKCd7XCJyb3dcIjonICsgciArICcsJyArICdcImNvbFwiOicgKyAoYyArIDEpICsgJ30nKVxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRpZighdGhpcy5waWVjZXNBcnJBcnJbcl1bYyAtIDFdKXtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdG1fYWxsX2Nhbl9tb3ZlLmFkZCgne1wicm93XCI6JyArIHIgKyAnLCcgKyAnXCJjb2xcIjonICsgKGMgLSAxKSArICd9Jylcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdFx0XHRcdFx0aWYodGhpcy5tX2N1cl9jbGlja19zdG9uZS5tX2NvbCA9PT0gb2xkX2ppYW5nX3NodWFpX2NvbCl7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0aWYoKHIgKyAxKSA8PSA5ICYmICF0aGlzLnBpZWNlc0FyckFycltyICsgMV1bY10pe1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0bV9hbGxfY2FuX21vdmUuYWRkKCd7XCJyb3dcIjonICsgKHIgKyAxKSArICcsJyArICdcImNvbFwiOicgKyBjICsgJ30nKVxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRpZigociAtIDEpID49IDAgJiYgIXRoaXMucGllY2VzQXJyQXJyW3IgLSAxXVtjXSl7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRtX2FsbF9jYW5fbW92ZS5hZGQoJ3tcInJvd1wiOicgKyAociAtIDEpICsgJywnICsgJ1wiY29sXCI6JyArIGMgKyAnfScpXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHRcdFx0XHRcdFx0bV9hbGxfY2FuX21vdmUuYWRkKCd7XCJyb3dcIjonICsgciArICcsJyArICdcImNvbFwiOicgKyBjICsgJ30nKVxuXHRcdFx0XHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdFx0XHRtX2FsbF9jYW5fbW92ZS5hZGQoJ3tcInJvd1wiOicgKyByICsgJywnICsgJ1wiY29sXCI6JyArIGMgKyAnfScpO1xuXHRcdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdCAgICB9XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9KVxuXHRcdHJldHVybiBtX2FsbF9jYW5fbW92ZTtcblx0fSxcblxuXHQvLyDlsIblhptcdC8vIOe7neadgFxuXHRmaW5hbF9oaXQ6IGZ1bmN0aW9uKCkge1xuXG5cdFx0Y29uc3QgdGVtcCA9IHRoaXMubV9jdXJfY2xpY2tfc3RvbmU7XG5cblx0XHQvLyDlrZjlgqjmnKzmlrnlhajpg6jlrZDog73np7vliqjnmoTkvY3nva4g5YWIXG5cdFx0dmFyIG1fYWxsX2Nhbl9tb3ZlID0gdGhpcy5mbl9tX2F0dGFja19zY29wZSh0aGlzLmppYW5nX3NodWFpX3JvdywgdGhpcy5qaWFuZ19zaHVhaV9jb2wpO1xuXG5cdFx0Ly8g5a2Y5YKo5bCG5oiW5biF6IO956e75Yqo55qE5L2N572uIOWQjlxuXHRcdHZhciBqaWFuZ19zaHVhaV9jYW5fbW92ZSA9IHRoaXMuZm5famlhbmdfc2h1YWlfY2FuX21vdmUoKTtcblxuXHRcdHRoaXMubV9jdXJfY2xpY2tfc3RvbmUgPSB0ZW1wO1xuXG5cdFx0dmFyIHNpemUgPSBqaWFuZ19zaHVhaV9jYW5fbW92ZS5zaXplO1xuXHRcdC8vIOa4hemZpOW9k+WJjeWwhuW4heeahOW9k+WJjeeCueWHu1xuXHRcdGppYW5nX3NodWFpX2Nhbl9tb3ZlLmZvckVhY2goaXRlbSA9PiB7XG5cdFx0XHQvLyDliKTmlq3lsIbluIXlj6/np7vliqjnmoTkvY3nva4g5piv5ZCm5ZyoIOacrOaWueaJgOacieaji+WtkOWPr+enu+WKqOS9jee9ruiMg+WbtOWGhVxuXHRcdFx0aWYobV9hbGxfY2FuX21vdmUuaGFzKGl0ZW0pKXtcblxuXHRcdFx0XHRqaWFuZ19zaHVhaV9jYW5fbW92ZS5kZWxldGUoaXRlbSlcblx0XHRcdH1cblx0XHR9KVxuXHRcdGlmKHNpemUgIT09IGppYW5nX3NodWFpX2Nhbl9tb3ZlLnNpemUpe1xuXHRcdFx0Y29uc29sZS5sb2coJ+WwhuWGmycpO1x0Ly8g5Yqo55S7XG5cdFx0XHR2YXIga2lsbFByZWZhYiA9IGNjLmluc3RhbnRpYXRlKHRoaXMua2lsbFByZWZhYik7XG5cdFx0XHRraWxsUHJlZmFiLnNldFBvc2l0aW9uKDQgKiBDb25zdGFudC5jZWxsX3NpemUgLSBDb25zdGFudC5sZWZ0X2JvdHRvbV9wb3MubGVuX3gsIDQuNSAqIENvbnN0YW50LmNlbGxfc2l6ZSAtIENvbnN0YW50LmxlZnRfYm90dG9tX3Bvcy5sZW5feSk7XG5cdFx0XHR0aGlzLm5vZGUuYWRkQ2hpbGQoa2lsbFByZWZhYik7XG5cdFx0XHRraWxsUHJlZmFiLnJ1bkFjdGlvbihjYy5mYWRlVG8oMikpXG5cdFx0XHRzZXRUaW1lb3V0KCgpID0+IHtcblx0XHRcdFx0a2lsbFByZWZhYi5yZW1vdmVGcm9tUGFyZW50KClcblx0XHRcdH0sIDIwMDApXG5cdFx0fVxuXHRcdGZvciAobGV0IGkgPSAwOyBpIDwgMTA7IGkrKykge1xuXG5cdFx0XHRpZih0aGlzLnBpZWNlc0FyckFycltpXVt0aGlzLmppYW5nX3NodWFpX2NvbF0gJiZcblx0XHRcdFx0dGhpcy5waWVjZXNBcnJBcnJbaV1bdGhpcy5qaWFuZ19zaHVhaV9jb2xdLm1fc3RvbmVfdHlwZSA9PT0gNiAmJlxuXHRcdFx0XHR0aGlzLnBpZWNlc0FyckFycltpXVt0aGlzLmppYW5nX3NodWFpX2NvbF0ubV9yb3cgIT09IHRoaXMuamlhbmdfc2h1YWlfcm93KXtcblxuXHRcdFx0XHRpZiAoTW92ZVJ1bGUuZ2V0X3N0b25lX251bV9iZXR3ZWVuX3Jvd19jb2wodGhpcywgaSwgdGhpcy5qaWFuZ19zaHVhaV9jb2wsIHRoaXMuamlhbmdfc2h1YWlfcm93LCB0aGlzLmppYW5nX3NodWFpX2NvbCkgPT09IDApe1xuXHRcdFx0XHRcdHRoaXMuc2hvd193aW4oIXRoaXMucmVkX29yX2JsYWNrKVxuXHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0fSxcblxuICAgIC8v6YCJ5Lit5LiA6aKX5qOL5a2QXG4gICAgc2VsZWN0X29uZV9zdG9uZTogZnVuY3Rpb24oY2xpY2tfc3RvbmUpe1xuXG4gICAgICAgIGlmKHRoaXMuY2FuX21vdmVfZG90X2xpc3Qpe1xuXG4gICAgICAgICAgICB0aGlzLmNsZWFyX2Nhbl9tb3ZlX2RvdCgnYm94JylcbiAgICAgICAgfVxuXG4gICAgICAgIGlmKHRoaXMubV9jdXJfY2xpY2tfc3RvbmUpe1xuICAgICAgICAgICAgdmFyIHByZV9wcmVmYWIgPSB0aGlzLm1fY3VyX2NsaWNrX3N0b25lLm1fcGllY2VQcmVmYWI7XG4gICAgICAgICAgICBwcmVfcHJlZmFiLnN0b3BBbGxBY3Rpb25zKCk7XG4gICAgICAgICAgICBwcmVfcHJlZmFiLnNjYWxlID0gMTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8v5Yi35paw5paw55qE5qOL5a2QXG4gICAgICAgIHRoaXMubV9jdXJfY2xpY2tfc3RvbmUgPSBjbGlja19zdG9uZTtcbiAgICAgICAgdmFyIHByZWZhYiA9IHRoaXMubV9jdXJfY2xpY2tfc3RvbmUubV9waWVjZVByZWZhYjtcbiAgICAgICAgcHJlZmFiLnN0b3BBbGxBY3Rpb25zKCk7XG4gICAgICAgIHByZWZhYi5zY2FsZSA9IDE7XG4gICAgICAgIHByZWZhYi5ydW5BY3Rpb24oY2MucmVwZWF0Rm9yZXZlcihjYy5zZXF1ZW5jZShjYy5zY2FsZVRvKDAuNSwgMC44KSwgY2Muc2NhbGVUbygwLjUsIDEuMCkpKSk7XG5cbiAgICAgICAgLy/liKTmlq3lj6/np7vliqjngrlcbiAgICAgICAgdGhpcy5jYW5fbW92ZV9kb3QoKVxuICAgIH0sXG5cbiAgICAvL+adgOatu+aji+WtkFxuICAgIGtpbGxfc3RvbmU6IGZ1bmN0aW9uKHJvdywgY29sKXtcblxuXHRcdC8vIOaji+WtkOenu+WKqOWKqOeUu1xuXHRcdGNvbnN0IG15U3ByaXRlID0gdGhpcy5tX2N1cl9jbGlja19zdG9uZS5tX3BpZWNlUHJlZmFiO1xuXHRcdGNvbnN0IG1vdmVUbyA9IGNjLm1vdmVUbygwLjIsIGNvbCAqIENvbnN0YW50LmNlbGxfc2l6ZSAtIENvbnN0YW50LmxlZnRfYm90dG9tX3Bvcy5sZW5feCwgcm93ICogQ29uc3RhbnQuY2VsbF9zaXplIC0gQ29uc3RhbnQubGVmdF9ib3R0b21fcG9zLmxlbl95KTtcblx0XHRteVNwcml0ZS5ydW5BY3Rpb24obW92ZVRvKTtcblxuXHRcdC8vIOWumuaXtuWZqCDmo4vlrZDnp7vliqjlrozlkI7lho3ov5vooYzkuIvkuIDmraXmk43kvZxcblx0XHRzZXRUaW1lb3V0KCgpID0+IHtcblx0XHRcdC8vMS7pu5Hmo4vooqvlkIPmjolcblx0XHRcdHZhciBlYXRCbGFja1N0b25lID0gdGhpcy5waWVjZXNBcnJBcnJbcm93XVtjb2xdO1xuXG5cdFx0XHRlYXRCbGFja1N0b25lLm1faXNfZGVhZCA9IHRydWU7XG5cdFx0XHRlYXRCbGFja1N0b25lLm1fcGllY2VQcmVmYWIucmVtb3ZlRnJvbVBhcmVudCgpO1xuXG5cdFx0XHQvLzIu5a2Y55qE55qE57qi5qOL55qE5L2N572u572u56m6XG5cdFx0XHR0aGlzLnBpZWNlc0FyckFyclt0aGlzLm1fY3VyX2NsaWNrX3N0b25lLm1fcm93XVt0aGlzLm1fY3VyX2NsaWNrX3N0b25lLm1fY29sXSA9IG51bGw7XG5cdFx0XHR2YXIgb2xkX3JvdyA9IHRoaXMubV9jdXJfY2xpY2tfc3RvbmUubV9yb3c7XG5cdFx0XHR2YXIgb2xkX2NvbCA9IHRoaXMubV9jdXJfY2xpY2tfc3RvbmUubV9jb2w7XG5cblx0XHRcdC8vMy7otbDmo4vlkI7kv67mlLnnuqLml5flsZ7mgKdcblx0XHRcdHRoaXMubV9jdXJfY2xpY2tfc3RvbmUubV9yb3cgPSByb3c7XG5cdFx0XHR0aGlzLm1fY3VyX2NsaWNrX3N0b25lLm1fY29sID0gY29sO1xuXG5cdFx0XHQvLzQu5L+u5pS557qi5peX5paw55qEVUnkvY3nva5cblx0XHRcdHZhciB4ID0gIGNvbCAqIENvbnN0YW50LmNlbGxfc2l6ZSAtIENvbnN0YW50LmxlZnRfYm90dG9tX3Bvcy5sZW5feDtcblx0XHRcdHZhciB5ID0gIHJvdyAqIENvbnN0YW50LmNlbGxfc2l6ZSAtIENvbnN0YW50LmxlZnRfYm90dG9tX3Bvcy5sZW5feTtcblx0XHRcdHRoaXMubV9jdXJfY2xpY2tfc3RvbmUubV9waWVjZVByZWZhYi5zZXRQb3NpdGlvbih4LCB5KTtcblxuXHRcdFx0Ly81LuWIt+aWsOWtmOWCqFxuXHRcdFx0dGhpcy5waWVjZXNBcnJBcnJbcm93XVtjb2xdID0gdGhpcy5tX2N1cl9jbGlja19zdG9uZTtcblxuXHRcdFx0Ly8g5ZCR5pyN5Yqh5Zmo5Y+R6YCB6LWw5qOL6K6w5b2VXG5cdFx0XHR0aGlzLnNlbmRfZ2FtZV9ib2FyZF9pbmZvKHRoaXMucGllY2VzQXJyQXJyLCByb3csIGNvbCwgb2xkX3Jvdywgb2xkX2NvbCxcblx0XHRcdFx0dGhpcy5yZWRfb3JfYmxhY2ssIHRoaXMubV9jdXJfY2xpY2tfc3RvbmUubV9zdG9uZV90eXBlLCB0aGlzLndlYnNvY2tldCk7XG5cblx0XHRcdC8vNi7otbDlrozmo4vlkI7orr7nva7lvZPliY3mnKrpgInkuK3mo4vlrZBcblx0XHRcdHZhciBwcmVmYWIgPSB0aGlzLm1fY3VyX2NsaWNrX3N0b25lLm1fcGllY2VQcmVmYWI7XG5cdFx0XHRwcmVmYWIuc3RvcEFsbEFjdGlvbnMoKTtcblx0XHRcdHByZWZhYi5zY2FsZSA9IDE7XG5cdFx0XHR0aGlzLm1fY3VyX2NsaWNrX3N0b25lID0gbnVsbDtcblxuXHRcdFx0Ly83Lui9ruWIsOWvueaWuei1sOaji1xuXHRcdFx0dGhpcy5pc015VHVybiA9ICF0aGlzLmlzTXlUdXJuXHQvL1xuXG5cdFx0XHQvLyBjb25zb2xlLmxvZygn5ZCDIScpOyDliqjnlLtcblx0XHRcdHZhciBlYXRQcmVmYWIgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLmVhdFByZWZhYik7XG5cdFx0XHRlYXRQcmVmYWIuc2V0UG9zaXRpb24oNCAqIENvbnN0YW50LmNlbGxfc2l6ZSAtIENvbnN0YW50LmxlZnRfYm90dG9tX3Bvcy5sZW5feCxcblx0XHRcdFx0NC41ICogQ29uc3RhbnQuY2VsbF9zaXplIC0gQ29uc3RhbnQubGVmdF9ib3R0b21fcG9zLmxlbl95KTtcblx0XHRcdHRoaXMubm9kZS5hZGRDaGlsZChlYXRQcmVmYWIpO1xuXHRcdFx0ZWF0UHJlZmFiLnJ1bkFjdGlvbihjYy5mYWRlVG8oMikpXG5cdFx0XHRzZXRUaW1lb3V0KCgpID0+IHtcblx0XHRcdFx0ZWF0UHJlZmFiLnJlbW92ZUZyb21QYXJlbnQoKVxuXHRcdFx0fSwgMjAwMClcblxuXHRcdFx0Ly8g6IOc5Yip5p2h5Lu2IOWwhuW4heiiq+WQg1xuXHRcdFx0aWYoZWF0QmxhY2tTdG9uZS5tX3N0b25lX3R5cGUgPT09IENvbnN0YW50LnN0b25lX3R5cGUuamlhbmcpe1xuXHRcdFx0XHR0aGlzLnNob3dfd2luKCFlYXRCbGFja1N0b25lLm1fdHVybl90eXBlKTtcblx0XHRcdH1cblxuXHRcdFx0Ly/muIXpmaTlj6/np7vliqjngrnnmoTpooTliLbkvZNcblx0XHRcdHRoaXMuY2xlYXJfY2FuX21vdmVfZG90KCk7XG5cblx0XHRcdC8vIOagh+iusOenu+WKqOWJjeWQjueahOS9jee9rlxuXHRcdFx0dGhpcy5tb3ZlX2Zyb250X2JhY2socm93LCBjb2wsIG9sZF9yb3csIG9sZF9jb2wpO1xuXG5cdFx0XHQvLyDlsIblhpsg57ud5p2AXG5cdFx0XHR0aGlzLmZpbmFsX2hpdCgpO1xuXG5cdFx0XHR0aGlzLmNvdW50ZG93biA9IDMwMDtcblxuXHRcdH0sIDIwMClcbiAgICB9LFxuICAgIC8v56e75Yqo5qOL5a2QXG4gICAgbW92ZV9zdG9uZTogZnVuY3Rpb24ocm93LCBjb2wpe1xuXG5cdFx0Ly8g5qOL5a2Q56e75Yqo5Yqo55S7XG5cdFx0Y29uc3QgbXlTcHJpdGUgPSB0aGlzLm1fY3VyX2NsaWNrX3N0b25lLm1fcGllY2VQcmVmYWI7XG5cdFx0Y29uc3QgbW92ZVRvID0gY2MubW92ZVRvKDAuMywgY29sICogQ29uc3RhbnQuY2VsbF9zaXplIC0gQ29uc3RhbnQubGVmdF9ib3R0b21fcG9zLmxlbl94LFxuXHRcdFx0cm93ICogQ29uc3RhbnQuY2VsbF9zaXplIC0gQ29uc3RhbnQubGVmdF9ib3R0b21fcG9zLmxlbl95KTtcblx0XHRteVNwcml0ZS5ydW5BY3Rpb24obW92ZVRvKTtcblxuXG5cdFx0Ly8g5a6a5pe25ZmoIOaji+WtkOenu+WKqOWujOWQjuWGjei/m+ihjOS4i+S4gOatpeaTjeS9nFxuXHRcdHNldFRpbWVvdXQoKCkgPT4ge1xuXHRcdFx0Ly8xLua4heeQhuWOn+adpeS9jee9rlxuXHRcdFx0dmFyIG9sZF9yb3cgPSB0aGlzLm1fY3VyX2NsaWNrX3N0b25lLm1fcm93O1xuXHRcdFx0dmFyIG9sZF9jb2wgPSB0aGlzLm1fY3VyX2NsaWNrX3N0b25lLm1fY29sO1xuXHRcdFx0dGhpcy5waWVjZXNBcnJBcnJbb2xkX3Jvd11bb2xkX2NvbF0gPSBudWxsO1xuXG5cblx0XHRcdC8vMi7orr7nva7mlrDnmoTmlbDmja5cblx0XHRcdHRoaXMubV9jdXJfY2xpY2tfc3RvbmUubV9yb3cgPSByb3c7XG5cdFx0XHR0aGlzLm1fY3VyX2NsaWNrX3N0b25lLm1fY29sID0gY29sO1xuXHRcdFx0dGhpcy5waWVjZXNBcnJBcnJbcm93XVtjb2xdID0gdGhpcy5tX2N1cl9jbGlja19zdG9uZTtcblxuXHRcdFx0Ly8zLuabtOaWsOS9jee9rlxuXHRcdFx0dmFyIHggPSAgY29sICogQ29uc3RhbnQuY2VsbF9zaXplIC0gQ29uc3RhbnQubGVmdF9ib3R0b21fcG9zLmxlbl94XG5cdFx0XHR2YXIgeSA9ICByb3cgKiBDb25zdGFudC5jZWxsX3NpemUgLSBDb25zdGFudC5sZWZ0X2JvdHRvbV9wb3MubGVuX3k7XG5cdFx0XHR0aGlzLm1fY3VyX2NsaWNrX3N0b25lLm1fcGllY2VQcmVmYWIuc2V0UG9zaXRpb24oeCwgeSk7XG5cblx0XHRcdC8vIOWQkeacjeWKoeWZqOWPkemAgei1sOaji+iusOW9lVxuXHRcdFx0dGhpcy5zZW5kX2dhbWVfYm9hcmRfaW5mbyh0aGlzLnBpZWNlc0FyckFyciwgcm93LCBjb2wsIG9sZF9yb3csIG9sZF9jb2wsXG5cdFx0XHRcdHRoaXMucmVkX29yX2JsYWNrLCB0aGlzLm1fY3VyX2NsaWNrX3N0b25lLm1fc3RvbmVfdHlwZSwgdGhpcy53ZWJzb2NrZXQpO1xuXG5cdFx0XHQvLzQu6LWw5a6M5qOL5a2Q5YGc5q2i5Yqo5L2cXG5cdFx0XHR2YXIgcHJlZmFiID0gdGhpcy5tX2N1cl9jbGlja19zdG9uZS5tX3BpZWNlUHJlZmFiO1xuXHRcdFx0cHJlZmFiLnN0b3BBbGxBY3Rpb25zKCk7XG5cdFx0XHRwcmVmYWIuc2NhbGUgPSAxO1xuXHRcdFx0dGhpcy5tX2N1cl9jbGlja19zdG9uZSA9IG51bGw7XG5cblx0XHRcdC8vNS7ova7liLDlr7nmlrnotbDmo4tcblx0XHRcdHRoaXMuaXNNeVR1cm4gPSAhdGhpcy5pc015VHVyblx0Ly9cblxuXHRcdFx0Ly/muIXpmaTlj6/np7vliqjngrnnmoTpooTliLbkvZNcblx0XHRcdHRoaXMuY2xlYXJfY2FuX21vdmVfZG90KCk7XG5cblx0XHRcdC8vIOagh+iusOenu+WKqOWJjeWQjueahOS9jee9rlxuXHRcdFx0dGhpcy5tb3ZlX2Zyb250X2JhY2socm93LCBjb2wsIG9sZF9yb3csIG9sZF9jb2wpO1xuXG5cdFx0XHQvLyDlsIblhpsg57ud5p2AXG5cdFx0XHR0aGlzLmZpbmFsX2hpdCgpXG5cblx0XHRcdHRoaXMuY291bnRkb3duID0gMzAwO1xuXG5cdFx0fSwgMzAxKVxuICAgIH0sXG5cbiAgICAvL+WIneWni+WMljMy6aKX5qOL5a2QXG4gICAgaW5pdDMyU3RvbmVzOiBmdW5jdGlvbigpe1xuXG4gICAgICAgIC8v5Yid5aeL5YyW5qOL5a2Q5pWw57uE5L+h5oGvXG4gICAgICAgIGZvcih2YXIgcm93ID0gMDsgcm93IDw9IDk7IHJvdysrKXtcbiAgICAgICAgICAgIHRoaXMucGllY2VzQXJyQXJyW3Jvd10gPSBbXTtcbiAgICAgICAgICAgIGZvcih2YXIgY29sID0gMDsgY29sIDw9IDg7IGNvbCsrKXtcbiAgICAgICAgICAgICAgICB0aGlzLnBpZWNlc0FyckFycltyb3ddW2NvbF0gPSBudWxsO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy/mo4vlrZDliJ3lp4vljJbkv6Hmga9cbiAgICAgICAgdmFyIGdhbWVfYm9hcmRfaW5pdF9pbmZvID0gQ29uc3RhbnQuZ2FtZV9ib2FyZF9pbml0X2luZm87XG5cbiAgICAgICAgZm9yKHZhciBrIGluIGdhbWVfYm9hcmRfaW5pdF9pbmZvKXtcbiAgICAgICAgICAgIHZhciBzdG9uZV9pbmZvID0gZ2FtZV9ib2FyZF9pbml0X2luZm9ba107XG5cbiAgICAgICAgICAgIHZhciByb3cgPSBzdG9uZV9pbmZvLnJvdztcbiAgICAgICAgICAgIHZhciBjb2wgPSBzdG9uZV9pbmZvLmNvbDtcbiAgICAgICAgICAgIHZhciB0dXJuX3R5cGUgPSBzdG9uZV9pbmZvLnR1cm5fdHlwZTtcbiAgICAgICAgICAgIHZhciBzdG9uZV90eXBlID0gc3RvbmVfaW5mby5zdG9uZV90eXBlO1xuICAgICAgICAgICAgdmFyIHBpZWNlUHJlZmFiID0gdGhpcy5jcmVhdGVPbmVQaWVjZUJ5TmFtZShDb25zdGFudC5zdG9uZV9yZXNfY29uZmlnW3R1cm5fdHlwZV1bc3RvbmVfdHlwZV0pO1xuXG4gICAgICAgICAgICAvL+WIm+W7uuS4gOmil+aji+WtkFxuICAgICAgICAgICAgdmFyIHN0b25lID0gbmV3IFN0b25lKHR1cm5fdHlwZSwgc3RvbmVfdHlwZSwgZmFsc2UsIHJvdywgY29sLCBwaWVjZVByZWZhYik7XG5cbiAgICAgICAgICAgIHZhciB4ID0gIGNvbCAqIENvbnN0YW50LmNlbGxfc2l6ZSAtIENvbnN0YW50LmxlZnRfYm90dG9tX3Bvcy5sZW5feFxuICAgICAgICAgICAgdmFyIHkgPSAgcm93ICogQ29uc3RhbnQuY2VsbF9zaXplIC0gQ29uc3RhbnQubGVmdF9ib3R0b21fcG9zLmxlbl95O1xuICAgICAgICAgICAgc3RvbmUubV9waWVjZVByZWZhYi5zZXRQb3NpdGlvbih4LCB5KTtcbiAgICAgICAgICAgIHRoaXMubm9kZS5hZGRDaGlsZChzdG9uZS5tX3BpZWNlUHJlZmFiKTtcblxuICAgICAgICAgICAgLy/lrZjlgqjmo4vlrZDkv6Hmga9cbiAgICAgICAgICAgIHRoaXMucGllY2VzQXJyQXJyW3Jvd11bY29sXSA9IHN0b25lO1xuICAgICAgICB9XG4gICAgfSxcblxuXHQvL+WIneWni+WMluingueci+iAheaji+WtkOWPmOWMllxuXHRsb29rZXJTdG9uZXM6IGZ1bmN0aW9uKGRhdGEpe1xuXHRcdHZhciBnYW1lX2JvYXJkX2luZm8gPSBKU09OLnBhcnNlKGRhdGEpO1xuXG5cdFx0Ly8gaWYoTW92ZUhpc3RvcnkucG9pbnRlciA8IDEpe1xuXHRcdC8vIFx0dmFyIGdhbWVfYm9hcmRfaW5mbyA9IEpTT04ucGFyc2UoTW92ZUhpc3RvcnkuaGlzdG9yeVswXSk7XG5cdFx0Ly8gfSBlbHNlIHtcblx0XHQvLyBcdE1vdmVIaXN0b3J5LnBvaW50ZXItLTtcblx0XHQvLyBcdHZhciBnYW1lX2JvYXJkX2luZm8gPSBKU09OLnBhcnNlKE1vdmVIaXN0b3J5Lmhpc3RvcnlbTW92ZUhpc3RvcnkucG9pbnRlcl0pO1xuXHRcdC8vIFx0TW92ZUhpc3RvcnkuaGlzdG9yeS5wb3AoKTtcblx0XHQvLyB9XG5cblx0XHQvLyBjb25zb2xlLmxvZyhnYW1lX2JvYXJkX2luZm8ubW92ZS5yX29fYiwgZ2FtZV9ib2FyZF9pbmZvLCB0aGlzLmlzTXlUdXJuKTtcblxuXHQgICAgLy/liJ3lp4vljJbmo4vlrZDmlbDnu4Tkv6Hmga9cblx0ICAgIGZvcih2YXIgcm93ID0gMDsgcm93IDw9IDk7IHJvdysrKXtcblx0ICAgICAgICAvLyB0aGlzLnBpZWNlc0FyckFycltyb3ddID0gW107XG5cdCAgICAgICAgZm9yKHZhciBjb2wgPSAwOyBjb2wgPD0gODsgY29sKyspe1xuXHRcdFx0XHRpZih0aGlzLnBpZWNlc0FyckFycltyb3ddW2NvbF0pe1xuXHRcdFx0XHRcdHRoaXMucGllY2VzQXJyQXJyW3Jvd11bY29sXS5tX3BpZWNlUHJlZmFiLnJlbW92ZUZyb21QYXJlbnQoKTtcblx0XHRcdFx0XHR0aGlzLnBpZWNlc0FyckFycltyb3ddW2NvbF0gPSBudWxsO1xuXHRcdFx0XHR9XG5cdCAgICAgICAgfVxuXHQgICAgfVxuXG5cdFx0dGhpcy5jbGVhcl9jYW5fbW92ZV9kb3QoKTtcblxuXHRcdHRoaXMubW92ZV9mcm9udF9iYWNrKGdhbWVfYm9hcmRfaW5mby5tb3ZlLnIsIGdhbWVfYm9hcmRfaW5mby5tb3ZlLmMsIGdhbWVfYm9hcmRfaW5mby5tb3ZlLm9fciwgZ2FtZV9ib2FyZF9pbmZvLm1vdmUub19jKTtcblxuXHRcdHRoaXMuaXNNeVR1cm4gPSBnYW1lX2JvYXJkX2luZm8ubW92ZS5yX29fYjtcblx0XHR0aGlzLnJlZF9vcl9ibGFjayA9IHRoaXMuaXNNeVR1cm4gPyBDb25zdGFudC50dXJuX3R5cGUucmVkIDogQ29uc3RhbnQudHVybl90eXBlLmJsYWNrO1xuXG5cdCAgICAvL+aji+WtkOWIneWni+WMluS/oeaBr1xuXHQgICAgdmFyIGdhbWVfYm9hcmRfaW5pdF9pbmZvID0gZ2FtZV9ib2FyZF9pbmZvLmRhdGE7XG5cblx0ICAgIGZvcih2YXIgayBpbiBnYW1lX2JvYXJkX2luaXRfaW5mbyl7XG5cdCAgICAgICAgdmFyIHN0b25lX2luZm8gPSBnYW1lX2JvYXJkX2luaXRfaW5mb1trXTtcblxuXHQgICAgICAgIHZhciByb3cgPSBzdG9uZV9pbmZvLnI7XG5cdCAgICAgICAgdmFyIGNvbCA9IHN0b25lX2luZm8uYztcblx0ICAgICAgICB2YXIgdHVybl90eXBlID0gc3RvbmVfaW5mby50X3Q7XG5cdCAgICAgICAgdmFyIHN0b25lX3R5cGUgPSBzdG9uZV9pbmZvLnNfdDtcblx0ICAgICAgICB2YXIgcGllY2VQcmVmYWIgPSB0aGlzLmNyZWF0ZU9uZVBpZWNlQnlOYW1lKENvbnN0YW50LnN0b25lX3Jlc19jb25maWdbdHVybl90eXBlXVtzdG9uZV90eXBlXSk7XG5cblxuXHQgICAgICAgIC8v5Yib5bu65LiA6aKX5qOL5a2QXG5cdCAgICAgICAgdmFyIHN0b25lID0gbmV3IFN0b25lKHR1cm5fdHlwZSwgc3RvbmVfdHlwZSwgZmFsc2UsIHJvdywgY29sLCBwaWVjZVByZWZhYik7XG5cdFx0XHQvL+aji+ebmOaXi+i9rOWQjuavj+asoea4suafk+aXi+i9rOaji+WtkFxuXHRcdFx0aWYgKHRoaXMucm90YXRlID09IDApe1xuXHRcdFx0XHRzdG9uZS5tX3BpZWNlUHJlZmFiLmlzM0ROb2RlID0gdHJ1ZTtcblx0XHRcdFx0c3RvbmUubV9waWVjZVByZWZhYi5ldWxlckFuZ2xlcyA9IGNjLnYzKDE4MCwgMTgwLCAwKTtcblxuXHRcdFx0XHQvLyBzdG9uZS5tX3BpZWNlUHJlZmFiLnJ1bkFjdGlvbihjYy5yb3RhdGVUbygwLCAxODAsIDE4MCkpXG5cdFx0XHR9XG5cblx0ICAgICAgICB2YXIgeCA9ICBjb2wgKiBDb25zdGFudC5jZWxsX3NpemUgLSBDb25zdGFudC5sZWZ0X2JvdHRvbV9wb3MubGVuX3hcblx0ICAgICAgICB2YXIgeSA9ICByb3cgKiBDb25zdGFudC5jZWxsX3NpemUgLSBDb25zdGFudC5sZWZ0X2JvdHRvbV9wb3MubGVuX3k7XG5cdCAgICAgICAgc3RvbmUubV9waWVjZVByZWZhYi5zZXRQb3NpdGlvbih4LCB5KTtcblxuXHRcdFx0Ly/liJ3lp4vljJblgJLorqHml7Zcblx0XHRcdHRoaXMuY291bnRkb3duID0gMzAwO1xuXG5cdCAgICAgICAgdGhpcy5ub2RlLmFkZENoaWxkKHN0b25lLm1fcGllY2VQcmVmYWIpO1xuXG5cdCAgICAgICAgLy/lrZjlgqjmo4vlrZDkv6Hmga9cblx0ICAgICAgICB0aGlzLnBpZWNlc0FyckFycltyb3ddW2NvbF0gPSBzdG9uZTtcblx0ICAgIH1cblx0fSxcblxuICAgIC8v5qC55o2u5qOL5a2Q5ZCN56ew5Yib5bu65LiA6aKX5qOL5a2QXG4gICAgY3JlYXRlT25lUGllY2VCeU5hbWU6IGZ1bmN0aW9uKHBpZWNlTmFtZSl7XG4gICAgICAgIHZhciBwaWVjZSA9IGNjLmluc3RhbnRpYXRlKHRoaXMucGllY2VQcmVmYWIpO1xuICAgICAgICBwaWVjZS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZSA9IHRoaXMucGllY2VzQXRsYXMuZ2V0U3ByaXRlRnJhbWUocGllY2VOYW1lKTtcbiAgICAgICAgcmV0dXJuIHBpZWNlO1xuICAgIH0sXG5cblx0Ly8g5Y+R6YCB6K+35rGCXG5cdHNlbmRfZ2FtZV9ib2FyZF9pbmZvOiBmdW5jdGlvbihwaWVjZXNBcnJBcnIsIHJvdywgY29sLCBvbGRfcm93LCBvbGRfY29sLCByZWRfb3JfYmxhY2ssIHN0b25lX3R5cGUsIHdlYnNvY2tldCkge1xuXG5cdFx0Y29uc3QgYXJyID0gW11cblx0XHRwaWVjZXNBcnJBcnIuZm9yRWFjaChpdGVtID0+IHtcblx0XHRcdGFyci5wdXNoKC4uLml0ZW0pXG5cdFx0fSlcblxuXHRcdC8vIOenu+WKqOivt+axguaVsOaNrlxuXHRcdHZhciBnYW1lX2JvYXJkX2luZm8gPSBbXVxuXHRcdGFyci5mb3JFYWNoKGl0ZW0gPT4ge1xuXHRcdFx0aWYoaXRlbSl7XG5cdFx0XHRcdGdhbWVfYm9hcmRfaW5mby5wdXNoKHtcblx0XHRcdFx0XHRzX3Q6IGl0ZW0ubV9zdG9uZV90eXBlLFxuXHRcdFx0XHRcdHRfdDogaXRlbS5tX3R1cm5fdHlwZSxcblx0XHRcdFx0XHRyOiBpdGVtLm1fcm93LFxuXHRcdFx0XHRcdGM6IGl0ZW0ubV9jb2xcblx0XHRcdFx0fSlcblx0XHRcdH1cblx0XHR9KVxuXG5cdFx0Y29uc3QgZGF0YSA9IHtcblx0XHRcdGRhdGE6IGdhbWVfYm9hcmRfaW5mbyxcblx0XHRcdG1vdmU6IHtcblx0XHRcdFx0cl9vX2I6IHJlZF9vcl9ibGFjayxcblx0XHRcdFx0c190OiBzdG9uZV90eXBlLFxuXHRcdFx0XHRyOiByb3csXG5cdFx0XHRcdGM6IGNvbCxcblx0XHRcdFx0b19yOiBvbGRfcm93LFxuXHRcdFx0XHRvX2M6IG9sZF9jb2wsXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gY29uc29sZS5sb2codGhpcy53ZWJzb2NrZXQpXG5cdFx0dGhpcy53ZWJzb2NrZXQuc2VuZChKU09OLnN0cmluZ2lmeShkYXRhKSk7XG5cdH0sXG5cdC8vIHVybOe8lueggVxuXHRjaGVja1VybDogZnVuY3Rpb24gKHNlYXJjaFN0cikge1xuXHRcdGZ1bmN0aW9uIGdldFF1ZXJ5U3RyaW5nIChuYW1lKSB7XG5cdFx0ICB2YXIgcmVnID0gbmV3IFJlZ0V4cCgnKF58JiknICsgbmFtZSArICc9KFteJl0qKSgmfCQpJylcblx0XHQgIHZhciByID0gd2luZG93LmxvY2F0aW9uLnNlYXJjaC5zdWJzdHIoMSkubWF0Y2gocmVnKVxuXHRcdCAgLy8gdmFyIHIgPSAncm9vbWlkPTQ2ODM0NTYmdWluPTQ1NjEzJy5tYXRjaChyZWcpO1xuXHRcdCAgaWYgKHIgIT0gbnVsbCkgcmV0dXJuIHVuZXNjYXBlKHJbMl0pXG5cdFx0ICByZXR1cm4gJyc7XG5cdFx0fVxuXHRcdHJldHVybiBlbmNvZGVVUklDb21wb25lbnQoZ2V0UXVlcnlTdHJpbmcoc2VhcmNoU3RyKSlcblx0fSxcblxuXHRnZXR3ZWJzb2NrZXQ6IGZ1bmN0aW9uICgpIHsgLy/mlrDlu7p3ZWJzb2NrZXTnmoTlh73mlbAg6aG16Z2i5Yid5aeL5YyWIOaWreW8gOi/nuaOpeaXtumHjeaWsOiwg+eUqFxuXG5cdFx0Y29uc3Qgcm9vbWlkID0gdGhpcy5jaGVja1VybCgncm9vbWlkJykgfHwgJzQ2ODM0NTYnO1xuXHRcdGNvbnN0IHVpbiA9IHRoaXMuY2hlY2tVcmwoJ3VpbicpIHx8ICc0NTYxMyc7XG5cdFx0Y29uc3Qgd3NVcmwgPSAnd3M6Ly8xOTIuMTY4LjIuMTQxOjgwMTAvd3M/cm9vbWlkPScgKyByb29taWQgKyAnJnVpbj0nICsgdWluO1xuXHRcdHRoaXMud2Vic29ja2V0ID0gbmV3IFdlYlNvY2tldCh3c1VybCk7XG5cblx0XHR0aGlzLndlYnNvY2tldC5vbm9wZW4gPSAoZXZlbnQpID0+IHtcblx0XHRcdHRoaXMuaW5pdDMyU3RvbmVzKCk7XG5cdFx0fTtcblx0XHQvLyB0aGlzLndlYnNvY2tldC5vbmNsb3NlID0gKGV2ZW50KSA9PiB7XG5cdFx0Ly8gXHQvL2NvbnNvbGUubG9nKCd3ZWJzb2NrZXTmnI3liqHlhbPpl63kuoYnKTtcblx0XHQvLyB9O1xuXHRcdHRoaXMud2Vic29ja2V0Lm9ubWVzc2FnZSA9IGZ1bmN0aW9uKGV2ZW50KSB7XG5cdFx0XHRjb25zb2xlLmxvZyhldmVudC5kYXRhKTtcblx0XHRcdGlmKCFldnQuZGF0YSl7XG5cblx0XHRcdFx0Ly8g5Yid5aeL5qOL5a2Q5Y6G5Y+y6K6w5b2VXG5cdFx0XHRcdC8vIHRoaXMuc2VuZF9nYW1lX2JvYXJkX2luZm8odGhpcy5waWVjZXNBcnJBcnIsIDIwLCAyMCwgMjAsIDIwLCBDb25zdGFudC50dXJuX3R5cGUuYmxhY2ssIHRoaXMud2Vic29ja2V0KTtcblx0XHRcdH1cblx0XHRcdGVsc2Uge1xuXG5cdFx0XHRcdGNvbnNvbGUubG9nKGV2dC5kYXRhKTtcblx0XHRcdFx0dGhpcy5sb29rZXJTdG9uZXMoZXZ0LmRhdGEpO1xuXHRcdFx0fVxuXG5cdFx0fTtcblx0fVxuXG59KTtcbiJdfQ==