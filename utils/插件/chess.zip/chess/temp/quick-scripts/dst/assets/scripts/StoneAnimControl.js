
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/StoneAnimControl.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '9e8c0ws40ROj6MdY8IFf18a', 'StoneAnimControl');
// scripts/StoneAnimControl.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    anim: cc.Animation
  },
  // onLoad () {},
  start: function start() {
    this.playRun();
  },
  playRun: function playRun() {
    this.anim = cc.find("stone").getComponent(cc.Animation);
    this.anim.play('move');
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9zY3JpcHRzL1N0b25lQW5pbUNvbnRyb2wuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJhbmltIiwiQW5pbWF0aW9uIiwic3RhcnQiLCJwbGF5UnVuIiwiZmluZCIsImdldENvbXBvbmVudCIsInBsYXkiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxJQUFJLEVBQUVKLEVBQUUsQ0FBQ0s7QUFERCxHQUhQO0FBT0w7QUFFQUMsRUFBQUEsS0FUSyxtQkFTRztBQUNKLFNBQUtDLE9BQUw7QUFDSCxHQVhJO0FBYUxBLEVBQUFBLE9BQU8sRUFBRSxtQkFBWTtBQUNqQixTQUFLSCxJQUFMLEdBQVlKLEVBQUUsQ0FBQ1EsSUFBSCxDQUFRLE9BQVIsRUFBaUJDLFlBQWpCLENBQThCVCxFQUFFLENBQUNLLFNBQWpDLENBQVo7QUFDQSxTQUFLRCxJQUFMLENBQVVNLElBQVYsQ0FBZSxNQUFmO0FBQ0gsR0FoQkksQ0FrQkw7O0FBbEJLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNjLkNsYXNzKHtcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIGFuaW06IGNjLkFuaW1hdGlvblxuICAgIH0sXG5cbiAgICAvLyBvbkxvYWQgKCkge30sXG5cbiAgICBzdGFydCgpIHtcbiAgICAgICAgdGhpcy5wbGF5UnVuKCk7XG4gICAgfSxcblxuICAgIHBsYXlSdW46IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdGhpcy5hbmltID0gY2MuZmluZChcInN0b25lXCIpLmdldENvbXBvbmVudChjYy5BbmltYXRpb24pO1xuICAgICAgICB0aGlzLmFuaW0ucGxheSgnbW92ZScpO1xuICAgIH0sXG5cbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcbn0pO1xuIl19