
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/MoveRule.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '4c113ACGeZFJIhp64kT0X5a', 'MoveRule');
// scripts/MoveRule.js

"use strict";

/**
 * 移动规则
 */
var Constant = require("./Constant.js"); //-----------------私有的工具函数


var get_stone_num_between_row_col = function get_stone_num_between_row_col(game_board_info, from_row, from_col, to_row, to_col) {
  var count = 0; // 左右移动

  if (from_row === to_row) {
    var began_col = from_col;
    var end_col = to_col;

    if (from_col > to_col) {
      // 左走 保证 began_col < end_col
      began_col = to_col;
      end_col = from_col;
    } //	判断行子中间存在棋子数


    for (var i = began_col + 1; i <= end_col - 1; i++) {
      if (game_board_info.piecesArrArr[from_row][i]) {
        count++;
      }
    }
  } // 上下移动
  else if (from_col === to_col) {
      var began_row = from_row;
      var end_row = to_row;

      if (from_row > to_row) {
        // 下走 保证 began_row < end_row
        began_row = to_row;
        end_row = from_row;
      } // 判断行子中间存在棋子数


      for (var i = began_row + 1; i <= end_row - 1; i++) {
        if (game_board_info.piecesArrArr[i][from_col]) {
          count++;
        }
      }
    } // 移动前后中间存在的字数


  return count;
}; //车


var canMoveChe = function canMoveChe(game_board_info, row, col) {
  var m_cur_click_stone = game_board_info.m_cur_click_stone;
  var num = get_stone_num_between_row_col(game_board_info, m_cur_click_stone.m_row, m_cur_click_stone.m_col, row, col);

  if (m_cur_click_stone.m_row === row || m_cur_click_stone.m_col === col) {} else {
    // console.log("-----车只能移动直线");
    return false;
  }

  return num === 0;
}; //马


var canMoveMa = function canMoveMa(game_board_info, row, col) {
  var m_cur_click_stone = game_board_info.m_cur_click_stone;

  if (Math.abs(m_cur_click_stone.m_row - row) === 1) {
    if (Math.abs(m_cur_click_stone.m_col - col) === 2) {
      if (game_board_info.piecesArrArr[m_cur_click_stone.m_row][(m_cur_click_stone.m_col + col) / 2]) {
        // console.log("-----马脚被蹩");
        return false;
      }

      return true;
    } else {
      // console.log("-----马只能走日");
      return false;
    }
  } else if (Math.abs(m_cur_click_stone.m_row - row) === 2) {
    if (Math.abs(m_cur_click_stone.m_col - col) === 1) {
      if (game_board_info.piecesArrArr[(m_cur_click_stone.m_row + row) / 2][m_cur_click_stone.m_col]) {
        // console.log("-----马脚被蹩");
        return false;
      }

      return true;
    } else {
      // console.log("-----马只能走日");
      return false;
    }
  } else {
    // console.log("-----马只能走日");
    return false;
  }

  return true;
}; //象


var canMoveXiang = function canMoveXiang(game_board_info, row, col) {
  var m_cur_click_stone = game_board_info.m_cur_click_stone;

  if (m_cur_click_stone.m_turn_type === Constant.turn_type.black) {
    if (row < 5) {
      // console.log("-----象不能过河");
      return false;
    }
  } else if (m_cur_click_stone.m_turn_type === Constant.turn_type.red) {
    if (row > 4) {
      // console.log("-----相不能过河");
      return false;
    }
  }

  if (Math.abs(m_cur_click_stone.m_row - row) !== 2 || Math.abs(m_cur_click_stone.m_col - col) !== 2) {
    // console.log("-----相只能走田");
    return false;
  }

  if (game_board_info.piecesArrArr[(m_cur_click_stone.m_row + row) / 2][(m_cur_click_stone.m_col + col) / 2]) {
    // console.log("-----相眼被挡");
    return false;
  }

  return true;
}; //士


var canMoveShi = function canMoveShi(game_board_info, row, col) {
  var m_cur_click_stone = game_board_info.m_cur_click_stone;

  if (m_cur_click_stone.m_turn_type === Constant.turn_type.black) {
    if (col < 3 || col > 5 || row < 7) {
      // console.log("-----不能出宫");
      return false;
    }
  } else if (m_cur_click_stone.m_turn_type === Constant.turn_type.red) {
    if (col < 3 || col > 5 || row > 2) {
      // console.log("-----士不能出宫");
      return false;
    }
  }

  if (Math.abs(m_cur_click_stone.m_row - row) !== 1 || Math.abs(m_cur_click_stone.m_col - col) !== 1) {
    // console.log("-----士只能移动斜线");
    return false;
  }

  return true;
}; //炮


var canMovePao = function canMovePao(game_board_info, row, col) {
  //当前选中的棋子
  var m_cur_click_stone = game_board_info.m_cur_click_stone; //

  var num = get_stone_num_between_row_col(game_board_info, m_cur_click_stone.m_row, m_cur_click_stone.m_col, row, col);

  if (m_cur_click_stone.m_row === row || m_cur_click_stone.m_col === col) {} else {
    // console.log("-----移动炮必须满足在一条直线上");
    return false;
  } //仅仅移动(包括横和竖),则移动到的row col不能有子


  if (num == 0) {
    var stone = game_board_info.piecesArrArr[row][col];

    if (!stone) {
      return true;
    } else {
      // console.log("-----仅仅移动的话，不可以移动到有子的地方");
      return false;
    }
  } //吃一个子
  else if (num == 1) {
      var stone = game_board_info.piecesArrArr[row][col];

      if (stone) {
        return true;
      } else {
        // console.log("-----间山打子的话，必须有一个子");
        return false;
      }
    } //隔一子以上


  return false;
}; //兵


var canMoveBing = function canMoveBing(game_board_info, row, col) {
  var m_cur_click_stone = game_board_info.m_cur_click_stone;

  if (m_cur_click_stone.m_turn_type === Constant.turn_type.black) {
    if (m_cur_click_stone.m_row < row) {
      // console.log("-----卒不能后退");
      return false;
    }

    if (m_cur_click_stone.m_row > 4 && m_cur_click_stone.m_col !== col) {
      // console.log("-----卒未过河不能左右")
      return false;
    }
  } else if (m_cur_click_stone.m_turn_type === Constant.turn_type.red) {
    if (m_cur_click_stone.m_row > row) {
      // console.log("-----兵不能后退");
      return false;
    }

    if (m_cur_click_stone.m_row < 5 && m_cur_click_stone.m_col !== col) {
      // console.log("-----兵未过河不能左右")
      return false;
    }
  }

  if (Math.abs(m_cur_click_stone.m_row - row) > 1 || Math.abs(m_cur_click_stone.m_col - col) > 1) {
    // console.log("-----兵只能走一步");
    return false;
  }

  if (m_cur_click_stone.m_row === row || m_cur_click_stone.m_col === col) {} else {
    // console.log("-----兵只能移动直线");
    return false;
  }

  return true;
}; //将


var canMoveJiang = function canMoveJiang(game_board_info, row, col) {
  var m_cur_click_stone = game_board_info.m_cur_click_stone;

  if (m_cur_click_stone.m_turn_type === Constant.turn_type.black) {
    if (col < 3 || col > 5 || row < 7) {
      // console.log("-----将不能出宫");
      return false;
    }
  } else if (m_cur_click_stone.m_turn_type === Constant.turn_type.red) {
    if (col < 3 || col > 5 || row > 2) {
      // console.log("-----帅不能出宫");
      return false;
    }
  }

  if (Math.abs(m_cur_click_stone.m_row - row) > 1 || Math.abs(m_cur_click_stone.m_col - col) > 1) {
    // console.log("-----帅只能走一步");
    return false;
  }

  if (m_cur_click_stone.m_row === row || m_cur_click_stone.m_col === col) {} else {
    // console.log("-----帅只能移动直线");
    return false;
  }

  return true;
}; //


var canMove = function canMove(game_board_info, row, col) {
  var m_cur_click_stone = game_board_info.m_cur_click_stone; // console.log("你当前移动了" + Constant.stone_res_config[m_cur_click_stone.m_turn_type][m_cur_click_stone.m_stone_type]);
  // 剔除自己方的棋子

  if (game_board_info.piecesArrArr[row][col] && game_board_info.piecesArrArr[row][col].m_turn_type === m_cur_click_stone.m_turn_type) {
    return false;
  } //


  switch (m_cur_click_stone.m_stone_type) {
    //车
    case Constant.stone_type.che:
      return canMoveChe(game_board_info, row, col);
    //马

    case Constant.stone_type.ma:
      return canMoveMa(game_board_info, row, col);
    //象

    case Constant.stone_type.xiang:
      return canMoveXiang(game_board_info, row, col);
    //士

    case Constant.stone_type.shi:
      return canMoveShi(game_board_info, row, col);
    //炮

    case Constant.stone_type.pao:
      return canMovePao(game_board_info, row, col);
    //兵

    case Constant.stone_type.bing:
      return canMoveBing(game_board_info, row, col);
    //将

    case Constant.stone_type.jiang:
      return canMoveJiang(game_board_info, row, col);

    default:
      return false;
  }

  return false;
}; //导出规则表


module.exports = {
  canMove: canMove,
  get_stone_num_between_row_col: get_stone_num_between_row_col
};

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9zY3JpcHRzL01vdmVSdWxlLmpzIl0sIm5hbWVzIjpbIkNvbnN0YW50IiwicmVxdWlyZSIsImdldF9zdG9uZV9udW1fYmV0d2Vlbl9yb3dfY29sIiwiZ2FtZV9ib2FyZF9pbmZvIiwiZnJvbV9yb3ciLCJmcm9tX2NvbCIsInRvX3JvdyIsInRvX2NvbCIsImNvdW50IiwiYmVnYW5fY29sIiwiZW5kX2NvbCIsImkiLCJwaWVjZXNBcnJBcnIiLCJiZWdhbl9yb3ciLCJlbmRfcm93IiwiY2FuTW92ZUNoZSIsInJvdyIsImNvbCIsIm1fY3VyX2NsaWNrX3N0b25lIiwibnVtIiwibV9yb3ciLCJtX2NvbCIsImNhbk1vdmVNYSIsIk1hdGgiLCJhYnMiLCJjYW5Nb3ZlWGlhbmciLCJtX3R1cm5fdHlwZSIsInR1cm5fdHlwZSIsImJsYWNrIiwicmVkIiwiY2FuTW92ZVNoaSIsImNhbk1vdmVQYW8iLCJzdG9uZSIsImNhbk1vdmVCaW5nIiwiY2FuTW92ZUppYW5nIiwiY2FuTW92ZSIsIm1fc3RvbmVfdHlwZSIsInN0b25lX3R5cGUiLCJjaGUiLCJtYSIsInhpYW5nIiwic2hpIiwicGFvIiwiYmluZyIsImppYW5nIiwibW9kdWxlIiwiZXhwb3J0cyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTs7O0FBR0EsSUFBSUEsUUFBUSxHQUFHQyxPQUFPLENBQUMsZUFBRCxDQUF0QixFQUVBOzs7QUFDQSxJQUFJQyw2QkFBNkIsR0FBRyxTQUFoQ0EsNkJBQWdDLENBQVNDLGVBQVQsRUFBMEJDLFFBQTFCLEVBQW9DQyxRQUFwQyxFQUE4Q0MsTUFBOUMsRUFBc0RDLE1BQXRELEVBQTZEO0FBQzdGLE1BQUlDLEtBQUssR0FBRyxDQUFaLENBRDZGLENBRzdGOztBQUNBLE1BQUdKLFFBQVEsS0FBS0UsTUFBaEIsRUFBdUI7QUFFbkIsUUFBSUcsU0FBUyxHQUFHSixRQUFoQjtBQUNBLFFBQUlLLE9BQU8sR0FBR0gsTUFBZDs7QUFFQSxRQUFHRixRQUFRLEdBQUdFLE1BQWQsRUFBcUI7QUFBRTtBQUNuQkUsTUFBQUEsU0FBUyxHQUFHRixNQUFaO0FBQ0FHLE1BQUFBLE9BQU8sR0FBR0wsUUFBVjtBQUNILEtBUmtCLENBVW5COzs7QUFDQSxTQUFJLElBQUlNLENBQUMsR0FBR0YsU0FBUyxHQUFDLENBQXRCLEVBQXlCRSxDQUFDLElBQUlELE9BQU8sR0FBQyxDQUF0QyxFQUF5Q0MsQ0FBQyxFQUExQyxFQUE2QztBQUN6QyxVQUFHUixlQUFlLENBQUNTLFlBQWhCLENBQTZCUixRQUE3QixFQUF1Q08sQ0FBdkMsQ0FBSCxFQUE2QztBQUN6Q0gsUUFBQUEsS0FBSztBQUNSO0FBQ0o7QUFFSixHQWpCRCxDQWtCQTtBQWxCQSxPQW1CSyxJQUFHSCxRQUFRLEtBQUtFLE1BQWhCLEVBQXVCO0FBQ3hCLFVBQUlNLFNBQVMsR0FBR1QsUUFBaEI7QUFDQSxVQUFJVSxPQUFPLEdBQUdSLE1BQWQ7O0FBRUEsVUFBR0YsUUFBUSxHQUFHRSxNQUFkLEVBQXFCO0FBQUU7QUFDbkJPLFFBQUFBLFNBQVMsR0FBR1AsTUFBWjtBQUNBUSxRQUFBQSxPQUFPLEdBQUdWLFFBQVY7QUFDSCxPQVB1QixDQVN4Qjs7O0FBQ0EsV0FBSSxJQUFJTyxDQUFDLEdBQUdFLFNBQVMsR0FBQyxDQUF0QixFQUF5QkYsQ0FBQyxJQUFJRyxPQUFPLEdBQUMsQ0FBdEMsRUFBeUNILENBQUMsRUFBMUMsRUFBNkM7QUFDekMsWUFBR1IsZUFBZSxDQUFDUyxZQUFoQixDQUE2QkQsQ0FBN0IsRUFBZ0NOLFFBQWhDLENBQUgsRUFBNkM7QUFDekNHLFVBQUFBLEtBQUs7QUFDUjtBQUNKO0FBQ0osS0F0QzRGLENBd0M3Rjs7O0FBQ0EsU0FBT0EsS0FBUDtBQUNILENBMUNELEVBNkNBOzs7QUFDQSxJQUFJTyxVQUFVLEdBQUcsU0FBYkEsVUFBYSxDQUFTWixlQUFULEVBQTBCYSxHQUExQixFQUErQkMsR0FBL0IsRUFBbUM7QUFDaEQsTUFBSUMsaUJBQWlCLEdBQUdmLGVBQWUsQ0FBQ2UsaUJBQXhDO0FBRUEsTUFBSUMsR0FBRyxHQUFHakIsNkJBQTZCLENBQUNDLGVBQUQsRUFBa0JlLGlCQUFpQixDQUFDRSxLQUFwQyxFQUEyQ0YsaUJBQWlCLENBQUNHLEtBQTdELEVBQW9FTCxHQUFwRSxFQUF5RUMsR0FBekUsQ0FBdkM7O0FBRUEsTUFBR0MsaUJBQWlCLENBQUNFLEtBQWxCLEtBQTRCSixHQUE1QixJQUFtQ0UsaUJBQWlCLENBQUNHLEtBQWxCLEtBQTRCSixHQUFsRSxFQUFzRSxDQUVyRSxDQUZELE1BRUs7QUFDRDtBQUNOLFdBQU8sS0FBUDtBQUNHOztBQUVELFNBQU9FLEdBQUcsS0FBSyxDQUFmO0FBQ0gsQ0FiRCxFQWVBOzs7QUFDQSxJQUFJRyxTQUFTLEdBQUcsU0FBWkEsU0FBWSxDQUFTbkIsZUFBVCxFQUEwQmEsR0FBMUIsRUFBK0JDLEdBQS9CLEVBQW1DO0FBQ2xELE1BQUlDLGlCQUFpQixHQUFHZixlQUFlLENBQUNlLGlCQUF4Qzs7QUFFQSxNQUFHSyxJQUFJLENBQUNDLEdBQUwsQ0FBU04saUJBQWlCLENBQUNFLEtBQWxCLEdBQTBCSixHQUFuQyxNQUE0QyxDQUEvQyxFQUFpRDtBQUNoRCxRQUFHTyxJQUFJLENBQUNDLEdBQUwsQ0FBU04saUJBQWlCLENBQUNHLEtBQWxCLEdBQTBCSixHQUFuQyxNQUE0QyxDQUEvQyxFQUFpRDtBQUNoRCxVQUFHZCxlQUFlLENBQUNTLFlBQWhCLENBQTZCTSxpQkFBaUIsQ0FBQ0UsS0FBL0MsRUFBc0QsQ0FBQ0YsaUJBQWlCLENBQUNHLEtBQWxCLEdBQTBCSixHQUEzQixJQUFrQyxDQUF4RixDQUFILEVBQThGO0FBQzdGO0FBQ0EsZUFBTyxLQUFQO0FBQ0E7O0FBQ0QsYUFBTyxJQUFQO0FBQ0EsS0FORCxNQU1PO0FBQ047QUFDQSxhQUFPLEtBQVA7QUFDQTtBQUNELEdBWEQsTUFXTyxJQUFHTSxJQUFJLENBQUNDLEdBQUwsQ0FBU04saUJBQWlCLENBQUNFLEtBQWxCLEdBQTBCSixHQUFuQyxNQUE0QyxDQUEvQyxFQUFpRDtBQUN2RCxRQUFHTyxJQUFJLENBQUNDLEdBQUwsQ0FBU04saUJBQWlCLENBQUNHLEtBQWxCLEdBQTBCSixHQUFuQyxNQUE0QyxDQUEvQyxFQUFpRDtBQUNoRCxVQUFHZCxlQUFlLENBQUNTLFlBQWhCLENBQTZCLENBQUNNLGlCQUFpQixDQUFDRSxLQUFsQixHQUEwQkosR0FBM0IsSUFBa0MsQ0FBL0QsRUFBa0VFLGlCQUFpQixDQUFDRyxLQUFwRixDQUFILEVBQThGO0FBQzdGO0FBQ0EsZUFBTyxLQUFQO0FBQ0E7O0FBQ0QsYUFBTyxJQUFQO0FBQ0EsS0FORCxNQU1PO0FBQ047QUFDQSxhQUFPLEtBQVA7QUFDQTtBQUNELEdBWE0sTUFXQTtBQUNOO0FBQ0EsV0FBTyxLQUFQO0FBQ0E7O0FBRUQsU0FBTyxJQUFQO0FBQ0EsQ0EvQkQsRUFpQ0E7OztBQUNBLElBQUlJLFlBQVksR0FBRyxTQUFmQSxZQUFlLENBQVN0QixlQUFULEVBQTBCYSxHQUExQixFQUErQkMsR0FBL0IsRUFBbUM7QUFDckQsTUFBSUMsaUJBQWlCLEdBQUdmLGVBQWUsQ0FBQ2UsaUJBQXhDOztBQUVBLE1BQUdBLGlCQUFpQixDQUFDUSxXQUFsQixLQUFrQzFCLFFBQVEsQ0FBQzJCLFNBQVQsQ0FBbUJDLEtBQXhELEVBQThEO0FBQzdELFFBQUdaLEdBQUcsR0FBRyxDQUFULEVBQVc7QUFDVjtBQUNBLGFBQU8sS0FBUDtBQUNBO0FBQ0QsR0FMRCxNQUtPLElBQUdFLGlCQUFpQixDQUFDUSxXQUFsQixLQUFrQzFCLFFBQVEsQ0FBQzJCLFNBQVQsQ0FBbUJFLEdBQXhELEVBQTZEO0FBQ25FLFFBQUdiLEdBQUcsR0FBRyxDQUFULEVBQVc7QUFDVjtBQUNBLGFBQU8sS0FBUDtBQUNBO0FBQ0Q7O0FBRUQsTUFBR08sSUFBSSxDQUFDQyxHQUFMLENBQVNOLGlCQUFpQixDQUFDRSxLQUFsQixHQUEwQkosR0FBbkMsTUFBNEMsQ0FBNUMsSUFBaURPLElBQUksQ0FBQ0MsR0FBTCxDQUFTTixpQkFBaUIsQ0FBQ0csS0FBbEIsR0FBMEJKLEdBQW5DLE1BQTRDLENBQWhHLEVBQWtHO0FBQ2pHO0FBQ0EsV0FBTyxLQUFQO0FBQ0E7O0FBRUQsTUFBR2QsZUFBZSxDQUFDUyxZQUFoQixDQUE2QixDQUFDTSxpQkFBaUIsQ0FBQ0UsS0FBbEIsR0FBMEJKLEdBQTNCLElBQWtDLENBQS9ELEVBQWtFLENBQUNFLGlCQUFpQixDQUFDRyxLQUFsQixHQUEwQkosR0FBM0IsSUFBa0MsQ0FBcEcsQ0FBSCxFQUEwRztBQUN6RztBQUNBLFdBQU8sS0FBUDtBQUNBOztBQUVELFNBQU8sSUFBUDtBQUNBLENBMUJELEVBNEJBOzs7QUFDQSxJQUFJYSxVQUFVLEdBQUcsU0FBYkEsVUFBYSxDQUFTM0IsZUFBVCxFQUEwQmEsR0FBMUIsRUFBK0JDLEdBQS9CLEVBQW1DO0FBQ25ELE1BQUlDLGlCQUFpQixHQUFHZixlQUFlLENBQUNlLGlCQUF4Qzs7QUFFQSxNQUFHQSxpQkFBaUIsQ0FBQ1EsV0FBbEIsS0FBa0MxQixRQUFRLENBQUMyQixTQUFULENBQW1CQyxLQUF4RCxFQUE4RDtBQUM3RCxRQUFHWCxHQUFHLEdBQUcsQ0FBTixJQUFXQSxHQUFHLEdBQUcsQ0FBakIsSUFBc0JELEdBQUcsR0FBRyxDQUEvQixFQUFpQztBQUNoQztBQUNBLGFBQU8sS0FBUDtBQUNBO0FBQ0QsR0FMRCxNQUtPLElBQUdFLGlCQUFpQixDQUFDUSxXQUFsQixLQUFrQzFCLFFBQVEsQ0FBQzJCLFNBQVQsQ0FBbUJFLEdBQXhELEVBQTZEO0FBQ25FLFFBQUdaLEdBQUcsR0FBRyxDQUFOLElBQVdBLEdBQUcsR0FBRyxDQUFqQixJQUFzQkQsR0FBRyxHQUFHLENBQS9CLEVBQWlDO0FBQ2hDO0FBQ0EsYUFBTyxLQUFQO0FBQ0E7QUFDRDs7QUFFRCxNQUFHTyxJQUFJLENBQUNDLEdBQUwsQ0FBU04saUJBQWlCLENBQUNFLEtBQWxCLEdBQTBCSixHQUFuQyxNQUE0QyxDQUE1QyxJQUFpRE8sSUFBSSxDQUFDQyxHQUFMLENBQVNOLGlCQUFpQixDQUFDRyxLQUFsQixHQUEwQkosR0FBbkMsTUFBNEMsQ0FBaEcsRUFBa0c7QUFDakc7QUFDQSxXQUFPLEtBQVA7QUFDQTs7QUFFRCxTQUFPLElBQVA7QUFDQSxDQXJCRCxFQXVCQTs7O0FBQ0EsSUFBSWMsVUFBVSxHQUFHLFNBQWJBLFVBQWEsQ0FBUzVCLGVBQVQsRUFBMEJhLEdBQTFCLEVBQStCQyxHQUEvQixFQUFtQztBQUVoRDtBQUNBLE1BQUlDLGlCQUFpQixHQUFHZixlQUFlLENBQUNlLGlCQUF4QyxDQUhnRCxDQUtoRDs7QUFDQSxNQUFJQyxHQUFHLEdBQUdqQiw2QkFBNkIsQ0FBQ0MsZUFBRCxFQUFrQmUsaUJBQWlCLENBQUNFLEtBQXBDLEVBQTJDRixpQkFBaUIsQ0FBQ0csS0FBN0QsRUFBb0VMLEdBQXBFLEVBQXlFQyxHQUF6RSxDQUF2Qzs7QUFFQSxNQUFHQyxpQkFBaUIsQ0FBQ0UsS0FBbEIsS0FBNEJKLEdBQTVCLElBQW1DRSxpQkFBaUIsQ0FBQ0csS0FBbEIsS0FBNEJKLEdBQWxFLEVBQXNFLENBRXJFLENBRkQsTUFFSztBQUVEO0FBQ0EsV0FBTyxLQUFQO0FBQ0gsR0FkK0MsQ0FnQmhEOzs7QUFDQSxNQUFHRSxHQUFHLElBQUksQ0FBVixFQUFZO0FBQ1IsUUFBSWEsS0FBSyxHQUFHN0IsZUFBZSxDQUFDUyxZQUFoQixDQUE2QkksR0FBN0IsRUFBa0NDLEdBQWxDLENBQVo7O0FBRUEsUUFBRyxDQUFDZSxLQUFKLEVBQVU7QUFDTixhQUFPLElBQVA7QUFDSCxLQUZELE1BRUs7QUFDRDtBQUNBLGFBQU8sS0FBUDtBQUNIO0FBQ0osR0FURCxDQVVBO0FBVkEsT0FXSyxJQUFHYixHQUFHLElBQUksQ0FBVixFQUFZO0FBRWIsVUFBSWEsS0FBSyxHQUFHN0IsZUFBZSxDQUFDUyxZQUFoQixDQUE2QkksR0FBN0IsRUFBa0NDLEdBQWxDLENBQVo7O0FBQ0EsVUFBR2UsS0FBSCxFQUFTO0FBQ0wsZUFBTyxJQUFQO0FBQ0gsT0FGRCxNQUVLO0FBRUQ7QUFDQSxlQUFPLEtBQVA7QUFDSDtBQUVKLEtBdkMrQyxDQXlDaEQ7OztBQUNBLFNBQU8sS0FBUDtBQUNILENBM0NELEVBNkNBOzs7QUFDQSxJQUFJQyxXQUFXLEdBQUcsU0FBZEEsV0FBYyxDQUFTOUIsZUFBVCxFQUEwQmEsR0FBMUIsRUFBK0JDLEdBQS9CLEVBQW1DO0FBQ3BELE1BQUlDLGlCQUFpQixHQUFHZixlQUFlLENBQUNlLGlCQUF4Qzs7QUFFQSxNQUFHQSxpQkFBaUIsQ0FBQ1EsV0FBbEIsS0FBa0MxQixRQUFRLENBQUMyQixTQUFULENBQW1CQyxLQUF4RCxFQUE4RDtBQUM3RCxRQUFHVixpQkFBaUIsQ0FBQ0UsS0FBbEIsR0FBMEJKLEdBQTdCLEVBQWlDO0FBQ2hDO0FBQ0EsYUFBTyxLQUFQO0FBQ0E7O0FBRUQsUUFBR0UsaUJBQWlCLENBQUNFLEtBQWxCLEdBQTBCLENBQTFCLElBQStCRixpQkFBaUIsQ0FBQ0csS0FBbEIsS0FBNEJKLEdBQTlELEVBQWtFO0FBQ2pFO0FBQ0EsYUFBTyxLQUFQO0FBQ0E7QUFDRCxHQVZELE1BVU8sSUFBR0MsaUJBQWlCLENBQUNRLFdBQWxCLEtBQWtDMUIsUUFBUSxDQUFDMkIsU0FBVCxDQUFtQkUsR0FBeEQsRUFBNkQ7QUFDbkUsUUFBR1gsaUJBQWlCLENBQUNFLEtBQWxCLEdBQTBCSixHQUE3QixFQUFpQztBQUNoQztBQUNBLGFBQU8sS0FBUDtBQUNBOztBQUVELFFBQUdFLGlCQUFpQixDQUFDRSxLQUFsQixHQUEwQixDQUExQixJQUErQkYsaUJBQWlCLENBQUNHLEtBQWxCLEtBQTRCSixHQUE5RCxFQUFrRTtBQUNqRTtBQUNBLGFBQU8sS0FBUDtBQUNBO0FBQ0Q7O0FBR0QsTUFBR00sSUFBSSxDQUFDQyxHQUFMLENBQVNOLGlCQUFpQixDQUFDRSxLQUFsQixHQUEwQkosR0FBbkMsSUFBMEMsQ0FBMUMsSUFBK0NPLElBQUksQ0FBQ0MsR0FBTCxDQUFTTixpQkFBaUIsQ0FBQ0csS0FBbEIsR0FBMEJKLEdBQW5DLElBQTBDLENBQTVGLEVBQThGO0FBQzdGO0FBQ0EsV0FBTyxLQUFQO0FBQ0E7O0FBR0QsTUFBR0MsaUJBQWlCLENBQUNFLEtBQWxCLEtBQTRCSixHQUE1QixJQUFtQ0UsaUJBQWlCLENBQUNHLEtBQWxCLEtBQTRCSixHQUFsRSxFQUFzRSxDQUVyRSxDQUZELE1BRUs7QUFDRDtBQUNILFdBQU8sS0FBUDtBQUNBOztBQUVELFNBQU8sSUFBUDtBQUNBLENBeENELEVBMENBOzs7QUFDQSxJQUFJaUIsWUFBWSxHQUFHLFNBQWZBLFlBQWUsQ0FBUy9CLGVBQVQsRUFBMEJhLEdBQTFCLEVBQStCQyxHQUEvQixFQUFtQztBQUNyRCxNQUFJQyxpQkFBaUIsR0FBR2YsZUFBZSxDQUFDZSxpQkFBeEM7O0FBRUEsTUFBR0EsaUJBQWlCLENBQUNRLFdBQWxCLEtBQWtDMUIsUUFBUSxDQUFDMkIsU0FBVCxDQUFtQkMsS0FBeEQsRUFBOEQ7QUFDN0QsUUFBR1gsR0FBRyxHQUFHLENBQU4sSUFBV0EsR0FBRyxHQUFHLENBQWpCLElBQXNCRCxHQUFHLEdBQUcsQ0FBL0IsRUFBaUM7QUFDaEM7QUFDQSxhQUFPLEtBQVA7QUFDQTtBQUNELEdBTEQsTUFLTyxJQUFHRSxpQkFBaUIsQ0FBQ1EsV0FBbEIsS0FBa0MxQixRQUFRLENBQUMyQixTQUFULENBQW1CRSxHQUF4RCxFQUE2RDtBQUNuRSxRQUFHWixHQUFHLEdBQUcsQ0FBTixJQUFXQSxHQUFHLEdBQUcsQ0FBakIsSUFBc0JELEdBQUcsR0FBRyxDQUEvQixFQUFpQztBQUNoQztBQUNBLGFBQU8sS0FBUDtBQUNBO0FBQ0Q7O0FBRUQsTUFBR08sSUFBSSxDQUFDQyxHQUFMLENBQVNOLGlCQUFpQixDQUFDRSxLQUFsQixHQUEwQkosR0FBbkMsSUFBMEMsQ0FBMUMsSUFBK0NPLElBQUksQ0FBQ0MsR0FBTCxDQUFTTixpQkFBaUIsQ0FBQ0csS0FBbEIsR0FBMEJKLEdBQW5DLElBQTBDLENBQTVGLEVBQThGO0FBQzdGO0FBQ0EsV0FBTyxLQUFQO0FBQ0E7O0FBRUQsTUFBR0MsaUJBQWlCLENBQUNFLEtBQWxCLEtBQTRCSixHQUE1QixJQUFtQ0UsaUJBQWlCLENBQUNHLEtBQWxCLEtBQTRCSixHQUFsRSxFQUFzRSxDQUVyRSxDQUZELE1BRUs7QUFDRDtBQUNILFdBQU8sS0FBUDtBQUNBOztBQUVELFNBQU8sSUFBUDtBQUNBLENBNUJELEVBK0JBOzs7QUFDQSxJQUFJa0IsT0FBTyxHQUFHLFNBQVZBLE9BQVUsQ0FBU2hDLGVBQVQsRUFBMEJhLEdBQTFCLEVBQStCQyxHQUEvQixFQUFtQztBQUM3QyxNQUFJQyxpQkFBaUIsR0FBR2YsZUFBZSxDQUFDZSxpQkFBeEMsQ0FENkMsQ0FHN0M7QUFFSDs7QUFDQSxNQUFHZixlQUFlLENBQUNTLFlBQWhCLENBQTZCSSxHQUE3QixFQUFrQ0MsR0FBbEMsS0FBMENkLGVBQWUsQ0FBQ1MsWUFBaEIsQ0FBNkJJLEdBQTdCLEVBQWtDQyxHQUFsQyxFQUF1Q1MsV0FBdkMsS0FBdURSLGlCQUFpQixDQUFDUSxXQUF0SCxFQUFrSTtBQUVqSSxXQUFPLEtBQVA7QUFDQSxHQVQrQyxDQVc3Qzs7O0FBQ0EsVUFBT1IsaUJBQWlCLENBQUNrQixZQUF6QjtBQUVJO0FBQ0EsU0FBS3BDLFFBQVEsQ0FBQ3FDLFVBQVQsQ0FBb0JDLEdBQXpCO0FBQ0ksYUFBT3ZCLFVBQVUsQ0FBQ1osZUFBRCxFQUFrQmEsR0FBbEIsRUFBdUJDLEdBQXZCLENBQWpCO0FBRUo7O0FBQ0EsU0FBS2pCLFFBQVEsQ0FBQ3FDLFVBQVQsQ0FBb0JFLEVBQXpCO0FBQ0ksYUFBT2pCLFNBQVMsQ0FBQ25CLGVBQUQsRUFBa0JhLEdBQWxCLEVBQXVCQyxHQUF2QixDQUFoQjtBQUVKOztBQUNBLFNBQUtqQixRQUFRLENBQUNxQyxVQUFULENBQW9CRyxLQUF6QjtBQUNJLGFBQU9mLFlBQVksQ0FBQ3RCLGVBQUQsRUFBa0JhLEdBQWxCLEVBQXVCQyxHQUF2QixDQUFuQjtBQUVKOztBQUNBLFNBQUtqQixRQUFRLENBQUNxQyxVQUFULENBQW9CSSxHQUF6QjtBQUNJLGFBQU9YLFVBQVUsQ0FBQzNCLGVBQUQsRUFBa0JhLEdBQWxCLEVBQXVCQyxHQUF2QixDQUFqQjtBQUVKOztBQUNBLFNBQUtqQixRQUFRLENBQUNxQyxVQUFULENBQW9CSyxHQUF6QjtBQUNJLGFBQU9YLFVBQVUsQ0FBQzVCLGVBQUQsRUFBa0JhLEdBQWxCLEVBQXVCQyxHQUF2QixDQUFqQjtBQUVKOztBQUNBLFNBQUtqQixRQUFRLENBQUNxQyxVQUFULENBQW9CTSxJQUF6QjtBQUNJLGFBQU9WLFdBQVcsQ0FBQzlCLGVBQUQsRUFBa0JhLEdBQWxCLEVBQXVCQyxHQUF2QixDQUFsQjtBQUVKOztBQUNBLFNBQUtqQixRQUFRLENBQUNxQyxVQUFULENBQW9CTyxLQUF6QjtBQUNJLGFBQU9WLFlBQVksQ0FBQy9CLGVBQUQsRUFBa0JhLEdBQWxCLEVBQXVCQyxHQUF2QixDQUFuQjs7QUFFSjtBQUNJLGFBQU8sS0FBUDtBQS9CUjs7QUFrQ0EsU0FBTyxLQUFQO0FBQ0gsQ0EvQ0QsRUFpREE7OztBQUNBNEIsTUFBTSxDQUFDQyxPQUFQLEdBQWlCO0FBQ2JYLEVBQUFBLE9BQU8sRUFBU0EsT0FESDtBQUVoQmpDLEVBQUFBLDZCQUE2QixFQUFFQTtBQUZmLENBQWpCIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIOenu+WKqOinhOWImVxuICovXG52YXIgQ29uc3RhbnQgPSByZXF1aXJlKFwiLi9Db25zdGFudC5qc1wiKTtcblxuLy8tLS0tLS0tLS0tLS0tLS0tLeengeacieeahOW3peWFt+WHveaVsFxudmFyIGdldF9zdG9uZV9udW1fYmV0d2Vlbl9yb3dfY29sID0gZnVuY3Rpb24oZ2FtZV9ib2FyZF9pbmZvLCBmcm9tX3JvdywgZnJvbV9jb2wsIHRvX3JvdywgdG9fY29sKXtcbiAgICB2YXIgY291bnQgPSAwO1xuXG4gICAgLy8g5bem5Y+z56e75YqoXG4gICAgaWYoZnJvbV9yb3cgPT09IHRvX3Jvdyl7XG5cbiAgICAgICAgdmFyIGJlZ2FuX2NvbCA9IGZyb21fY29sO1xuICAgICAgICB2YXIgZW5kX2NvbCA9IHRvX2NvbDtcblxuICAgICAgICBpZihmcm9tX2NvbCA+IHRvX2NvbCl7XHQvLyDlt6botbAg5L+d6K+BIGJlZ2FuX2NvbCA8IGVuZF9jb2xcbiAgICAgICAgICAgIGJlZ2FuX2NvbCA9IHRvX2NvbDtcbiAgICAgICAgICAgIGVuZF9jb2wgPSBmcm9tX2NvbDtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vXHTliKTmlq3ooYzlrZDkuK3pl7TlrZjlnKjmo4vlrZDmlbBcbiAgICAgICAgZm9yKHZhciBpID0gYmVnYW5fY29sKzE7IGkgPD0gZW5kX2NvbC0xOyBpKyspe1xuICAgICAgICAgICAgaWYoZ2FtZV9ib2FyZF9pbmZvLnBpZWNlc0FyckFycltmcm9tX3Jvd11baV0pe1xuICAgICAgICAgICAgICAgIGNvdW50Kys7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgIH1cbiAgICAvLyDkuIrkuIvnp7vliqhcbiAgICBlbHNlIGlmKGZyb21fY29sID09PSB0b19jb2wpe1xuICAgICAgICB2YXIgYmVnYW5fcm93ID0gZnJvbV9yb3c7XG4gICAgICAgIHZhciBlbmRfcm93ID0gdG9fcm93O1xuXG4gICAgICAgIGlmKGZyb21fcm93ID4gdG9fcm93KXtcdC8vIOS4i+i1sCDkv53or4EgYmVnYW5fcm93IDwgZW5kX3Jvd1xuICAgICAgICAgICAgYmVnYW5fcm93ID0gdG9fcm93O1xuICAgICAgICAgICAgZW5kX3JvdyA9IGZyb21fcm93O1xuICAgICAgICB9XG5cbiAgICAgICAgLy8g5Yik5pat6KGM5a2Q5Lit6Ze05a2Y5Zyo5qOL5a2Q5pWwXG4gICAgICAgIGZvcih2YXIgaSA9IGJlZ2FuX3JvdysxOyBpIDw9IGVuZF9yb3ctMTsgaSsrKXtcbiAgICAgICAgICAgIGlmKGdhbWVfYm9hcmRfaW5mby5waWVjZXNBcnJBcnJbaV1bZnJvbV9jb2xdKXtcbiAgICAgICAgICAgICAgICBjb3VudCsrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLy8g56e75Yqo5YmN5ZCO5Lit6Ze05a2Y5Zyo55qE5a2X5pWwXG4gICAgcmV0dXJuIGNvdW50O1xufVxuXG5cbi8v6L2mXG52YXIgY2FuTW92ZUNoZSA9IGZ1bmN0aW9uKGdhbWVfYm9hcmRfaW5mbywgcm93LCBjb2wpe1xuICAgIHZhciBtX2N1cl9jbGlja19zdG9uZSA9IGdhbWVfYm9hcmRfaW5mby5tX2N1cl9jbGlja19zdG9uZTtcblxuICAgIHZhciBudW0gPSBnZXRfc3RvbmVfbnVtX2JldHdlZW5fcm93X2NvbChnYW1lX2JvYXJkX2luZm8sIG1fY3VyX2NsaWNrX3N0b25lLm1fcm93LCBtX2N1cl9jbGlja19zdG9uZS5tX2NvbCwgcm93LCBjb2wpO1xuXG4gICAgaWYobV9jdXJfY2xpY2tfc3RvbmUubV9yb3cgPT09IHJvdyB8fCBtX2N1cl9jbGlja19zdG9uZS5tX2NvbCA9PT0gY29sKXtcblxuICAgIH1lbHNle1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhcIi0tLS0t6L2m5Y+q6IO956e75Yqo55u057q/XCIpO1xuXHRcdHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICByZXR1cm4gbnVtID09PSAwO1xufVxuXG4vL+mprFxudmFyIGNhbk1vdmVNYSA9IGZ1bmN0aW9uKGdhbWVfYm9hcmRfaW5mbywgcm93LCBjb2wpe1xuXHR2YXIgbV9jdXJfY2xpY2tfc3RvbmUgPSBnYW1lX2JvYXJkX2luZm8ubV9jdXJfY2xpY2tfc3RvbmU7XG5cblx0aWYoTWF0aC5hYnMobV9jdXJfY2xpY2tfc3RvbmUubV9yb3cgLSByb3cpID09PSAxKXtcblx0XHRpZihNYXRoLmFicyhtX2N1cl9jbGlja19zdG9uZS5tX2NvbCAtIGNvbCkgPT09IDIpe1xuXHRcdFx0aWYoZ2FtZV9ib2FyZF9pbmZvLnBpZWNlc0FyckFyclttX2N1cl9jbGlja19zdG9uZS5tX3Jvd11bKG1fY3VyX2NsaWNrX3N0b25lLm1fY29sICsgY29sKSAvIDJdKXtcblx0XHRcdFx0Ly8gY29uc29sZS5sb2coXCItLS0tLemprOiEmuiiq+i5qVwiKTtcblx0XHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIHRydWU7XG5cdFx0fSBlbHNlIHtcblx0XHRcdC8vIGNvbnNvbGUubG9nKFwiLS0tLS3pqazlj6rog73otbDml6VcIik7XG5cdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0fVxuXHR9IGVsc2UgaWYoTWF0aC5hYnMobV9jdXJfY2xpY2tfc3RvbmUubV9yb3cgLSByb3cpID09PSAyKXtcblx0XHRpZihNYXRoLmFicyhtX2N1cl9jbGlja19zdG9uZS5tX2NvbCAtIGNvbCkgPT09IDEpe1xuXHRcdFx0aWYoZ2FtZV9ib2FyZF9pbmZvLnBpZWNlc0FyckFyclsobV9jdXJfY2xpY2tfc3RvbmUubV9yb3cgKyByb3cpIC8gMl1bbV9jdXJfY2xpY2tfc3RvbmUubV9jb2xdKXtcblx0XHRcdFx0Ly8gY29uc29sZS5sb2coXCItLS0tLemprOiEmuiiq+i5qVwiKTtcblx0XHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIHRydWU7XG5cdFx0fSBlbHNlIHtcblx0XHRcdC8vIGNvbnNvbGUubG9nKFwiLS0tLS3pqazlj6rog73otbDml6VcIik7XG5cdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0fVxuXHR9IGVsc2Uge1xuXHRcdC8vIGNvbnNvbGUubG9nKFwiLS0tLS3pqazlj6rog73otbDml6VcIik7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9XG5cblx0cmV0dXJuIHRydWU7XG59XG5cbi8v6LGhXG52YXIgY2FuTW92ZVhpYW5nID0gZnVuY3Rpb24oZ2FtZV9ib2FyZF9pbmZvLCByb3csIGNvbCl7XG5cdHZhciBtX2N1cl9jbGlja19zdG9uZSA9IGdhbWVfYm9hcmRfaW5mby5tX2N1cl9jbGlja19zdG9uZTtcblxuXHRpZihtX2N1cl9jbGlja19zdG9uZS5tX3R1cm5fdHlwZSA9PT0gQ29uc3RhbnQudHVybl90eXBlLmJsYWNrKXtcblx0XHRpZihyb3cgPCA1KXtcblx0XHRcdC8vIGNvbnNvbGUubG9nKFwiLS0tLS3osaHkuI3og73ov4fmsrNcIik7XG5cdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0fVxuXHR9IGVsc2UgaWYobV9jdXJfY2xpY2tfc3RvbmUubV90dXJuX3R5cGUgPT09IENvbnN0YW50LnR1cm5fdHlwZS5yZWQpIHtcblx0XHRpZihyb3cgPiA0KXtcblx0XHRcdC8vIGNvbnNvbGUubG9nKFwiLS0tLS3nm7jkuI3og73ov4fmsrNcIik7XG5cdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0fVxuXHR9XG5cblx0aWYoTWF0aC5hYnMobV9jdXJfY2xpY2tfc3RvbmUubV9yb3cgLSByb3cpICE9PSAyIHx8IE1hdGguYWJzKG1fY3VyX2NsaWNrX3N0b25lLm1fY29sIC0gY29sKSAhPT0gMil7XG5cdFx0Ly8gY29uc29sZS5sb2coXCItLS0tLeebuOWPquiDvei1sOeUsFwiKTtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cblxuXHRpZihnYW1lX2JvYXJkX2luZm8ucGllY2VzQXJyQXJyWyhtX2N1cl9jbGlja19zdG9uZS5tX3JvdyArIHJvdykgLyAyXVsobV9jdXJfY2xpY2tfc3RvbmUubV9jb2wgKyBjb2wpIC8gMl0pe1xuXHRcdC8vIGNvbnNvbGUubG9nKFwiLS0tLS3nm7jnnLzooqvmjKFcIik7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9XG5cblx0cmV0dXJuIHRydWU7XG59XG5cbi8v5aOrXG52YXIgY2FuTW92ZVNoaSA9IGZ1bmN0aW9uKGdhbWVfYm9hcmRfaW5mbywgcm93LCBjb2wpe1xuXHR2YXIgbV9jdXJfY2xpY2tfc3RvbmUgPSBnYW1lX2JvYXJkX2luZm8ubV9jdXJfY2xpY2tfc3RvbmU7XG5cblx0aWYobV9jdXJfY2xpY2tfc3RvbmUubV90dXJuX3R5cGUgPT09IENvbnN0YW50LnR1cm5fdHlwZS5ibGFjayl7XG5cdFx0aWYoY29sIDwgMyB8fCBjb2wgPiA1IHx8IHJvdyA8IDcpe1xuXHRcdFx0Ly8gY29uc29sZS5sb2coXCItLS0tLeS4jeiDveWHuuWuq1wiKTtcblx0XHRcdHJldHVybiBmYWxzZVxuXHRcdH1cblx0fSBlbHNlIGlmKG1fY3VyX2NsaWNrX3N0b25lLm1fdHVybl90eXBlID09PSBDb25zdGFudC50dXJuX3R5cGUucmVkKSB7XG5cdFx0aWYoY29sIDwgMyB8fCBjb2wgPiA1IHx8IHJvdyA+IDIpe1xuXHRcdFx0Ly8gY29uc29sZS5sb2coXCItLS0tLeWjq+S4jeiDveWHuuWuq1wiKTtcblx0XHRcdHJldHVybiBmYWxzZVxuXHRcdH1cblx0fVxuXG5cdGlmKE1hdGguYWJzKG1fY3VyX2NsaWNrX3N0b25lLm1fcm93IC0gcm93KSAhPT0gMSB8fCBNYXRoLmFicyhtX2N1cl9jbGlja19zdG9uZS5tX2NvbCAtIGNvbCkgIT09IDEpe1xuXHRcdC8vIGNvbnNvbGUubG9nKFwiLS0tLS3lo6vlj6rog73np7vliqjmlpznur9cIik7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9XG5cblx0cmV0dXJuIHRydWU7XG59XG5cbi8v54KuXG52YXIgY2FuTW92ZVBhbyA9IGZ1bmN0aW9uKGdhbWVfYm9hcmRfaW5mbywgcm93LCBjb2wpe1xuXG4gICAgLy/lvZPliY3pgInkuK3nmoTmo4vlrZBcbiAgICB2YXIgbV9jdXJfY2xpY2tfc3RvbmUgPSBnYW1lX2JvYXJkX2luZm8ubV9jdXJfY2xpY2tfc3RvbmU7XG5cbiAgICAvL1xuICAgIHZhciBudW0gPSBnZXRfc3RvbmVfbnVtX2JldHdlZW5fcm93X2NvbChnYW1lX2JvYXJkX2luZm8sIG1fY3VyX2NsaWNrX3N0b25lLm1fcm93LCBtX2N1cl9jbGlja19zdG9uZS5tX2NvbCwgcm93LCBjb2wpO1xuXG4gICAgaWYobV9jdXJfY2xpY2tfc3RvbmUubV9yb3cgPT09IHJvdyB8fCBtX2N1cl9jbGlja19zdG9uZS5tX2NvbCA9PT0gY29sKXtcblxuICAgIH1lbHNle1xuXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwiLS0tLS3np7vliqjngq7lv4Xpobvmu6HotrPlnKjkuIDmnaHnm7Tnur/kuIpcIik7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICAvL+S7heS7heenu+WKqCjljIXmi6zmqKrlkoznq5YpLOWImeenu+WKqOWIsOeahHJvdyBjb2zkuI3og73mnInlrZBcbiAgICBpZihudW0gPT0gMCl7XG4gICAgICAgIHZhciBzdG9uZSA9IGdhbWVfYm9hcmRfaW5mby5waWVjZXNBcnJBcnJbcm93XVtjb2xdO1xuXG4gICAgICAgIGlmKCFzdG9uZSl7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfWVsc2V7XG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhcIi0tLS0t5LuF5LuF56e75Yqo55qE6K+d77yM5LiN5Y+v5Lul56e75Yqo5Yiw5pyJ5a2Q55qE5Zyw5pa5XCIpO1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgfVxuICAgIC8v5ZCD5LiA5Liq5a2QXG4gICAgZWxzZSBpZihudW0gPT0gMSl7XG5cbiAgICAgICAgdmFyIHN0b25lID0gZ2FtZV9ib2FyZF9pbmZvLnBpZWNlc0FyckFycltyb3ddW2NvbF07XG4gICAgICAgIGlmKHN0b25lKXtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9ZWxzZXtcblxuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coXCItLS0tLemXtOWxseaJk+WtkOeahOivne+8jOW/hemhu+acieS4gOS4quWtkFwiKTtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuXG4gICAgfVxuXG4gICAgLy/pmpTkuIDlrZDku6XkuIpcbiAgICByZXR1cm4gZmFsc2U7XG59XG5cbi8v5YW1XG52YXIgY2FuTW92ZUJpbmcgPSBmdW5jdGlvbihnYW1lX2JvYXJkX2luZm8sIHJvdywgY29sKXtcblx0dmFyIG1fY3VyX2NsaWNrX3N0b25lID0gZ2FtZV9ib2FyZF9pbmZvLm1fY3VyX2NsaWNrX3N0b25lO1xuXG5cdGlmKG1fY3VyX2NsaWNrX3N0b25lLm1fdHVybl90eXBlID09PSBDb25zdGFudC50dXJuX3R5cGUuYmxhY2spe1xuXHRcdGlmKG1fY3VyX2NsaWNrX3N0b25lLm1fcm93IDwgcm93KXtcblx0XHRcdC8vIGNvbnNvbGUubG9nKFwiLS0tLS3ljZLkuI3og73lkI7pgIBcIik7XG5cdFx0XHRyZXR1cm4gZmFsc2Vcblx0XHR9XG5cblx0XHRpZihtX2N1cl9jbGlja19zdG9uZS5tX3JvdyA+IDQgJiYgbV9jdXJfY2xpY2tfc3RvbmUubV9jb2wgIT09IGNvbCl7XG5cdFx0XHQvLyBjb25zb2xlLmxvZyhcIi0tLS0t5Y2S5pyq6L+H5rKz5LiN6IO95bem5Y+zXCIpXG5cdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0fVxuXHR9IGVsc2UgaWYobV9jdXJfY2xpY2tfc3RvbmUubV90dXJuX3R5cGUgPT09IENvbnN0YW50LnR1cm5fdHlwZS5yZWQpIHtcblx0XHRpZihtX2N1cl9jbGlja19zdG9uZS5tX3JvdyA+IHJvdyl7XG5cdFx0XHQvLyBjb25zb2xlLmxvZyhcIi0tLS0t5YW15LiN6IO95ZCO6YCAXCIpO1xuXHRcdFx0cmV0dXJuIGZhbHNlXG5cdFx0fVxuXG5cdFx0aWYobV9jdXJfY2xpY2tfc3RvbmUubV9yb3cgPCA1ICYmIG1fY3VyX2NsaWNrX3N0b25lLm1fY29sICE9PSBjb2wpe1xuXHRcdFx0Ly8gY29uc29sZS5sb2coXCItLS0tLeWFteacqui/h+ays+S4jeiDveW3puWPs1wiKVxuXHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdH1cblx0fVxuXG5cblx0aWYoTWF0aC5hYnMobV9jdXJfY2xpY2tfc3RvbmUubV9yb3cgLSByb3cpID4gMSB8fCBNYXRoLmFicyhtX2N1cl9jbGlja19zdG9uZS5tX2NvbCAtIGNvbCkgPiAxKXtcblx0XHQvLyBjb25zb2xlLmxvZyhcIi0tLS0t5YW15Y+q6IO96LWw5LiA5q2lXCIpO1xuXHRcdHJldHVybiBmYWxzZVxuXHR9XG5cblxuXHRpZihtX2N1cl9jbGlja19zdG9uZS5tX3JvdyA9PT0gcm93IHx8IG1fY3VyX2NsaWNrX3N0b25lLm1fY29sID09PSBjb2wpe1xuXG5cdH1lbHNle1xuXHQgICAgLy8gY29uc29sZS5sb2coXCItLS0tLeWFteWPquiDveenu+WKqOebtOe6v1wiKTtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cblxuXHRyZXR1cm4gdHJ1ZTtcbn1cblxuLy/lsIZcbnZhciBjYW5Nb3ZlSmlhbmcgPSBmdW5jdGlvbihnYW1lX2JvYXJkX2luZm8sIHJvdywgY29sKXtcblx0dmFyIG1fY3VyX2NsaWNrX3N0b25lID0gZ2FtZV9ib2FyZF9pbmZvLm1fY3VyX2NsaWNrX3N0b25lO1xuXG5cdGlmKG1fY3VyX2NsaWNrX3N0b25lLm1fdHVybl90eXBlID09PSBDb25zdGFudC50dXJuX3R5cGUuYmxhY2spe1xuXHRcdGlmKGNvbCA8IDMgfHwgY29sID4gNSB8fCByb3cgPCA3KXtcblx0XHRcdC8vIGNvbnNvbGUubG9nKFwiLS0tLS3lsIbkuI3og73lh7rlrqtcIik7XG5cdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0fVxuXHR9IGVsc2UgaWYobV9jdXJfY2xpY2tfc3RvbmUubV90dXJuX3R5cGUgPT09IENvbnN0YW50LnR1cm5fdHlwZS5yZWQpIHtcblx0XHRpZihjb2wgPCAzIHx8IGNvbCA+IDUgfHwgcm93ID4gMil7XG5cdFx0XHQvLyBjb25zb2xlLmxvZyhcIi0tLS0t5biF5LiN6IO95Ye65a6rXCIpO1xuXHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdH1cblx0fVxuXG5cdGlmKE1hdGguYWJzKG1fY3VyX2NsaWNrX3N0b25lLm1fcm93IC0gcm93KSA+IDEgfHwgTWF0aC5hYnMobV9jdXJfY2xpY2tfc3RvbmUubV9jb2wgLSBjb2wpID4gMSl7XG5cdFx0Ly8gY29uc29sZS5sb2coXCItLS0tLeW4heWPquiDvei1sOS4gOatpVwiKTtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cblxuXHRpZihtX2N1cl9jbGlja19zdG9uZS5tX3JvdyA9PT0gcm93IHx8IG1fY3VyX2NsaWNrX3N0b25lLm1fY29sID09PSBjb2wpe1xuXG5cdH1lbHNle1xuXHQgICAgLy8gY29uc29sZS5sb2coXCItLS0tLeW4heWPquiDveenu+WKqOebtOe6v1wiKTtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cblxuXHRyZXR1cm4gdHJ1ZTtcbn1cblxuXG4vL1xudmFyIGNhbk1vdmUgPSBmdW5jdGlvbihnYW1lX2JvYXJkX2luZm8sIHJvdywgY29sKXtcbiAgICB2YXIgbV9jdXJfY2xpY2tfc3RvbmUgPSBnYW1lX2JvYXJkX2luZm8ubV9jdXJfY2xpY2tfc3RvbmU7XG5cbiAgICAvLyBjb25zb2xlLmxvZyhcIuS9oOW9k+WJjeenu+WKqOS6hlwiICsgQ29uc3RhbnQuc3RvbmVfcmVzX2NvbmZpZ1ttX2N1cl9jbGlja19zdG9uZS5tX3R1cm5fdHlwZV1bbV9jdXJfY2xpY2tfc3RvbmUubV9zdG9uZV90eXBlXSk7XG5cblx0Ly8g5YmU6Zmk6Ieq5bex5pa555qE5qOL5a2QXG5cdGlmKGdhbWVfYm9hcmRfaW5mby5waWVjZXNBcnJBcnJbcm93XVtjb2xdICYmIGdhbWVfYm9hcmRfaW5mby5waWVjZXNBcnJBcnJbcm93XVtjb2xdLm1fdHVybl90eXBlID09PSBtX2N1cl9jbGlja19zdG9uZS5tX3R1cm5fdHlwZSl7XG5cblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cblxuICAgIC8vXG4gICAgc3dpdGNoKG1fY3VyX2NsaWNrX3N0b25lLm1fc3RvbmVfdHlwZSl7XG5cbiAgICAgICAgLy/ovaZcbiAgICAgICAgY2FzZSBDb25zdGFudC5zdG9uZV90eXBlLmNoZTpcbiAgICAgICAgICAgIHJldHVybiBjYW5Nb3ZlQ2hlKGdhbWVfYm9hcmRfaW5mbywgcm93LCBjb2wpO1xuXG4gICAgICAgIC8v6amsXG4gICAgICAgIGNhc2UgQ29uc3RhbnQuc3RvbmVfdHlwZS5tYTpcbiAgICAgICAgICAgIHJldHVybiBjYW5Nb3ZlTWEoZ2FtZV9ib2FyZF9pbmZvLCByb3csIGNvbCk7XG5cbiAgICAgICAgLy/osaFcbiAgICAgICAgY2FzZSBDb25zdGFudC5zdG9uZV90eXBlLnhpYW5nOlxuICAgICAgICAgICAgcmV0dXJuIGNhbk1vdmVYaWFuZyhnYW1lX2JvYXJkX2luZm8sIHJvdywgY29sKTtcblxuICAgICAgICAvL+Wjq1xuICAgICAgICBjYXNlIENvbnN0YW50LnN0b25lX3R5cGUuc2hpOlxuICAgICAgICAgICAgcmV0dXJuIGNhbk1vdmVTaGkoZ2FtZV9ib2FyZF9pbmZvLCByb3csIGNvbCk7XG5cbiAgICAgICAgLy/ngq5cbiAgICAgICAgY2FzZSBDb25zdGFudC5zdG9uZV90eXBlLnBhbzpcbiAgICAgICAgICAgIHJldHVybiBjYW5Nb3ZlUGFvKGdhbWVfYm9hcmRfaW5mbywgcm93LCBjb2wpO1xuXG4gICAgICAgIC8v5YW1XG4gICAgICAgIGNhc2UgQ29uc3RhbnQuc3RvbmVfdHlwZS5iaW5nOlxuICAgICAgICAgICAgcmV0dXJuIGNhbk1vdmVCaW5nKGdhbWVfYm9hcmRfaW5mbywgcm93LCBjb2wpO1xuXG4gICAgICAgIC8v5bCGXG4gICAgICAgIGNhc2UgQ29uc3RhbnQuc3RvbmVfdHlwZS5qaWFuZzpcbiAgICAgICAgICAgIHJldHVybiBjYW5Nb3ZlSmlhbmcoZ2FtZV9ib2FyZF9pbmZvLCByb3csIGNvbCk7XG5cbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICByZXR1cm4gZmFsc2U7XG59XG5cbi8v5a+85Ye66KeE5YiZ6KGoXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgICBjYW5Nb3ZlOiAgICAgICAgY2FuTW92ZSxcblx0Z2V0X3N0b25lX251bV9iZXR3ZWVuX3Jvd19jb2w6IGdldF9zdG9uZV9udW1fYmV0d2Vlbl9yb3dfY29sXG59XG4iXX0=